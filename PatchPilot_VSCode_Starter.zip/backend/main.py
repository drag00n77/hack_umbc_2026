from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from backend.services.zap_service import get_zap_status, run_basic_scan
from backend.services.gemini_service import analyze_vulnerability

app = FastAPI(title="PatchPilot API", version="0.1.0")

class ScanRequest(BaseModel):
    target: str

class AnalyzeRequest(BaseModel):
    finding: dict

@app.get("/health")
def health():
    return {"status": "ok", "message": "PatchPilot backend is connected"}

@app.get("/zap/status")
def zap_status():
    try:
        return get_zap_status()
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@app.post("/scan")
def scan(request: ScanRequest):
    try:
        return run_basic_scan(request.target)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@app.post("/analyze")
def analyze(request: AnalyzeRequest):
    try:
        return analyze_vulnerability(request.finding)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
