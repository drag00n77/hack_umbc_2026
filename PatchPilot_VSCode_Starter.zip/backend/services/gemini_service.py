import os
from dotenv import load_dotenv
from google import genai

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

def analyze_vulnerability(finding: dict):
    if not GEMINI_API_KEY:
        return {
            "ai_enabled": False,
            "message": "GEMINI_API_KEY is not configured.",
            "finding": finding
        }

    client = genai.Client(api_key=GEMINI_API_KEY)
    prompt = f"""
You are the AI analysis layer for PatchPilot, a defensive cybersecurity tool.
OWASP ZAP has already detected the finding below.
Do not invent additional vulnerabilities.
Base your analysis only on the provided ZAP evidence.

Name: {finding.get('name')}
Risk: {finding.get('risk')}
Confidence: {finding.get('confidence')}
URL: {finding.get('url')}
Method: {finding.get('method')}
Parameter: {finding.get('param')}
Evidence: {finding.get('evidence')}
Description: {finding.get('description')}
Existing ZAP solution: {finding.get('solution')}
CWE: {finding.get('cweid')}

Return these headings:
SUMMARY:
WHY IT MATTERS:
PRIORITY:
REMEDIATION:
DEVELOPER GUIDANCE:
VERIFICATION:

Focus on remediation and defensive security.
"""
    response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
    return {
        "ai_enabled": True,
        "model": GEMINI_MODEL,
        "analysis": response.text,
        "source": "Gemini interpretation of OWASP ZAP evidence"
    }
