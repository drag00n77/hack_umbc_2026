import os
import time
from dotenv import load_dotenv
from zapv2 import ZAPv2

load_dotenv()
ZAP_API_KEY = os.getenv("ZAP_API_KEY", "")
ZAP_PROXY = os.getenv("ZAP_PROXY", "http://127.0.0.1:8080")
proxies = {"http": ZAP_PROXY, "https": ZAP_PROXY}
zap = ZAPv2(apikey=ZAP_API_KEY, proxies=proxies)

def get_zap_status():
    return {"connected": True, "zap_version": zap.core.version, "proxy": ZAP_PROXY}

def run_basic_scan(target: str):
    if not target.startswith(("http://", "https://")):
        raise ValueError("Target must begin with http:// or https://")

    zap.urlopen(target)
    time.sleep(2)

    spider_id = zap.spider.scan(target)
    while int(zap.spider.status(spider_id)) < 100:
        time.sleep(1)

    scan_id = zap.ascan.scan(target)
    while int(zap.ascan.status(scan_id)) < 100:
        time.sleep(2)

    alerts = zap.core.alerts(baseurl=target)
    findings = []
    for alert in alerts:
        findings.append({
            "name": alert.get("alert"),
            "risk": alert.get("risk"),
            "confidence": alert.get("confidence"),
            "url": alert.get("url"),
            "method": alert.get("method"),
            "param": alert.get("param"),
            "attack": alert.get("attack"),
            "evidence": alert.get("evidence"),
            "description": alert.get("description"),
            "solution": alert.get("solution"),
            "cweid": alert.get("cweid"),
            "wascid": alert.get("wascid"),
            "reference": alert.get("reference"),
        })
    return {
        "target": target,
        "scanner": "OWASP ZAP",
        "zap_version": zap.core.version,
        "finding_count": len(findings),
        "findings": findings
    }
