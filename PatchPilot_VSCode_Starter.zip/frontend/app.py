import os
import requests
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000")

st.set_page_config(page_title="PatchPilot", page_icon="🛡️", layout="wide")

st.markdown("""
<style>
.stApp {background:#0b1120;color:#f8fafc;}
.block-container {padding-top:2rem;max-width:1400px;}
</style>
""", unsafe_allow_html=True)

st.title("🛡️ PatchPilot")
st.caption("Detect. Understand. Defend.")

with st.sidebar:
    st.header("PatchPilot")
    if st.button("Test Backend Connection", use_container_width=True):
        try:
            r=requests.get(f"{BACKEND_URL}/health", timeout=5)
            r.raise_for_status()
            st.success(r.json()["message"])
        except Exception as exc:
            st.error(f"Backend connection failed: {exc}")

    if st.button("Test ZAP Connection", use_container_width=True):
        try:
            r=requests.get(f"{BACKEND_URL}/zap/status", timeout=10)
            r.raise_for_status()
            d=r.json()
            st.success(f"Connected to OWASP ZAP {d['zap_version']}")
        except Exception as exc:
            st.error(f"ZAP connection failed: {exc}")

st.subheader("Security Overview")
st.caption("Scan an authorized target with OWASP ZAP and analyze findings with Gemini.")

c1,c2,c3,c4=st.columns(4)
c1.metric("Critical","0")
c2.metric("High","0")
c3.metric("Medium","0")
c4.metric("Low","0")

st.divider()
st.subheader("New Security Scan")
target=st.text_input("Authorized Target URL", placeholder="http://localhost:3000")
authorized=st.checkbox("I confirm that I own this system or have explicit permission to test it.")

if "scan_results" not in st.session_state:
    st.session_state.scan_results=None
if "ai_result" not in st.session_state:
    st.session_state.ai_result=None

if st.button("Start OWASP ZAP Scan", type="primary", disabled=not authorized):
    if not target:
        st.warning("Enter a target URL first.")
    else:
        try:
            with st.status("Running OWASP ZAP scan...", expanded=True) as status:
                st.write("Connecting to FastAPI...")
                st.write("Starting ZAP spider and active scan...")
                r=requests.post(f"{BACKEND_URL}/scan", json={"target":target}, timeout=900)
                r.raise_for_status()
                st.session_state.scan_results=r.json()
                status.update(label="Scan complete", state="complete")
        except Exception as exc:
            st.error(f"Scan failed: {exc}")

results=st.session_state.scan_results
if results:
    st.divider()
    st.subheader("Detected Vulnerabilities")
    st.caption(f"Detected by OWASP ZAP {results.get('zap_version','')}")
    st.metric("Total Findings", results.get("finding_count",0))
    findings=results.get("findings",[])
    if not findings:
        st.success("No ZAP findings were returned.")
    else:
        labels=[f"{i+1}. {f.get('risk','Unknown')} - {f.get('name','Finding')}" for i,f in enumerate(findings)]
        selected_label=st.selectbox("Select a vulnerability", labels)
        finding=findings[labels.index(selected_label)]
        left,right=st.columns([1,1.3])
        with left:
            st.markdown("### OWASP ZAP Evidence")
            st.json(finding)
        with right:
            st.markdown("### Gemini Analysis")
            st.caption("Gemini interprets ZAP evidence; it does not detect the vulnerability.")
            if st.button("Analyze Selected Finding with Gemini"):
                try:
                    r=requests.post(f"{BACKEND_URL}/analyze", json={"finding":finding}, timeout=60)
                    r.raise_for_status()
                    st.session_state.ai_result=r.json()
                except Exception as exc:
                    st.error(f"Gemini analysis failed: {exc}")
            ai_result=st.session_state.ai_result
            if ai_result:
                if ai_result.get("ai_enabled"):
                    st.markdown(ai_result.get("analysis",""))
                else:
                    st.warning(ai_result.get("message","Gemini is not configured."))
