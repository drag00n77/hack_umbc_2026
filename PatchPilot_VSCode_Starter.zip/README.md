# PatchPilot VS Code Starter

This starter connects:

Streamlit -> FastAPI -> OWASP ZAP -> Gemini -> Streamlit

## Windows / VS Code Quick Start

1. Open this folder in VS Code.
2. Open Terminal -> New Terminal.
3. Create a virtual environment:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

4. Install dependencies:

```powershell
pip install -r requirements.txt
```

5. Copy `.env.example` to `.env` and add your Gemini API key.

6. Start OWASP ZAP and make sure its API/proxy is reachable on `http://127.0.0.1:8080`.

7. Start FastAPI in Terminal 1:

```powershell
uvicorn backend.main:app --reload
```

8. Open `http://127.0.0.1:8000/docs` to verify FastAPI.

9. Open a SECOND VS Code terminal and start Streamlit:

```powershell
streamlit run frontend/app.py
```

10. In PatchPilot, test in this order:
- Test Backend Connection
- Test ZAP Connection
- Enter an authorized training target
- Run scan
- Select a finding
- Analyze it with Gemini

## Architecture

Google Stitch is your design blueprint. It is not a runtime dependency.

```text
Google Stitch
    |
    v
Streamlit frontend
    | HTTP
    v
FastAPI backend
   / \
  v   v
 ZAP Gemini
   \ /
    v
 FastAPI
    |
    v
Streamlit UI
```

Only scan systems you own or are explicitly authorized to test.
