export type SeverityLevel = 'critical' | 'high' | 'medium' | 'low';

export interface Vulnerability {
  id: string;
  name: string;
  cwe: string;
  wasc?: string;
  category: string;
  severity: SeverityLevel;
  cvss: number;
  priority: number;
  endpoint: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  confidence: number;
  status: 'Open' | 'Investigating' | 'In Review' | 'Remediated' | 'Verified';
  detectedTime: string;
  scanner: string;
  scannerRuleId?: string;
  parameter?: string;
  responseStatus?: string;
  latency?: string;
  payload?: string;
  payloadType?: string;
  errorOutput?: string;
  summary: string;
  impact: string;
  affectedFile?: string;
  vulnerableCode?: string;
  remediatedCode?: string;
  stepsToFix?: string[];
  remediationTeam?: string;
}

export interface AttackNode {
  id: string;
  title: string;
  type: 'actor' | 'ingress' | 'vulnerability' | 'lateral' | 'objective' | 'identity';
  roleLabel: string;
  badge: string;
  severity?: SeverityLevel;
  cvss?: number;
  cwe?: string;
  description: string;
  endpoint?: string;
  method?: string;
  subtext?: string;
  scannerProof?: string;
  mitreTechniques?: { code: string; name: string; tactic: string }[];
  patchSnippet?: { before: string; after: string };
  whyContributes?: string;
}

export interface AttackPath {
  id: string;
  title: string;
  severity: SeverityLevel;
  cveNodesCount: number;
  maxBlastRadius: string;
  estimatedTtp: string;
  complianceViolation: string;
  timeline: {
    phase: string;
    label: string;
    title: string;
    description: string;
    mitreCode: string;
    active?: boolean;
    severity?: SeverityLevel;
  }[];
  nodeIds: string[];
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  severity: SeverityLevel;
  timestamp: string;
  read: boolean;
  linkAction?: string;
}
