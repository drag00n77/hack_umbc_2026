import React, { useState } from 'react';
import { LOGO_URL, NOTIFICATIONS } from '../data/mockData.ts';
import { NavTab } from './Sidebar.tsx';

interface HeaderProps {
  currentTab: NavTab;
  onOpenSlackModal: () => void;
  onOpenBriefModal: () => void;
  onTriggerScan: () => void;
  isScanning?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onOpenSlackModal,
  onOpenBriefModal,
  onTriggerScan,
  isScanning = false,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);

  const getSubheaderInfo = () => {
    switch (currentTab) {
      case 'security-overview':
        return { title: 'Security Overview', desc: 'Monitor vulnerabilities, prioritize risk, and verify remediation.' };
      case 'new-scan':
        return { title: 'New Security Scan', desc: 'Configure and launch an authorized OWASP ZAP security assessment.' };
      case 'vulnerabilities':
        return { title: 'Vulnerabilities', desc: 'Investigate security findings identified by OWASP ZAP deep engine inspection.' };
      case 'attack-paths':
        return { title: 'Potential Attack Paths', desc: 'Correlate runtime ZAP findings, network exposure, and impact blast radiuses.' };
      case 'remediation-center':
        return { title: 'Remediation Center', desc: 'Structured step-by-step developer remediation workflows with integrated AI guidance.' };
      case 'verification':
        return { title: 'Verification Center', desc: 'Confirm whether remediation successfully resolved detected vulnerabilities.' };
      case 'reports':
        return { title: 'Reports & Audits', desc: 'Board-ready compliance artifacts, verification attestations, and audit logs.' };
      case 'integrations':
        return { title: 'Integrations Hub', desc: 'Connect OWASP ZAP daemons, CI/CD pipelines, Slack webhooks, and GitHub PR bots.' };
      case 'settings':
        return { title: 'Platform Settings', desc: 'Autonomous triage thresholds, rate limits, and perimeter access mandates.' };
      default:
        return { title: 'PatchPilot Console', desc: 'Detect. Understand. Defend.' };
    }
  };

  const headerInfo = getSubheaderInfo();

  return (
    <header className="fixed top-0 left-72 right-0 h-20 bg-[#0f131c]/85 backdrop-blur-xl z-40 shadow-[0_1px_8px_rgba(0,0,0,0.4)] border-b border-[#1c2028]">
      <div className="w-full h-20 px-6 flex items-center justify-between">
        {/* Left: Brand info & Breadcrumb */}
        <div className="flex items-center gap-4 min-w-0">
          <img 
            alt="PatchPilot Shield Logo" 
            className="h-8 w-auto object-contain" 
            src={LOGO_URL} 
          />
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold tracking-tight leading-none">
                PatchPilot
              </span>
              <span className="font-code-sm text-[11px] text-[#c0c1ff] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-[#8083ff]/15">
                Console
              </span>
            </div>
            <span className="font-body-sm text-[12px] text-[#908fa0] truncate mt-0.5">
              {headerInfo.desc}
            </span>
          </div>
        </div>

        {/* Right: Controls & CTAs */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Target Host Badge */}
          <div className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#181c24] font-code-sm text-[12px] border border-[#262a33]">
            <span className="material-symbols-outlined text-[15px] text-[#7bd0ff]">dns</span>
            <span className="text-[#908fa0]">Target:</span>
            <span className="text-[#dfe2ee] font-mono font-semibold">localhost:3000</span>
            <span className="h-1.5 w-1.5 rounded-full bg-[#7bd0ff] animate-pulse"></span>
            <span className="text-[#7bd0ff] text-[10px] font-bold uppercase tracking-wider">Reachable</span>
          </div>

          {/* Engine Status Badge */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#1c2028] font-code-sm text-[12px] border border-[#262a33]">
            <span className="h-2 w-2 rounded-full bg-[#7bd0ff] animate-ping"></span>
            <span className="text-[#908fa0]">Scanner:</span>
            <span className="text-[#dfe2ee] font-semibold">OWASP ZAP v2.14</span>
          </div>

          {/* Slack Alert Button */}
          <button 
            onClick={onOpenSlackModal}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#93000a]/80 text-[#ffdad6] hover:bg-[#93000a] transition-all font-label-md text-[12px] font-semibold shadow-sm border border-[#ffb4ab]/30 cursor-pointer"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px]">campaign</span>
            <span>Send Alert to Slack</span>
          </button>

          {/* Notifications Bell */}
          <div className="relative">
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              aria-label="Notifications" 
              className="w-9 h-9 rounded-lg bg-[#1c2028] flex items-center justify-center text-[#c7c4d7] hover:text-[#dfe2ee] hover:bg-[#262a33] transition-colors border border-[#262a33] cursor-pointer" 
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">notifications</span>
            </button>
            <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#ffb4ab] text-[#690005] font-code-sm text-[10px] font-bold">
              3
            </span>

            {/* Notifications Popover */}
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-xl bg-[#181c24] border border-[#262a33] shadow-2xl p-3 z-50 flex flex-col gap-2">
                <div className="flex items-center justify-between pb-2 border-b border-[#262a33]">
                  <span className="font-label-lg text-[13px] text-[#dfe2ee] font-bold">SecOps Real-Time Alerts</span>
                  <span className="text-[11px] font-mono text-[#7bd0ff] font-semibold">3 Unresolved</span>
                </div>
                <div className="flex flex-col gap-2 max-h-80 overflow-y-auto pr-1">
                  {NOTIFICATIONS.map((n) => (
                    <div 
                      key={n.id}
                      className="p-2.5 rounded-lg bg-[#1c2028] hover:bg-[#262a33] transition-colors cursor-pointer border border-[#262a33]"
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded uppercase ${
                          n.severity === 'critical' ? 'bg-[#93000a] text-[#ffdad6]' :
                          n.severity === 'high' ? 'bg-[#a078ff]/30 text-[#d0bcff]' : 'bg-[#00a6e0]/30 text-[#7bd0ff]'
                        }`}>
                          {n.severity}
                        </span>
                        <span className="text-[10px] text-[#908fa0]">{n.timestamp}</span>
                      </div>
                      <h4 className="text-[12px] font-semibold text-[#dfe2ee] mt-1">{n.title}</h4>
                      <p className="text-[11px] text-[#c7c4d7] line-clamp-2 mt-0.5">{n.message}</p>
                    </div>
                  ))}
                </div>
                <div className="pt-2 border-t border-[#262a33] flex justify-between items-center text-[11px]">
                  <button 
                    onClick={() => setShowNotifications(false)}
                    className="text-[#c0c1ff] hover:underline cursor-pointer"
                  >
                    Close
                  </button>
                  <span className="text-[#908fa0]">OWASP ZAP Telemetry Sync Active</span>
                </div>
              </div>
            )}
          </div>

          {/* Generate Security Brief Button */}
          <button 
            onClick={onOpenBriefModal}
            className="hidden md:flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#c0c1ff] text-[#1000a9] hover:bg-[#e1e0ff] transition-all font-label-md text-[13px] font-semibold shadow-sm cursor-pointer" 
            type="button"
          >
            <span className="material-symbols-outlined text-[17px]">download</span>
            <span>Security Brief</span>
          </button>

          {/* Quick Scan Action */}
          <button 
            onClick={onTriggerScan}
            disabled={isScanning}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#8083ff] text-[#0d0096] hover:bg-[#c0c1ff] transition-all font-label-md text-[13px] font-bold shadow-md cursor-pointer disabled:opacity-60" 
            type="button"
          >
            <span className={`material-symbols-outlined text-[18px] ${isScanning ? 'animate-spin' : ''}`}>
              {isScanning ? 'progress_activity' : 'play_arrow'}
            </span>
            <span className="hidden sm:inline">{isScanning ? 'Scanning...' : 'Start Security Scan'}</span>
          </button>

          {/* User Profile */}
          <div className="w-8 h-8 rounded-full bg-[#c0c1ff] flex items-center justify-center shrink-0 text-[#1000a9]" title="SecOps Lead (lead@patchpilot.io)">
            <span className="material-symbols-outlined text-[18px]">person</span>
          </div>
        </div>
      </div>
    </header>
  );
};
