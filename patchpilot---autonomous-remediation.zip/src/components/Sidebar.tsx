import React from 'react';
import { LOGO_URL } from '../data/mockData.ts';

export type NavTab = 
  | 'security-overview'
  | 'new-scan'
  | 'vulnerabilities'
  | 'attack-paths'
  | 'remediation-center'
  | 'verification'
  | 'reports'
  | 'integrations'
  | 'settings';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, onSelectTab }) => {
  const navItems = [
    {
      id: 'security-overview' as NavTab,
      label: 'Security Overview',
      icon: 'shield',
      badge: null
    },
    {
      id: 'new-scan' as NavTab,
      label: 'New Scan',
      icon: 'radar',
      badge: null
    },
    {
      id: 'vulnerabilities' as NavTab,
      label: 'Vulnerabilities',
      icon: 'security',
      badge: { text: '22', className: 'bg-[#93000a] text-[#ffdad6]' }
    },
    {
      id: 'attack-paths' as NavTab,
      label: 'Attack Paths',
      icon: 'route',
      badge: { text: 'AI BETA', className: 'bg-[#a078ff] text-[#340080] uppercase tracking-wider' }
    },
    {
      id: 'remediation-center' as NavTab,
      label: 'Remediation Center',
      icon: 'build_circle',
      badge: { text: '3', className: 'bg-[#00a6e0] text-[#00374d]' }
    },
    {
      id: 'verification' as NavTab,
      label: 'Verification',
      icon: 'verified_user',
      badge: null
    },
    {
      id: 'reports' as NavTab,
      label: 'Reports',
      icon: 'assessment',
      badge: null
    },
    {
      id: 'integrations' as NavTab,
      label: 'Integrations',
      icon: 'hub',
      badge: null
    },
    {
      id: 'settings' as NavTab,
      label: 'Settings',
      icon: 'settings',
      badge: null
    }
  ];

  return (
    <aside className="fixed left-0 top-0 h-full w-72 bg-[#0a0e16] z-50 flex flex-col justify-between shadow-[0_1px_8px_rgba(0,0,0,0.4)] border-r border-[#1c2028]">
      <div className="flex flex-col">
        {/* Brand Header */}
        <div 
          onClick={() => onSelectTab('security-overview')}
          className="h-20 px-6 flex items-center gap-3 bg-[#181c24]/40 border-b border-[#1c2028] cursor-pointer hover:bg-[#181c24]/70 transition-colors"
        >
          <img 
            alt="PatchPilot Shield Logo" 
            className="h-8 w-auto object-contain" 
            src={LOGO_URL} 
          />
          <div className="flex flex-col">
            <span className="font-headline-sm text-[18px] font-semibold text-[#dfe2ee] tracking-tight leading-none">PatchPilot</span>
            <span className="font-code-sm text-[11px] text-[#c7c4d7] tracking-wider uppercase mt-1">Autonomous Remediation</span>
          </div>
        </div>

        {/* Navigation Items */}
        <div className="px-4 py-3">
          <nav className="flex flex-col gap-1">
            {navItems.map((item) => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  aria-current={isActive ? 'page' : undefined}
                  className={`w-full flex items-center justify-between px-4 py-2.5 rounded-xl transition-all font-label-lg text-[14px] text-left cursor-pointer ${
                    isActive
                      ? 'bg-[#262a33] text-[#c0c1ff] font-bold shadow-sm'
                      : 'text-[#c7c4d7] hover:bg-[#1c2028] hover:text-[#dfe2ee]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`material-symbols-outlined text-[19px] ${isActive ? 'text-[#c0c1ff]' : 'text-[#908fa0]'}`}>
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold leading-tight ${item.badge.className}`}>
                      {item.badge.text}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Bottom Status Section */}
      <div className="flex flex-col gap-2 p-4 bg-[#181c24]/70 border-t border-[#1c2028]">
        {/* Engine status indicator */}
        <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-[#262a33]">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-[#7bd0ff] animate-pulse"></span>
            <span className="font-code-sm text-[11px] text-[#dfe2ee] font-medium">OWASP ZAP v2.14 • Operational</span>
          </div>
          <span className="font-code-sm text-[11px] text-[#7bd0ff] font-bold">LIVE</span>
        </div>

        {/* AI Banner */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0a0e16] text-[#d0bcff] shadow-[0_0_20px_-4px_rgba(139,92,246,0.35)]">
          <span className="material-symbols-outlined text-[16px] text-[#a078ff]">auto_awesome</span>
          <span className="font-code-sm text-[11px] text-[#c7c4d7] truncate">AI Intelligence powered by Gemini</span>
        </div>

        {/* User Card */}
        <div className="flex items-center justify-between pt-1 px-1">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-8 h-8 rounded-full bg-[#c0c1ff] flex items-center justify-center shrink-0 text-[#1000a9] font-bold">
              <span className="material-symbols-outlined text-[18px]">person</span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-label-md text-[12px] text-[#dfe2ee] font-semibold truncate">SecOps Lead</span>
              <span className="font-code-sm text-[11px] text-[#908fa0] truncate">lead@patchpilot.io</span>
            </div>
          </div>
          <div className="w-2 h-2 rounded-full bg-[#7bd0ff] shrink-0" title="Active Session"></div>
        </div>
      </div>
    </aside>
  );
};
