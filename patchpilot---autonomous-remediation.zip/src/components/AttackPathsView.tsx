import React, { useState } from 'react';
import { ATTACK_NODES, ATTACK_PATHS } from '../data/mockData.ts';
import { AttackNode } from '../types/index.ts';
import { NavTab } from './Sidebar.tsx';

interface AttackPathsViewProps {
  onNavigate: (tab: NavTab) => void;
}

export const AttackPathsView: React.FC<AttackPathsViewProps> = ({ onNavigate }) => {
  const [selectedPathId, setSelectedPathId] = useState<'path-1' | 'path-2'>('path-1');
  const [selectedNodeId, setSelectedNodeId] = useState<string>('sqli');
  const [viewMode, setViewMode] = useState<'topology' | 'matrix'>('topology');
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [mitigationSimulated, setMitigationSimulated] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);

  const selectedPath = ATTACK_PATHS.find(p => p.id === selectedPathId) || ATTACK_PATHS[0];
  const selectedNode: AttackNode = ATTACK_NODES[selectedNodeId] || ATTACK_NODES['sqli'];

  const handleSimulateMitigation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setIsSimulating(false);
      setMitigationSimulated(true);
      setTimeout(() => setMitigationSimulated(false), 5000);
    }, 1500);
  };

  const handleExportStix = () => {
    const stixData = {
      type: "bundle",
      id: "bundle--d7a1e0c2-9018-4b7f-8291-382a9f1b942e",
      spec_version: "2.1",
      objects: [
        {
          type: "attack-pattern",
          id: "attack-pattern--cwe-89",
          name: "SQL Injection",
          external_references: [
            { source_name: "cwe", external_id: "CWE-89" },
            { source_name: "mitre-attack", external_id: "T1190" }
          ]
        },
        {
          type: "threat-actor",
          id: "threat-actor--anonymous",
          name: "External Attacker"
        }
      ]
    };
    const blob = new Blob([JSON.stringify(stixData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attack-graph-${selectedPathId}.stix2.json`;
    a.click();
  };

  return (
    <div className="flex flex-col w-full">
      {/* Disclaimer Scrim Notification */}
      <div className="px-6 py-2.5 bg-[#181c24] flex flex-col md:flex-row items-start md:items-center justify-between gap-2 shadow-sm border-b border-[#262a33]">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#a078ff] text-[#340080] font-code-sm text-[11px] font-bold uppercase tracking-wider shrink-0 font-mono">
            <span className="material-symbols-outlined text-[14px]">auto_awesome</span>
            <span>Gemini AI Engine</span>
          </div>
          <p className="font-body-sm text-[12px] text-[#c7c4d7] truncate">
            <strong className="text-[#dfe2ee] font-semibold">AI-Generated Security Hypothesis:</strong> Attack relationships represent AI-assisted correlation of OWASP ZAP telemetry and require human triage.
          </p>
        </div>
        <div className="flex items-center gap-4 shrink-0 font-code-sm text-[11px] font-mono">
          <span className="text-[#d0bcff] flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-[#d0bcff] animate-pulse"></span>
            Model: Gemini 1.5 Pro SecOps Tuning
          </span>
          <span className="text-[#908fa0]">Confidence: 94.8%</span>
        </div>
      </div>

      {/* Primary Header & Telemetry Stat Strip */}
      <div className="px-6 pt-6 pb-4 flex flex-col xl:flex-row xl:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 font-code-sm text-[11px] text-[#c0c1ff] uppercase tracking-wider mb-1 font-mono">
            <span className="material-symbols-outlined text-[16px]">account_tree</span>
            <span>Tactical Threat Modeling // Dynamic Correlation</span>
          </div>
          <h1 className="font-headline-xl text-[30px] md:text-[34px] text-[#dfe2ee] font-bold tracking-tight">
            Potential Attack Paths
          </h1>
          <p className="font-body-md text-[13px] text-[#908fa0] mt-1 max-w-3xl leading-relaxed">
            Understand how discrete vulnerabilities coalesce into systemic kill chains. Correlates runtime ZAP findings, network exposure, and impact blast radiuses.
          </p>
        </div>

        {/* Quick Stats Bento Strip */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="px-4 py-2.5 rounded-xl bg-[#1c2028] flex flex-col shadow-sm border border-[#262a33]">
            <span className="font-code-sm text-[10px] text-[#908fa0] uppercase tracking-wider font-mono">Synthesized Paths</span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="font-headline-md text-[20px] text-[#dfe2ee] font-bold">2</span>
              <span className="font-body-sm text-[12px] text-[#ffb4ab] font-bold font-mono">1 Critical Chain</span>
            </div>
          </div>

          <div className="px-4 py-2.5 rounded-xl bg-[#1c2028] flex flex-col shadow-sm border border-[#262a33]">
            <span className="font-code-sm text-[10px] text-[#908fa0] uppercase tracking-wider font-mono">Chained CVE / CWEs</span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="font-headline-md text-[20px] text-[#dfe2ee] font-bold">4 Nodes</span>
              <span className="font-body-sm text-[12px] text-[#7bd0ff] font-bold font-mono">OWASP Verified</span>
            </div>
          </div>

          <div className="px-4 py-2.5 rounded-xl bg-[#1c2028] flex flex-col shadow-sm border border-[#262a33]">
            <span className="font-code-sm text-[10px] text-[#908fa0] uppercase tracking-wider font-mono">Max Blast Radius</span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="font-headline-md text-[18px] text-[#ffb4ab] font-bold">Database Leak</span>
              <span className="font-code-sm text-[10px] text-[#ffdad6] bg-[#93000a] px-1.5 py-0.2 rounded font-bold font-mono">SOC2 / PII</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Multi-Pane Visual Graph Stage */}
      <div className="px-6 pb-12 grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Left & Center: Interactive Canvas (8 Cols) */}
        <div className="xl:col-span-8 flex flex-col gap-4">
          {/* Graph Command HUD Bar */}
          <div className="p-2.5 rounded-xl bg-[#181c24] flex flex-wrap items-center justify-between gap-3 shadow-sm border border-[#262a33]">
            {/* Path Selectors */}
            <div className="flex items-center gap-2 overflow-x-auto py-0.5">
              <button 
                onClick={() => {
                  setSelectedPathId('path-1');
                  setSelectedNodeId('sqli');
                }}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-lg font-label-md text-[13px] transition-all cursor-pointer ${
                  selectedPathId === 'path-1'
                    ? 'bg-[#31353e] text-[#c0c1ff] font-bold shadow-sm border border-[#c0c1ff]/40'
                    : 'bg-[#1c2028] text-[#c7c4d7] hover:text-[#dfe2ee] hover:bg-[#262a33]'
                }`}
              >
                <span className="h-2 w-2 rounded-full bg-[#ffb4ab] animate-pulse"></span>
                <span>Path #1: SQLi to Database Exfiltration</span>
                <span className="px-1.5 py-0.2 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] font-bold font-mono">CRITICAL</span>
              </button>

              <button 
                onClick={() => {
                  setSelectedPathId('path-2');
                  setSelectedNodeId('broken-access');
                }}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-lg font-label-md text-[13px] transition-all cursor-pointer ${
                  selectedPathId === 'path-2'
                    ? 'bg-[#31353e] text-[#7bd0ff] font-bold shadow-sm border border-[#7bd0ff]/40'
                    : 'bg-[#1c2028] text-[#c7c4d7] hover:text-[#dfe2ee] hover:bg-[#262a33]'
                }`}
              >
                <span className="h-2 w-2 rounded-full bg-[#7bd0ff]"></span>
                <span>Path #2: Auth Bypass to Admin Takeover</span>
                <span className="px-1.5 py-0.2 rounded bg-[#262a33] text-[#7bd0ff] font-code-sm text-[10px] font-mono">HIGH</span>
              </button>
            </div>

            {/* View Controls & Zoom Matrix */}
            <div className="flex items-center gap-2">
              <div className="flex items-center bg-[#1c2028] rounded-lg p-0.5 border border-[#262a33]">
                <button 
                  onClick={() => setViewMode('topology')}
                  className={`px-3 py-1 rounded font-code-sm text-[11px] transition-colors cursor-pointer font-mono ${
                    viewMode === 'topology' ? 'bg-[#353942] text-[#dfe2ee] font-bold shadow-sm' : 'text-[#908fa0] hover:text-[#dfe2ee]'
                  }`}
                >
                  Topology
                </button>
                <button 
                  onClick={() => setViewMode('matrix')}
                  className={`px-3 py-1 rounded font-code-sm text-[11px] transition-colors cursor-pointer font-mono ${
                    viewMode === 'matrix' ? 'bg-[#353942] text-[#dfe2ee] font-bold shadow-sm' : 'text-[#908fa0] hover:text-[#dfe2ee]'
                  }`}
                >
                  Kill Chain Matrix
                </button>
              </div>

              <div className="h-4 w-[1px] bg-[#262a33] mx-1"></div>

              <div className="flex items-center gap-0.5 bg-[#1c2028] rounded-lg p-0.5 border border-[#262a33]">
                <button 
                  onClick={() => setZoomLevel(prev => Math.min(prev + 10, 140))}
                  className="w-7 h-7 flex items-center justify-center rounded text-[#908fa0] hover:bg-[#262a33] hover:text-[#dfe2ee] transition-colors cursor-pointer" 
                  title="Zoom In"
                >
                  <span className="material-symbols-outlined text-[18px]">add</span>
                </button>
                <button 
                  onClick={() => setZoomLevel(prev => Math.max(prev - 10, 70))}
                  className="w-7 h-7 flex items-center justify-center rounded text-[#908fa0] hover:bg-[#262a33] hover:text-[#dfe2ee] transition-colors cursor-pointer" 
                  title="Zoom Out"
                >
                  <span className="material-symbols-outlined text-[18px]">remove</span>
                </button>
                <button 
                  onClick={() => setZoomLevel(100)}
                  className="w-7 h-7 flex items-center justify-center rounded text-[#908fa0] hover:bg-[#262a33] hover:text-[#dfe2ee] transition-colors cursor-pointer" 
                  title="Reset View"
                >
                  <span className="material-symbols-outlined text-[18px]">crop_free</span>
                </button>
              </div>
            </div>
          </div>

          {/* Graph Canvas Container */}
          <div className="relative w-full rounded-xl bg-[#0a0e16] overflow-hidden shadow-2xl min-h-[720px] p-6 flex flex-col justify-between border border-[#262a33]">
            {/* Subtle Ambient Grid Background & AI Radiance */}
            <div className="absolute inset-0 bg-[radial-gradient(#1c2028_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none"></div>
            <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-[#a078ff]/10 blur-[100px] pointer-events-none"></div>
            <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-[#93000a]/15 blur-[120px] pointer-events-none"></div>

            {/* Legend Strip Floating */}
            <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 bg-[#181c24]/85 backdrop-blur-md p-3 rounded-lg shadow-sm border border-[#262a33]">
              <div className="flex items-center gap-4 text-[11px] font-mono">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-[#ffb4ab]"></span>
                  <span className="text-[#c7c4d7]">Active Threat Flow</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-[#7bd0ff]"></span>
                  <span className="text-[#c7c4d7]">Alternate Lateral Branch</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-[#a078ff]"></span>
                  <span className="text-[#c7c4d7]">Target Perimeter Asset</span>
                </div>
              </div>
              <div className="font-code-sm text-[11px] text-[#908fa0] flex items-center gap-1 font-mono">
                <span className="material-symbols-outlined text-[15px] text-[#d0bcff]">touch_app</span>
                <span>Click any node to inspect telemetry evidence</span>
              </div>
            </div>

            {/* Node & Graph Tree Visualization Canvas */}
            <div 
              className="relative z-10 w-full my-6 flex flex-col items-center justify-center transition-transform duration-200"
              style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}
            >
              {/* NODE 1: External Attacker */}
              <div className="w-full max-w-sm flex flex-col items-center">
                <div 
                  onClick={() => setSelectedNodeId('actor')}
                  className={`w-full p-4 rounded-xl shadow-lg transition-all cursor-pointer border ${
                    selectedNodeId === 'actor' 
                      ? 'bg-[#262a33] border-[#ffb4ab] ring-1 ring-[#ffb4ab]/40' 
                      : 'bg-[#181c24] hover:bg-[#262a33] border-[#262a33]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2 text-[#ffb4ab] font-code-sm text-[11px] font-bold uppercase font-mono">
                      <span className="material-symbols-outlined text-[18px]">terminal</span>
                      <span>Threat Actor</span>
                    </div>
                    <span className="px-1.5 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] font-semibold uppercase font-mono">
                      Untrusted
                    </span>
                  </div>
                  <h2 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">External Attacker</h2>
                  <div className="flex items-center justify-between text-[12px] text-[#908fa0] mt-1 font-mono">
                    <span>Public Internet Perimeter</span>
                    <span>Anon IP: 198.51.100.42</span>
                  </div>
                </div>
              </div>

              {/* Connector 1 -> 2 (Vertical Pulsing Laser) */}
              <div className="h-12 w-0.5 bg-gradient-to-b from-[#ffb4ab] to-[#7bd0ff] relative flex items-center justify-center">
                <div className="absolute w-2 h-2 rounded-full bg-[#ffb4ab] animate-ping"></div>
                <span className="material-symbols-outlined text-[14px] text-[#7bd0ff] absolute top-6">keyboard_arrow_down</span>
              </div>

              {/* NODE 2: Public API Gateway */}
              <div className="w-full max-w-md flex flex-col items-center relative">
                <div 
                  onClick={() => setSelectedNodeId('ingress')}
                  className={`w-full p-4 rounded-xl transition-all cursor-pointer shadow-lg border ${
                    selectedNodeId === 'ingress' 
                      ? 'bg-[#262a33] border-[#7bd0ff] ring-1 ring-[#7bd0ff]/40' 
                      : 'bg-[#181c24] hover:bg-[#262a33] border-[#262a33]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2 text-[#7bd0ff] font-code-sm text-[11px] font-bold uppercase font-mono">
                      <span className="material-symbols-outlined text-[18px]">public</span>
                      <span>Ingress Gateway</span>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-[#262a33] text-[#7bd0ff] font-code-sm text-[10px] font-semibold uppercase font-mono border border-[#31353e]">
                      Zero Auth Required
                    </span>
                  </div>
                  <h2 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">
                    Public API Gateway: /api/products/search
                  </h2>
                  <div className="flex items-center justify-between text-[12px] text-[#908fa0] mt-1 font-mono">
                    <span className="text-[#c0c1ff]">GET /api/products/search?q=</span>
                    <span>Nginx Reverse Proxy</span>
                  </div>
                </div>

                {/* Forking Connectors for Split Paths */}
                <div className="w-full flex items-center justify-center relative h-16">
                  <svg className="absolute inset-0 w-full h-16 pointer-events-none" fill="none" viewBox="0 0 448 64">
                    {/* Primary Path Line (Left) */}
                    <path 
                      className={selectedPathId === 'path-1' ? 'animate-pulse' : ''} 
                      d="M 224 0 L 224 20 L 110 20 L 110 64" 
                      stroke="#ffb4ab" 
                      strokeDasharray="4 4" 
                      strokeWidth={selectedPathId === 'path-1' ? "2.5" : "1.5"}
                      opacity={selectedPathId === 'path-1' ? "1" : "0.4"}
                    />
                    {/* Secondary Branch Line (Right) */}
                    <path 
                      className={selectedPathId === 'path-2' ? 'animate-pulse' : ''} 
                      d="M 224 0 L 224 20 L 338 20 L 338 64" 
                      stroke="#7bd0ff" 
                      strokeDasharray="4 4" 
                      strokeWidth={selectedPathId === 'path-2' ? "2.5" : "1.5"}
                      opacity={selectedPathId === 'path-2' ? "1" : "0.4"}
                    />
                  </svg>
                </div>
              </div>

              {/* Split Tier: Left Path (Active SQLi) vs Right Branch (Exploitation Alternative) */}
              <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* LEFT BRANCH: Primary Exploit Sequence (Path 1) */}
                <div className={`flex flex-col items-center transition-opacity ${selectedPathId === 'path-1' ? 'opacity-100' : 'opacity-65'}`}>
                  {/* NODE 3: SQL Injection */}
                  <div 
                    onClick={() => setSelectedNodeId('sqli')}
                    className={`w-full p-4 rounded-xl shadow-2xl relative cursor-pointer transform hover:-translate-y-0.5 transition-all border ${
                      selectedNodeId === 'sqli' 
                        ? 'bg-[#262a33] border-[#ffb4ab] ring-2 ring-[#ffb4ab]/40 shadow-[0_0_24px_rgba(255,180,171,0.25)]' 
                        : 'bg-[#181c24] border-[#262a33]'
                    }`}
                  >
                    <div className="relative z-10 flex flex-col">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1.5 text-[#ffb4ab] font-code-sm text-[11px] font-bold uppercase font-mono">
                          <span className="material-symbols-outlined text-[18px]">bug_report</span>
                          <span>Target Vulnerability</span>
                        </div>
                        <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] font-bold uppercase tracking-wider font-mono">
                          CRITICAL 9.8
                        </span>
                      </div>
                      <div className="flex items-baseline justify-between">
                        <h2 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">SQL Injection Vulnerability</h2>
                        <span className="font-code-sm text-[11px] text-[#c0c1ff] font-mono font-medium">CWE-89</span>
                      </div>
                      <p className="font-body-sm text-[12px] text-[#c7c4d7] mt-1">
                        Unsanitized input string in search parameter executed against Postgres core engine.
                      </p>
                      <div className="mt-3 pt-2 flex items-center justify-between font-code-sm text-[11px] bg-[#1c2028] p-2 rounded-lg border border-[#262a33] font-mono">
                        <span className="text-[#908fa0]">Validated by OWASP ZAP v2.14</span>
                        <span className="text-[#ffb4ab] font-bold flex items-center gap-1">
                          <span className="material-symbols-outlined text-[14px]">verified_user</span>
                          Confirmed PoC
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Connector 3 -> 4 */}
                  <div className="h-10 w-0.5 bg-[#ffb4ab] relative flex items-center justify-center my-0.5">
                    <span className="material-symbols-outlined text-[14px] text-[#ffb4ab] absolute top-3">keyboard_arrow_down</span>
                  </div>

                  {/* NODE 4: PostgreSQL Database Access */}
                  <div 
                    onClick={() => setSelectedNodeId('db-access')}
                    className={`w-full p-4 rounded-xl transition-all cursor-pointer shadow-md border ${
                      selectedNodeId === 'db-access' 
                        ? 'bg-[#262a33] border-[#7bd0ff] ring-1 ring-[#7bd0ff]/40' 
                        : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 text-[#7bd0ff] font-code-sm text-[11px] font-bold uppercase font-mono">
                        <span className="material-symbols-outlined text-[18px]">database</span>
                        <span>Direct Storage Reach</span>
                      </div>
                      <span className="px-1.5 py-0.5 rounded bg-[#93000a]/40 text-[#ffb4ab] font-code-sm text-[10px] font-bold uppercase font-mono">
                        HIGH IMPACT
                      </span>
                    </div>
                    <h2 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">PostgreSQL Database Access</h2>
                    <div className="text-[12px] text-[#c7c4d7] mt-1 font-mono">
                      Escapes web sandbox. Grants execution context as <span className="text-[#c0c1ff] font-bold">app_user</span> role with elevated schema read privileges.
                    </div>
                  </div>

                  {/* Connector 4 -> 5 */}
                  <div className="h-10 w-0.5 bg-[#ffb4ab] relative flex items-center justify-center my-0.5">
                    <span className="material-symbols-outlined text-[14px] text-[#ffb4ab] absolute top-3">keyboard_arrow_down</span>
                  </div>

                  {/* NODE 5: Sensitive Customer Data Exfiltration */}
                  <div 
                    onClick={() => setSelectedNodeId('exfiltration')}
                    className={`w-full p-4 rounded-xl shadow-2xl relative overflow-hidden cursor-pointer border ${
                      selectedNodeId === 'exfiltration' 
                        ? 'bg-[#262a33] border-[#ffb4ab] ring-2 ring-[#ffb4ab]/50' 
                        : 'bg-[#181c24] border-[#262a33]'
                    }`}
                  >
                    <div className="absolute -right-12 -top-12 w-28 h-28 bg-[#93000a]/20 rounded-full blur-xl pointer-events-none"></div>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 text-[#ffb4ab] font-code-sm text-[11px] font-bold uppercase font-mono">
                        <span className="material-symbols-outlined text-[18px]">lock_open</span>
                        <span>Kill Chain Objective Met</span>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] font-bold uppercase tracking-wider font-mono">
                        Breach Complete
                      </span>
                    </div>
                    <h2 className="font-headline-sm text-[16px] text-[#ffb4ab] font-bold">
                      Sensitive Customer Data Exfiltration
                    </h2>
                    <div className="text-[12px] text-[#c7c4d7] mt-1">
                      Extraction of 142,000 hashed client credentials and billing addresses. Direct GDPR, HIPAA, and SOC2 violation.
                    </div>
                  </div>
                </div>

                {/* RIGHT BRANCH: Alternate Exploitation Branch (Path 2) */}
                <div className={`flex flex-col items-center transition-opacity ${selectedPathId === 'path-2' ? 'opacity-100' : 'opacity-65'}`}>
                  {/* Branch Node 1: Broken Access Control */}
                  <div 
                    onClick={() => setSelectedNodeId('broken-access')}
                    className={`w-full p-4 rounded-xl transition-all cursor-pointer shadow-md border ${
                      selectedNodeId === 'broken-access' 
                        ? 'bg-[#262a33] border-[#7bd0ff] ring-1 ring-[#7bd0ff]/40' 
                        : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 text-[#7bd0ff] font-code-sm text-[11px] font-bold uppercase font-mono">
                        <span className="material-symbols-outlined text-[18px]">lock_reset</span>
                        <span>Secondary Path</span>
                      </div>
                      <span className="px-1.5 py-0.5 rounded bg-[#262a33] text-[#7bd0ff] font-code-sm text-[10px] font-semibold font-mono border border-[#31353e]">
                        CWE-284
                      </span>
                    </div>
                    <h2 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">Broken Access Control on /api/users</h2>
                    <div className="text-[12px] text-[#c7c4d7] mt-1">
                      IDOR susceptibility allowing unauthorized enumeration of user IDs and associated role claim payloads.
                    </div>
                  </div>

                  {/* Connector */}
                  <div className="h-10 w-0.5 bg-[#7bd0ff]/50 relative flex items-center justify-center my-0.5">
                    <span className="material-symbols-outlined text-[14px] text-[#7bd0ff] absolute top-3">keyboard_arrow_down</span>
                  </div>

                  {/* Branch Node 2: Session Hijacking */}
                  <div 
                    onClick={() => setSelectedNodeId('session-hijack')}
                    className={`w-full p-4 rounded-xl transition-all cursor-pointer shadow-md border ${
                      selectedNodeId === 'session-hijack' 
                        ? 'bg-[#262a33] border-[#7bd0ff] ring-1 ring-[#7bd0ff]/40' 
                        : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 text-[#7bd0ff] font-code-sm text-[11px] font-bold uppercase font-mono">
                        <span className="material-symbols-outlined text-[18px]">badge</span>
                        <span>Identity Vector</span>
                      </div>
                      <span className="px-1.5 py-0.5 rounded bg-[#262a33] text-[#7bd0ff] font-code-sm text-[10px] font-mono border border-[#31353e]">
                        HIGH RISK
                      </span>
                    </div>
                    <h2 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">User Session Hijacking</h2>
                    <div className="text-[12px] text-[#c7c4d7] mt-1">
                      Predictable JWT generation pattern leaks valid session tokens during unauthorized reset invocations.
                    </div>
                  </div>

                  {/* Connector */}
                  <div className="h-10 w-0.5 bg-[#7bd0ff]/50 relative flex items-center justify-center my-0.5">
                    <span className="material-symbols-outlined text-[14px] text-[#7bd0ff] absolute top-3">keyboard_arrow_down</span>
                  </div>

                  {/* Branch Node 3: Privilege Escalation */}
                  <div 
                    onClick={() => setSelectedNodeId('admin-takeover')}
                    className={`w-full p-4 rounded-xl shadow-md cursor-pointer border ${
                      selectedNodeId === 'admin-takeover' 
                        ? 'bg-[#262a33] border-[#ffb4ab] ring-2 ring-[#ffb4ab]/40' 
                        : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 text-[#7bd0ff] font-code-sm text-[11px] font-bold uppercase font-mono">
                        <span className="material-symbols-outlined text-[18px]">admin_panel_settings</span>
                        <span>Admin Takeover</span>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] font-bold uppercase font-mono">
                        System Hijack
                      </span>
                    </div>
                    <h2 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">Admin Privilege Escalation</h2>
                    <div className="text-[12px] text-[#c7c4d7] mt-1">
                      Actor acquires full cluster administrative scope and changes security policies across tenant services.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Canvas Bottom Status Ticker */}
            <div className="relative z-10 pt-4 flex flex-col sm:flex-row items-center justify-between gap-3 font-code-sm text-[11px] text-[#908fa0] border-t border-[#262a33] font-mono">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] text-[#7bd0ff]">memory</span>
                <span>Graph Renderer: PatchPilot Neural Topology Engine v4.2</span>
              </div>
              <div className="flex items-center gap-4">
                <span>Nodes: 8</span>
                <span>Correlations: 11 edges</span>
                <span className="text-[#c0c1ff]">Click any node to inspect</span>
              </div>
            </div>
          </div>

          {/* Tactical Kill-Chain Timeline Progression (Mitre Matrix View) */}
          <div className="p-6 rounded-xl bg-[#181c24] shadow-md border border-[#262a33] flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[20px] text-[#c0c1ff]">timeline</span>
                <h3 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">
                  Attacker Progression Timeline ({selectedPath.title.split(':')[0]})
                </h3>
              </div>
              <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">
                Estimated TTP Execution: {selectedPath.estimatedTtp}
              </span>
            </div>

            {/* 5-Step Horizontal Sequence */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 pt-1">
              {selectedPath.timeline.map((step, idx) => (
                <div 
                  key={idx}
                  className={`p-3 rounded-lg flex flex-col justify-between border ${
                    step.active 
                      ? 'bg-[#262a33] border-[#c0c1ff] shadow-sm' 
                      : 'bg-[#1c2028] border-[#262a33]'
                  }`}
                >
                  <div>
                    <span className={`font-code-sm text-[10px] font-bold font-mono ${step.active ? 'text-[#c0c1ff]' : 'text-[#908fa0]'}`}>
                      {step.phase} {step.active ? '[ACTIVE]' : ''}
                    </span>
                    <p className="font-label-md text-[13px] text-[#dfe2ee] mt-1 font-semibold leading-tight">{step.title}</p>
                    <p className="font-body-sm text-[11px] text-[#908fa0] mt-1 leading-snug">{step.description}</p>
                  </div>
                  <span className={`font-code-sm text-[10px] mt-3 uppercase font-mono font-bold ${
                    step.severity === 'critical' ? 'text-[#ffb4ab]' :
                    step.severity === 'high' ? 'text-[#ffb4ab]' : 'text-[#7bd0ff]'
                  }`}>
                    {step.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Panel: Path Detail & Node Deep Dive (4 Cols) */}
        <div className="xl:col-span-4 flex flex-col gap-4">
          {/* Selected Node Detail Card */}
          <div className="rounded-xl bg-[#181c24] shadow-xl overflow-hidden border border-[#262a33]">
            {/* Header Banner */}
            <div className="p-4 bg-[#262a33] border-b border-[#31353e] flex flex-col gap-1">
              <div className="flex items-center justify-between">
                <span className="font-code-sm text-[11px] text-[#ffb4ab] font-bold uppercase tracking-wider flex items-center gap-1.5 font-mono">
                  <span className="h-2 w-2 rounded-full bg-[#ffb4ab] animate-pulse"></span>
                  Selected Node Analysis
                </span>
                <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] font-bold font-mono">
                  {selectedNode.severity ? selectedNode.severity.toUpperCase() : 'ASSET'}
                </span>
              </div>
              <h2 className="font-headline-md text-[20px] text-[#dfe2ee] font-bold tracking-tight">
                {selectedNode.title}
              </h2>
              <div className="flex items-center gap-2 font-code-sm text-[11px] text-[#908fa0] font-mono">
                <span>{selectedNode.cwe || 'INFRA'}</span>
                <span>•</span>
                <span className="text-[#c0c1ff]">OWASP Top 10</span>
                <span>•</span>
                <span>CVSS {selectedNode.cvss || 9.8}</span>
              </div>
            </div>

            <div className="p-4 flex flex-col gap-4">
              {/* Key Meta Data Grid */}
              <div className="grid grid-cols-2 gap-3 bg-[#0a0e16] p-3 rounded-lg border border-[#262a33] font-mono text-[11px]">
                <div>
                  <span className="text-[#908fa0] uppercase text-[10px]">Endpoint Target</span>
                  <p className="text-[#dfe2ee] font-medium truncate mt-0.5">{selectedNode.endpoint || '/api/products/search'}</p>
                </div>
                <div>
                  <span className="text-[#908fa0] uppercase text-[10px]">HTTP Method</span>
                  <p className="text-[#7bd0ff] font-bold mt-0.5">{selectedNode.method || 'GET'}</p>
                </div>
                <div>
                  <span className="text-[#908fa0] uppercase text-[10px]">Injection Param</span>
                  <p className="text-[#ffb4ab] font-mono mt-0.5">q</p>
                </div>
                <div>
                  <span className="text-[#908fa0] uppercase text-[10px]">Detector Engine</span>
                  <p className="text-[#dfe2ee] mt-0.5">OWASP ZAP v2.14</p>
                </div>
              </div>

              {/* Evidence Summary Box */}
              <div className="flex flex-col gap-1.5">
                <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-[#c0c1ff]">fact_check</span>
                  Evidence Summary & Scanner Verification
                </span>
                <div className="p-3 rounded-lg bg-[#0a0e16] font-code-sm text-[11px] text-[#c7c4d7] leading-relaxed overflow-x-auto border border-[#262a33] font-mono">
                  <span className="text-[#ffb4ab] font-medium">PostgreSQL syntax error returned</span> via query parameter <code className="text-[#c0c1ff] font-bold">"q"</code>. Scanner proof confirmed boolean-based blind response alteration:
                  <div className="mt-2 text-[#dfe2ee] bg-[#262a33] p-2 rounded text-[11px] leading-tight select-all border border-[#31353e]">
                    {selectedNode.scannerProof || "Payload: ' UNION SELECT null, username, password_hash FROM users--"}
                  </div>
                </div>
              </div>

              {/* Why It Contributes to Path */}
              <div className="flex flex-col gap-1.5">
                <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-[#d0bcff]">hub</span>
                  Why It Contributes to This Attack Path
                </span>
                <p className="font-body-sm text-[12px] text-[#c7c4d7] leading-relaxed bg-[#1c2028] p-3 rounded-lg border border-[#262a33]">
                  {selectedNode.whyContributes || "The unauthenticated search endpoint allows arbitrary SQL query execution, granting direct read access to underlying customer tables without requiring API tokens. This completely bypasses the perimeter firewall."}
                </p>
              </div>

              {/* MITRE ATT&CK Chain Mapping */}
              <div className="flex flex-col gap-1.5">
                <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-[#7bd0ff]">shield</span>
                  MITRE ATT&CK Matrix Mapping
                </span>
                <div className="flex flex-col gap-1.5 font-mono text-[11px]">
                  {(selectedNode.mitreTechniques || [
                    { code: "T1190", name: "Exploit Public-Facing App", tactic: "Initial Access" },
                    { code: "T1059", name: "Command & Script Interpreter", tactic: "Execution" },
                    { code: "T1530", name: "Data from Cloud Storage", tactic: "Exfiltration" }
                  ]).map((t: { code: string; name: string; tactic: string }, i: number) => (
                    <div key={i} className="flex items-center justify-between p-2 rounded bg-[#1c2028] border border-[#262a33]">
                      <span className="text-[#dfe2ee]">{t.code}: {t.name}</span>
                      <span className="text-[#c0c1ff] font-bold">{t.tactic}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* AI Recommended Mitigation */}
              <div className="p-3.5 rounded-xl bg-gradient-to-br from-[#a078ff]/15 via-[#262a33] to-[#1c2028] shadow-md flex flex-col gap-2 border border-[#a078ff]/30">
                <div className="flex items-center gap-1.5 text-[#d0bcff] font-code-sm text-[11px] font-bold uppercase font-mono">
                  <span className="material-symbols-outlined text-[16px]">auto_awesome</span>
                  <span>Gemini Recommended Mitigation</span>
                </div>
                <p className="font-body-sm text-[12px] text-[#dfe2ee] leading-snug">
                  Enforce parameterized prepared statements in DB queries and deploy strict gateway input sanitation rules.
                </p>
                <div className="mt-1 p-2 rounded bg-[#0a0e16] font-code-sm text-[11px] text-[#c7c4d7] font-mono border border-[#262a33]">
                  <span className="text-[#ffb4ab] line-through">- db.query(`SELECT * FROM p WHERE q = '${`\${req.query.q}`}'`)</span><br />
                  <span className="text-[#7bd0ff]">+ db.query('SELECT * FROM p WHERE q = $1', [req.query.q])</span>
                </div>
              </div>

              {/* Action CTAs */}
              <div className="flex flex-col gap-2 pt-1">
                <button 
                  onClick={handleSimulateMitigation}
                  disabled={isSimulating}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-md text-[13px] hover:bg-[#e1e0ff] transition-colors shadow-sm font-bold cursor-pointer disabled:opacity-75"
                >
                  <span className={`material-symbols-outlined text-[18px] ${isSimulating ? 'animate-spin' : ''}`}>
                    {isSimulating ? 'refresh' : 'build_circle'}
                  </span>
                  <span>{isSimulating ? 'Running Neural Simulation...' : mitigationSimulated ? 'Simulation: Kill-Chain Severed (100% Blocked)' : 'Simulate Path Mitigation'}</span>
                </button>
                <button 
                  onClick={() => onNavigate('remediation-center')}
                  className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-lg bg-[#262a33] text-[#dfe2ee] font-label-md text-[13px] hover:bg-[#31353e] transition-colors shadow-sm border border-[#31353e] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">open_in_new</span>
                  <span>Open Remediation Center</span>
                </button>
              </div>
            </div>
          </div>

          {/* Export Attack Graph */}
          <div className="p-4 rounded-xl bg-[#181c24] shadow-sm flex items-center justify-between border border-[#262a33]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#262a33] flex items-center justify-center text-[#7bd0ff] border border-[#31353e]">
                <span className="material-symbols-outlined text-[22px]">verified</span>
              </div>
              <div className="flex flex-col">
                <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold">Export Attack Graph</span>
                <span className="font-body-sm text-[11px] text-[#908fa0]">Compatible with STIX 2.1 & CybOX JSON</span>
              </div>
            </div>
            <button 
              onClick={handleExportStix}
              className="p-2 rounded-lg bg-[#1c2028] text-[#c7c4d7] hover:text-[#dfe2ee] hover:bg-[#262a33] transition-colors border border-[#262a33] cursor-pointer" 
              title="Download STIX"
            >
              <span className="material-symbols-outlined text-[20px]">download</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
