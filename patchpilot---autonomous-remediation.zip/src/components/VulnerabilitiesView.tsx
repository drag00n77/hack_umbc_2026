import React, { useState } from 'react';
import { VULNERABILITIES } from '../data/mockData.ts';
import { Vulnerability } from '../types/index.ts';
import { NavTab } from './Sidebar.tsx';

interface VulnerabilitiesViewProps {
  onNavigate: (tab: NavTab) => void;
}

export const VulnerabilitiesView: React.FC<VulnerabilitiesViewProps> = ({ onNavigate }) => {
  const [selectedVuln, setSelectedVuln] = useState<Vulnerability>(VULNERABILITIES[0]);
  const [detailTab, setDetailTab] = useState<'overview' | 'zap' | 'ai' | 'remediation' | 'verification'>('zap');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedPayload, setCopiedPayload] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);
  const [pocGenerated, setPocGenerated] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const filteredVulns = VULNERABILITIES.filter(v => {
    const matchesFilter = filterSeverity === 'all' || v.severity === filterSeverity;
    const matchesSearch = v.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          v.endpoint.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          v.cwe.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const handleCopyPayload = () => {
    navigator.clipboard.writeText(selectedVuln.payload || "' OR '1'='1' --");
    setCopiedPayload(true);
    setTimeout(() => setCopiedPayload(false), 2000);
  };

  const handleExportCsv = () => {
    const headers = "ID,Name,CWE,Severity,CVSS,Endpoint,Method,Status\n";
    const rows = VULNERABILITIES.map(v => 
      `"${v.id}","${v.name}","${v.cwe}","${v.severity}",${v.cvss},"${v.endpoint}","${v.method}","${v.status}"`
    ).join("\n");
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `patchpilot-vulnerabilities-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  const handleGeneratePoc = () => {
    setPocGenerated(true);
    setTimeout(() => setPocGenerated(false), 3000);
  };

  return (
    <div className="flex flex-col w-full">
      {/* Sub-Header / Workspace Context */}
      <div className="px-6 py-4 bg-[#0a0e16]/80 backdrop-blur-md flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1c2028]">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-3">
            <span className="font-headline-lg text-[24px] text-[#dfe2ee] font-semibold tracking-tight">Vulnerabilities</span>
            <span className="px-2.5 py-0.5 rounded-full bg-[#93000a] text-[#ffdad6] font-code-sm text-[11px] font-bold tracking-wide font-mono">
              22 ACTIVE FINDINGS
            </span>
            <span className="hidden sm:inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#262a33] font-code-sm text-[11px] text-[#7bd0ff] font-mono">
              <span className="h-1.5 w-1.5 rounded-full bg-[#7bd0ff] animate-pulse"></span>
              ZAP CORE 2.14.0 SYNCED
            </span>
          </div>
          <p className="font-body-md text-[13px] text-[#908fa0]">
            Investigate security findings identified by OWASP ZAP v2.14 deep engine inspection.
          </p>
        </div>

        {/* Quick Stats Ticker */}
        <div className="flex items-center gap-3 self-start md:self-auto">
          <div className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-[#262a33] border border-[#31353e]">
            <span className="material-symbols-outlined text-[18px] text-[#ffb4ab]">dangerous</span>
            <div className="flex flex-col">
              <span className="font-code-sm text-[10px] text-[#908fa0] uppercase leading-none font-mono">Max Risk</span>
              <span className="font-headline-sm text-[16px] text-[#ffb4ab] font-bold leading-tight font-mono">CVSS 9.8</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-[#262a33] border border-[#31353e]">
            <span className="material-symbols-outlined text-[18px] text-[#d0bcff]">bolt</span>
            <div className="flex flex-col">
              <span className="font-code-sm text-[10px] text-[#908fa0] uppercase leading-none font-mono">AI Auto-Fix</span>
              <span className="font-headline-sm text-[16px] text-[#d0bcff] font-bold leading-tight font-mono">3 Ready</span>
            </div>
          </div>

          <button 
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#c0c1ff] text-[#1000a9] font-label-md text-[13px] font-bold hover:bg-[#e1e0ff] transition-colors shadow-md cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">publish</span>
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Primary Analyst Filter Bar */}
      <div className="px-6 py-4 bg-[#181c24]/60 flex flex-col xl:flex-row gap-4 items-stretch xl:items-center justify-between border-b border-[#1c2028]">
        {/* Search and Query Input */}
        <div className="flex-1 flex items-center gap-3 min-w-0">
          <div className="relative w-full max-w-xl flex items-center">
            <span className="material-symbols-outlined text-[#908fa0] absolute left-3 pointer-events-none text-[20px]">search</span>
            <input 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#0a0e16] text-[#dfe2ee] font-body-md text-[13px] pl-10 pr-16 py-2 rounded-xl placeholder:text-[#908fa0]/70 focus:outline-none focus:bg-[#1c2028] shadow-inner border border-[#262a33]" 
              placeholder="Search vulnerability name, endpoint, CWE, parameter..." 
              type="text" 
            />
            <div className="absolute right-2.5 flex items-center gap-1 pointer-events-none">
              <kbd className="px-1.5 py-0.5 rounded bg-[#262a33] text-[#908fa0] font-code-sm text-[11px] uppercase font-mono">⌘K</kbd>
            </div>
          </div>

          {/* Status Filter */}
          <div className="relative hidden sm:block">
            <button className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#262a33] text-[#dfe2ee] font-label-md text-[12px] hover:bg-[#31353e] transition-colors border border-[#31353e] cursor-pointer">
              <span className="material-symbols-outlined text-[16px] text-[#908fa0]">tune</span>
              <span>Status: Open (16)</span>
              <span className="material-symbols-outlined text-[16px] text-[#908fa0]">expand_more</span>
            </button>
          </div>
        </div>

        {/* Severity Pills & Sort */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center p-1 rounded-xl bg-[#0a0e16] shadow-inner gap-1 border border-[#262a33]">
            <button 
              onClick={() => setFilterSeverity('all')}
              className={`px-3 py-1 rounded-lg font-label-md text-[12px] transition-colors cursor-pointer ${
                filterSeverity === 'all' ? 'bg-[#262a33] text-[#dfe2ee] font-semibold' : 'text-[#908fa0] hover:text-[#dfe2ee]'
              }`}
            >
              All <span className="ml-1 text-[#908fa0] font-mono text-[11px]">22</span>
            </button>
            <button 
              onClick={() => setFilterSeverity('critical')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-[#ffb4ab] transition-colors cursor-pointer ${
                filterSeverity === 'critical' ? 'bg-[#93000a]/50 font-bold' : 'hover:bg-[#93000a]/20'
              }`}
            >
              <span className="h-2 w-2 rounded-full bg-[#ffb4ab]"></span>
              <span className="font-label-md text-[12px]">Critical</span>
              <span className="font-mono text-[11px] opacity-80">2</span>
            </button>
            <button 
              onClick={() => setFilterSeverity('high')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-[#7bd0ff] transition-colors cursor-pointer ${
                filterSeverity === 'high' ? 'bg-[#00a6e0]/30 font-bold' : 'hover:bg-[#00a6e0]/15'
              }`}
            >
              <span className="h-2 w-2 rounded-full bg-[#7bd0ff]"></span>
              <span className="font-label-md text-[12px]">High</span>
              <span className="font-mono text-[11px] opacity-80">4</span>
            </button>
            <button 
              onClick={() => setFilterSeverity('medium')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-[#d0bcff] transition-colors cursor-pointer ${
                filterSeverity === 'medium' ? 'bg-[#a078ff]/30 font-bold' : 'hover:bg-[#a078ff]/15'
              }`}
            >
              <span className="h-2 w-2 rounded-full bg-[#d0bcff]"></span>
              <span className="font-label-md text-[12px]">Medium</span>
              <span className="font-mono text-[11px] opacity-80">7</span>
            </button>
            <button 
              onClick={() => setFilterSeverity('low')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-[#908fa0] transition-colors cursor-pointer ${
                filterSeverity === 'low' ? 'bg-[#262a33] font-bold text-[#dfe2ee]' : 'hover:bg-[#1c2028]'
              }`}
            >
              <span className="h-2 w-2 rounded-full bg-[#908fa0]"></span>
              <span className="font-label-md text-[12px]">Low</span>
              <span className="font-mono text-[11px] opacity-80">9</span>
            </button>
          </div>

          {/* Sort Selection */}
          <div className="flex items-center gap-1.5 bg-[#262a33] px-3 py-1.5 rounded-xl border border-[#31353e]">
            <span className="material-symbols-outlined text-[16px] text-[#908fa0]">sort</span>
            <span className="font-code-sm text-[11px] text-[#908fa0] uppercase font-mono">Sort:</span>
            <span className="font-label-md text-[12px] text-[#c0c1ff] font-semibold cursor-pointer">Priority (Urgency)</span>
          </div>
        </div>
      </div>

      {/* Primary Workspace Split: Table (58%) vs Detail Drawer (42%) */}
      <div className="px-6 py-6 flex flex-col 2xl:flex-row gap-6 w-full items-start">
        {/* LEFT PANE: 58% Width Data Table Container */}
        <div className="w-full 2xl:w-[58%] flex flex-col gap-3">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[16px] text-[#c0c1ff]">view_timeline</span>
              <span className="font-code-sm text-[11px] uppercase tracking-wider text-[#908fa0] font-semibold font-mono">
                Triage Queue (Sorted by Exploitation Likelihood)
              </span>
            </div>
            <div className="flex items-center gap-2 text-[#908fa0] font-code-sm text-[11px] font-mono">
              <span>Showing {filteredVulns.length} of 22 items</span>
              <span className="h-1 w-1 rounded-full bg-[#908fa0]"></span>
              <span>Target Host: 127.0.0.1:3000</span>
            </div>
          </div>

          {/* Table Card Wrapper */}
          <div className="w-full bg-[#181c24] rounded-xl shadow-xl overflow-hidden border border-[#262a33]">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#0a0e16] text-[#908fa0] font-code-sm text-[11px] uppercase tracking-wider select-none font-mono border-b border-[#262a33]">
                    <th className="py-3 px-4 font-semibold w-16">Prio</th>
                    <th className="py-3 px-4 font-semibold">Finding Name</th>
                    <th className="py-3 px-4 font-semibold w-24">Severity</th>
                    <th className="py-3 px-4 font-semibold">Target Endpoint</th>
                    <th className="py-3 px-4 font-semibold hidden lg:table-cell">Confidence</th>
                    <th className="py-3 px-4 font-semibold">Status</th>
                    <th className="py-3 px-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#262a33] text-[13px] font-body-md">
                  {filteredVulns.map((vuln) => {
                    const isSelected = selectedVuln.id === vuln.id;
                    const borderLeftColor = 
                      vuln.severity === 'critical' ? '#ffb4ab' :
                      vuln.severity === 'high' ? '#7bd0ff' :
                      vuln.severity === 'medium' ? '#d0bcff' : '#908fa0';

                    return (
                      <tr 
                        key={vuln.id}
                        onClick={() => setSelectedVuln(vuln)}
                        className={`group relative cursor-pointer transition-colors ${
                          isSelected 
                            ? 'bg-[#262a33] shadow-[inset_4px_0_0_0]' 
                            : 'hover:bg-[#1c2028]'
                        }`}
                        style={{
                          boxShadow: isSelected ? `inset 4px 0 0 0 ${borderLeftColor}` : undefined
                        }}
                      >
                        <td className="py-3.5 px-4 font-code-sm text-[11px] font-bold font-mono">
                          <span className={`px-1.5 py-0.5 rounded ${
                            vuln.severity === 'critical' ? 'bg-[#93000a]/40 text-[#ffb4ab]' : 'bg-[#31353e] text-[#c7c4d7]'
                          }`}>
                            #{vuln.priority}
                          </span>
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="flex flex-col min-w-0">
                            <span className="font-label-lg text-[13px] font-bold text-[#dfe2ee] group-hover:text-[#c0c1ff] transition-colors flex items-center gap-1.5">
                              {vuln.name}
                              {vuln.severity === 'critical' && (
                                <span className="material-symbols-outlined text-[14px] text-[#d0bcff]" title="AI Exploit Vector mapped">smart_toy</span>
                              )}
                            </span>
                            <span className="font-code-sm text-[11px] text-[#908fa0] truncate font-mono">
                              {vuln.cwe} • {vuln.category}
                            </span>
                          </div>
                        </td>

                        <td className="py-3.5 px-4">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded font-code-sm text-[10px] font-bold uppercase tracking-wider font-mono ${
                            vuln.severity === 'critical' ? 'bg-[#93000a] text-[#ffdad6]' :
                            vuln.severity === 'high' ? 'bg-[#00a6e0]/30 text-[#7bd0ff]' :
                            vuln.severity === 'medium' ? 'bg-[#a078ff]/30 text-[#d0bcff]' : 'bg-[#31353e] text-[#908fa0]'
                          }`}>
                            {vuln.severity.toUpperCase()}
                          </span>
                        </td>

                        <td className="py-3.5 px-4">
                          <span className="font-code-sm text-[11px] font-medium text-[#7bd0ff] truncate block max-w-[190px] font-mono">
                            {vuln.endpoint}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 hidden lg:table-cell">
                          <div className="flex items-center gap-1.5 text-[#c7c4d7] font-code-sm text-[11px] font-mono">
                            <span className="h-2 w-2 rounded-full bg-[#7bd0ff]"></span>
                            <span>{vuln.confidence}% ({vuln.scanner.split(' ')[0]})</span>
                          </div>
                        </td>

                        <td className="py-3.5 px-4">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-code-sm text-[10px] font-semibold font-mono ${
                            vuln.status === 'Open' ? 'bg-[#93000a]/20 text-[#ffb4ab]' :
                            vuln.status === 'Remediated' ? 'bg-[#00a6e0]/20 text-[#7bd0ff]' : 'bg-[#262a33] text-[#c7c4d7]'
                          }`}>
                            <span className="h-1.5 w-1.5 rounded-full bg-current"></span>
                            {vuln.status}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <button 
                            className="px-2.5 py-1 rounded bg-[#31353e] hover:bg-[#c0c1ff] hover:text-[#1000a9] text-[#dfe2ee] font-label-md text-[12px] font-semibold transition-colors cursor-pointer"
                          >
                            Inspect
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Table Pagination Footer */}
            <div className="px-4 py-3 bg-[#0a0e16] flex items-center justify-between border-t border-[#262a33]">
              <div className="flex items-center gap-2 text-[#908fa0] font-code-sm text-[11px] font-mono">
                <span>Showing rows 1 - {filteredVulns.length} of 22</span>
              </div>
              <div className="flex items-center gap-1 font-mono">
                <button 
                  disabled={currentPage === 1}
                  className="px-2.5 py-1 rounded bg-[#262a33] text-[#dfe2ee] font-code-sm text-[11px] disabled:opacity-40 cursor-pointer"
                >
                  Previous
                </button>
                <span className="px-2.5 py-1 rounded bg-[#c0c1ff] text-[#1000a9] font-code-sm text-[11px] font-bold">1</span>
                <button className="px-2.5 py-1 rounded bg-[#1c2028] text-[#c7c4d7] font-code-sm text-[11px] hover:bg-[#262a33] cursor-pointer">2</button>
                <button className="px-2.5 py-1 rounded bg-[#1c2028] text-[#c7c4d7] font-code-sm text-[11px] hover:bg-[#262a33] cursor-pointer">3</button>
                <button className="px-2.5 py-1 rounded bg-[#262a33] text-[#dfe2ee] font-code-sm text-[11px] hover:bg-[#31353e] cursor-pointer">Next</button>
              </div>
            </div>
          </div>

          {/* Telemetry Vector Visualization Mini-card */}
          <div className="w-full p-4 rounded-xl bg-[#181c24] shadow-sm border border-[#262a33] flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#262a33] flex items-center justify-center shrink-0 border border-[#31353e]">
                <svg className="w-8 h-8 text-[#7bd0ff]" fill="none" viewBox="0 0 36 36">
                  <path d="M18 2L32 10V26L18 34L4 26V10L18 2Z" fill="none" stroke="currentColor" strokeOpacity="0.3" strokeWidth="2" />
                  <path d="M18 7L28 13V23L18 29L8 23V13L18 7Z" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="1.5" />
                  <circle cx="18" cy="18" fill="currentColor" r="2.5" />
                </svg>
              </div>
              <div className="flex flex-col">
                <span className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">Active Attack Surface Exposure</span>
                <span className="font-body-sm text-[12px] text-[#908fa0]">OWASP ZAP 2.14 verified 43 API endpoints across 14 controller modules in current target scan session.</span>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <div className="flex flex-col items-end">
                <span className="font-code-sm text-[11px] text-[#908fa0] uppercase font-semibold font-mono">Risk Density</span>
                <span className="font-headline-sm text-[18px] text-[#ffb4ab] font-bold font-mono">High (0.84)</span>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT PANE: 42% Width Vulnerability Detail Drawer (Selected Finding) */}
        <div className="w-full 2xl:w-[42%] flex flex-col gap-4 bg-[#181c24] rounded-2xl shadow-2xl p-6 relative overflow-hidden border border-[#262a33]">
          {/* Top Glowing Gradient Bar */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#ffb4ab] via-[#a078ff] to-[#7bd0ff]"></div>

          {/* Drawer Header */}
          <div className="flex flex-col gap-2 pt-1">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[11px] font-bold uppercase tracking-wider font-mono">
                  {selectedVuln.severity.toUpperCase()} #{selectedVuln.priority}
                </span>
                <span className="px-2 py-0.5 rounded bg-[#262a33] text-[#dfe2ee] font-code-sm text-[11px] font-medium font-mono border border-[#31353e]">
                  CVSS {selectedVuln.cvss}
                </span>
                <span className="px-2 py-0.5 rounded bg-[#00a6e0]/20 text-[#7bd0ff] font-code-sm text-[11px] font-semibold flex items-center gap-1 font-mono">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#7bd0ff]"></span>
                  {selectedVuln.status} Finding
                </span>
              </div>

              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setBookmarked(!bookmarked)}
                  className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                    bookmarked ? 'bg-[#c0c1ff] text-[#1000a9] border-[#c0c1ff]' : 'bg-[#1c2028] text-[#c7c4d7] hover:text-[#dfe2ee] border-[#262a33]'
                  }`}
                  title="Bookmark Finding"
                >
                  <span className="material-symbols-outlined text-[18px]">bookmark</span>
                </button>
                <button 
                  onClick={() => onNavigate('attack-paths')}
                  className="p-1.5 rounded-lg bg-[#1c2028] hover:bg-[#262a33] text-[#c7c4d7] hover:text-[#dfe2ee] transition-colors border border-[#262a33] cursor-pointer" 
                  title="Open Attack Graph"
                >
                  <span className="material-symbols-outlined text-[18px]">route</span>
                </button>
              </div>
            </div>

            <div className="flex flex-col">
              <h2 className="font-headline-md text-[20px] text-[#dfe2ee] font-bold tracking-tight">
                {selectedVuln.name} in Query Parameter
              </h2>
              <div className="flex items-center gap-2 mt-1 text-[#7bd0ff] font-code-md text-[12px] font-medium break-all font-mono">
                <span className="material-symbols-outlined text-[16px]">terminal</span>
                <span>{selectedVuln.method} {selectedVuln.endpoint}?q=</span>
              </div>
            </div>
          </div>

          {/* Navigation Tabs in Detail Drawer */}
          <div className="flex items-center gap-1 overflow-x-auto bg-[#0a0e16] p-1 rounded-xl shadow-inner border border-[#262a33] select-none">
            <button 
              onClick={() => setDetailTab('overview')}
              className={`px-3 py-1.5 rounded-lg font-label-md text-[12px] transition-colors cursor-pointer ${
                detailTab === 'overview' ? 'bg-[#262a33] text-[#dfe2ee] font-bold' : 'text-[#908fa0] hover:text-[#dfe2ee]'
              }`}
            >
              Overview
            </button>
            <button 
              onClick={() => setDetailTab('zap')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-label-md text-[12px] transition-colors cursor-pointer ${
                detailTab === 'zap' ? 'bg-[#262a33] text-[#c0c1ff] font-bold shadow-sm' : 'text-[#908fa0] hover:text-[#dfe2ee]'
              }`}
            >
              <span className="material-symbols-outlined text-[14px]">policy</span>
              <span>ZAP Evidence</span>
            </button>
            <button 
              onClick={() => setDetailTab('ai')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-label-md text-[12px] transition-colors cursor-pointer ${
                detailTab === 'ai' ? 'bg-[#a078ff]/30 text-[#d0bcff] font-bold' : 'text-[#d0bcff] hover:bg-[#a078ff]/20'
              }`}
            >
              <span className="material-symbols-outlined text-[14px]">smart_toy</span>
              <span>AI Analysis</span>
            </button>
            <button 
              onClick={() => setDetailTab('remediation')}
              className={`px-3 py-1.5 rounded-lg font-label-md text-[12px] transition-colors cursor-pointer ${
                detailTab === 'remediation' ? 'bg-[#262a33] text-[#dfe2ee] font-bold' : 'text-[#908fa0] hover:text-[#dfe2ee]'
              }`}
            >
              Remediation
            </button>
            <button 
              onClick={() => setDetailTab('verification')}
              className={`px-3 py-1.5 rounded-lg font-label-md text-[12px] transition-colors cursor-pointer ${
                detailTab === 'verification' ? 'bg-[#262a33] text-[#dfe2ee] font-bold' : 'text-[#908fa0] hover:text-[#dfe2ee]'
              }`}
            >
              Verification
            </button>
          </div>

          {/* ACTIVE TAB CONTENT: OWASP ZAP Raw Forensic Evidence */}
          {detailTab === 'zap' && (
            <div className="flex flex-col gap-4 animate-fadeIn">
              {/* Ground Truth Scanner Proof Badge */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#262a33] border border-[#31353e]">
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-[20px] text-[#7bd0ff]">verified</span>
                  <div className="flex flex-col">
                    <span className="font-label-md text-[13px] font-bold text-[#dfe2ee]">
                      Source: OWASP ZAP v2.14 Engine Proof
                    </span>
                    <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">
                      Deterministic HTTP traffic probe • Attack Rule ID: {selectedVuln.scannerRuleId || '40018'}
                    </span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-[#1c2028] text-[#7bd0ff] font-code-sm text-[10px] font-bold uppercase font-mono border border-[#31353e]">
                  Confidence: {selectedVuln.confidence}%
                </span>
              </div>

              {/* Telemetry Matrix Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="p-2.5 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col">
                  <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-semibold font-mono">Alert Taxon</span>
                  <span className="font-label-md text-[13px] text-[#dfe2ee] font-bold mt-0.5 font-mono">{selectedVuln.cwe}</span>
                  <span className="font-code-sm text-[10px] text-[#908fa0]">{selectedVuln.wasc || 'WASC-19'}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col">
                  <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-semibold font-mono">Method</span>
                  <span className="font-label-md text-[13px] text-[#7bd0ff] font-bold mt-0.5 font-mono">HTTP {selectedVuln.method}</span>
                  <span className="font-code-sm text-[10px] text-[#908fa0]">Port 3000</span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col">
                  <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-semibold font-mono">Parameter</span>
                  <span className="font-label-md text-[13px] text-[#ffb4ab] font-bold mt-0.5 font-mono">'{selectedVuln.parameter || 'q'}'</span>
                  <span className="font-code-sm text-[10px] text-[#908fa0]">Query String</span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col">
                  <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-semibold font-mono">Response Code</span>
                  <span className="font-label-md text-[13px] text-[#ffb4ab] font-bold mt-0.5 font-mono">500 Server Err</span>
                  <span className="font-code-sm text-[10px] text-[#908fa0]">{selectedVuln.latency || '114ms'}</span>
                </div>
              </div>

              {/* Injected Payload Callout */}
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-code-sm text-[11px] uppercase font-semibold tracking-wider text-[#908fa0] font-mono">
                    Verified Attack Payload
                  </span>
                  <button 
                    onClick={handleCopyPayload}
                    className="flex items-center gap-1 text-[#c0c1ff] hover:underline font-code-sm text-[11px] font-mono cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[14px]">
                      {copiedPayload ? 'check' : 'content_copy'}
                    </span>
                    <span>{copiedPayload ? 'Copied' : 'Copy Payload'}</span>
                  </button>
                </div>
                <div className="p-3 rounded-xl bg-[#0a0e16] font-code-md text-[12px] text-[#ffb4ab] font-medium shadow-inner flex items-center justify-between border border-[#262a33] font-mono">
                  <code>{selectedVuln.payload || "' OR '1'='1' --"}</code>
                  <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] font-semibold uppercase">
                    {selectedVuln.payloadType || 'Boolean Tautology'}
                  </span>
                </div>
              </div>

              {/* Raw Scanner Evidence Box */}
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-code-sm text-[11px] uppercase font-semibold tracking-wider text-[#908fa0] font-mono">
                    Raw Evidence Transcript
                  </span>
                  <span className="font-code-sm text-[10px] text-[#908fa0] font-mono">
                    Matched: PostgreSQL 15.3 Driver Error
                  </span>
                </div>
                <div className="p-3.5 rounded-xl bg-[#0a0e16] text-[#dfe2ee] shadow-inner flex flex-col gap-1 border border-[#262a33] font-mono text-[11px]">
                  <div className="flex items-center justify-between pb-1 text-[#908fa0] border-b border-[#262a33]">
                    <div className="flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-[#ffb4ab]"></span>
                      <span>ZAP Diagnostic Log #40018-912</span>
                    </div>
                    <span>Thread: zap-scanner-worker-4</span>
                  </div>
                  <pre className="text-[#dfe2ee] overflow-x-auto leading-relaxed select-all pt-1">
                    <span className="text-[#ffb4ab] font-semibold">HTTP/1.1 500 Internal Server Error</span>{'\n'}
                    <span className="text-[#908fa0]">Content-Type:</span> application/json; charset=utf-8{'\n'}
                    <span className="text-[#908fa0]">Server:</span> nginx/1.24.0{'\n'}
                    <span className="text-[#908fa0]">X-Powered-By:</span> Express{'\n\n'}
                    {`{\n  "status": "error",\n  "message": "Syntax error at or near \\"'\\": select * from products where name ILIKE '%' OR '1'='1'--%' AND published = true",\n  "code": "42601",\n  "driver": "pg_catalog / PostgreSQL 15.3"\n}`}
                  </pre>
                </div>
              </div>

              {/* AI Co-Pilot Recommendation Tile */}
              <div className="p-3.5 rounded-xl bg-[#0a0e16] shadow-[0_0_20px_-4px_rgba(139,92,246,0.25)] flex flex-col gap-1 border border-[#a078ff]/30">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[18px] text-[#d0bcff]">auto_awesome</span>
                    <span className="font-label-md text-[13px] text-[#d0bcff] font-bold">
                      Autonomous Patch Engine (Gemini Pro)
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-[#a078ff] text-[#340080] font-code-sm text-[10px] font-bold uppercase font-mono">
                    Diff Ready
                  </span>
                </div>
                <p className="font-body-sm text-[12px] text-[#c7c4d7]">
                  Scanner confirmed vulnerable raw concatenation in <code className="text-[#c0c1ff] font-mono">controllers/productController.ts:42</code>. Parameterized ORM binding ready for zero-downtime deployment.
                </p>
              </div>

              {/* Scanner Official Solution */}
              <div className="flex flex-col gap-1">
                <span className="font-code-sm text-[11px] uppercase font-semibold tracking-wider text-[#908fa0] font-mono">
                  Scanner Remediation Prescription
                </span>
                <div className="p-3 rounded-xl bg-[#1c2028] text-[#dfe2ee] font-body-sm text-[12px] leading-relaxed border border-[#262a33]">
                  Use parameterized SQL queries or prepared statements. Never concatenate untrusted user input directly into executable SQL statements. Implement strict alphanumeric input validation on <code className="text-[#7bd0ff] font-mono">req.query.q</code>.
                </div>
              </div>
            </div>
          )}

          {/* AI Analysis Tab */}
          {detailTab === 'ai' && (
            <div className="flex flex-col gap-3 animate-fadeIn">
              <div className="p-4 rounded-xl bg-[#1c2028] border border-[#a078ff]/30 flex flex-col gap-3">
                <div className="flex items-center gap-2 text-[#d0bcff] font-semibold text-[14px]">
                  <span className="material-symbols-outlined text-[18px]">psychology</span>
                  <span>Gemini 1.5 Pro Root-Cause Synthesis</span>
                </div>
                <p className="text-[13px] text-[#c7c4d7] leading-relaxed">
                  Automated AST inspection mapped this injection point to an un-sanitized string template literal inside <code className="text-[#c0c1ff] font-mono">ProductSearchController.ts</code>. Attack surface exposure is multiplied because the endpoint lacks any ingress token verification.
                </p>
                <div className="p-3 rounded-lg bg-[#0a0e16] border border-[#262a33] font-mono text-[11px]">
                  <div className="text-[#7bd0ff] font-bold mb-1">Downstream Blast Radius:</div>
                  <div className="text-[#dfe2ee]">• Direct access to pg_catalog, users, and customer billing records</div>
                  <div className="text-[#dfe2ee]">• Potential for secondary administrative privilege escalation via JWT forging</div>
                  <div className="text-[#ffb4ab]">• Mandatory compliance disclosure required under SOC 2 Common Criteria 6.1</div>
                </div>
              </div>
            </div>
          )}

          {/* Overview Tab */}
          {detailTab === 'overview' && (
            <div className="flex flex-col gap-3 animate-fadeIn">
              <div className="p-4 rounded-xl bg-[#1c2028] border border-[#262a33]">
                <h4 className="font-semibold text-[#dfe2ee] text-[14px] mb-2">Executive Summary</h4>
                <p className="text-[13px] text-[#c7c4d7] leading-relaxed">
                  {selectedVuln.summary}
                </p>
                <div className="mt-3 pt-3 border-t border-[#262a33] text-[12px] text-[#908fa0]">
                  <strong>Business Impact:</strong> {selectedVuln.impact}
                </div>
              </div>
            </div>
          )}

          {/* Remediation Tab */}
          {detailTab === 'remediation' && (
            <div className="flex flex-col gap-3 animate-fadeIn">
              <div className="p-4 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col gap-2">
                <span className="font-semibold text-[#dfe2ee] text-[13px]">Recommended Fix</span>
                <pre className="p-3 bg-[#0a0e16] rounded-lg font-mono text-[11px] text-[#7bd0ff] overflow-x-auto border border-[#262a33]">
                  {selectedVuln.remediatedCode}
                </pre>
                <button 
                  onClick={() => onNavigate('remediation-center')}
                  className="mt-2 py-2 px-4 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-bold text-[12px] cursor-pointer"
                >
                  Open in Remediation Center →
                </button>
              </div>
            </div>
          )}

          {/* Verification Tab */}
          {detailTab === 'verification' && (
            <div className="flex flex-col gap-3 animate-fadeIn">
              <div className="p-4 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-[#dfe2ee] text-[13px]">Verification Status</span>
                  <span className="px-2 py-0.5 rounded bg-[#00a6e0]/20 text-[#7bd0ff] font-mono text-[11px] font-bold">READY TO RETEST</span>
                </div>
                <p className="text-[12px] text-[#c7c4d7]">
                  Verify whether patch PR #142 effectively suppresses database error reflection under mutating SQL injection fuzz tests.
                </p>
                <button 
                  onClick={() => onNavigate('verification')}
                  className="py-2 px-4 rounded-lg bg-[#00a6e0] text-[#00374d] font-bold text-[12px] cursor-pointer"
                >
                  Go to Verification Center →
                </button>
              </div>
            </div>
          )}

          {/* Drawer Footer Actions */}
          <div className="pt-4 bg-[#181c24] border-t border-[#262a33] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => alert(`Marked ${selectedVuln.id} as potential False Positive for SecOps audit.`)}
                className="px-3 py-2 rounded-xl bg-[#1c2028] hover:bg-[#262a33] text-[#ffb4ab] font-label-md text-[12px] font-semibold transition-colors flex items-center gap-1.5 shadow-sm border border-[#262a33] cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">flag</span>
                <span>False Positive</span>
              </button>
              <button 
                onClick={handleGeneratePoc}
                className="px-3 py-2 rounded-xl bg-[#1c2028] hover:bg-[#262a33] text-[#dfe2ee] font-label-md text-[12px] font-semibold transition-colors flex items-center gap-1.5 shadow-sm border border-[#262a33] cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">play_circle</span>
                <span>{pocGenerated ? 'PoC Script Copied' : 'Generate PoC'}</span>
              </button>
            </div>

            <button 
              onClick={() => onNavigate('remediation-center')}
              className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#c0c1ff] text-[#1000a9] font-label-lg text-[13px] font-bold hover:bg-[#e1e0ff] transition-colors shadow-lg cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">build</span>
              <span>Send to Remediation Center</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
