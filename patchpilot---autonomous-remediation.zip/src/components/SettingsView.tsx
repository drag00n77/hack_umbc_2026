import React, { useState } from 'react';

export const SettingsView: React.FC = () => {
  const [maxRps, setMaxRps] = useState(25);
  const [dualEngine, setDualEngine] = useState(true);
  const [aiTriageMode, setAiTriageMode] = useState('continuous');
  const [slackAutoAlert, setSlackAutoAlert] = useState(true);
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-6 max-w-[1200px] mx-auto w-full">
      <div>
        <span className="font-code-sm text-[11px] text-[#7bd0ff] uppercase tracking-wider font-mono">
          Security Controls & Governance
        </span>
        <h1 className="font-headline-xl text-[30px] md:text-[34px] text-[#dfe2ee] font-bold tracking-tight">
          Platform Settings
        </h1>
        <p className="font-body-md text-[13px] text-[#908fa0] mt-1 max-w-2xl">
          Fine-tune autonomous remediation rules, active perimeter throttling, and automated verification handoffs.
        </p>
      </div>

      {saved && (
        <div className="p-3 rounded-lg bg-[#00a6e0]/15 text-[#7bd0ff] font-mono text-[12px] flex items-center gap-2 border border-[#7bd0ff]/30">
          <span className="material-symbols-outlined text-[16px]">check_circle</span>
          <span>Security configuration policies persisted successfully.</span>
        </div>
      )}

      <form onSubmit={handleSave} className="flex flex-col gap-6">
        {/* Perimeter Safeguards */}
        <div className="bg-[#181c24] p-6 rounded-xl border border-[#262a33] flex flex-col gap-4">
          <div className="flex items-center gap-2 text-[#dfe2ee] font-semibold text-[16px]">
            <span className="material-symbols-outlined text-[#7bd0ff]">speed</span>
            <h2>Perimeter Throttling & Safeguards</h2>
          </div>
          <p className="text-[13px] text-[#908fa0]">
            Strict rate limiting prevents denial-of-service impacts when OWASP ZAP exercises dynamic injection payloads against preview environments.
          </p>

          <div className="flex flex-col gap-2 max-w-md">
            <div className="flex justify-between text-[13px]">
              <span>Maximum Request Rate Limit</span>
              <span className="font-mono text-[#7bd0ff] font-bold">{maxRps} RPS</span>
            </div>
            <input 
              type="range" 
              min="5" 
              max="100" 
              value={maxRps} 
              onChange={(e) => setMaxRps(Number(e.target.value))}
              className="accent-[#c0c1ff] cursor-pointer"
            />
            <span className="text-[11px] text-[#908fa0] font-mono">Recommended safe ceiling: 25 RPS</span>
          </div>
        </div>

        {/* Engine Consensus & AI */}
        <div className="bg-[#181c24] p-6 rounded-xl border border-[#262a33] flex flex-col gap-4">
          <div className="flex items-center gap-2 text-[#dfe2ee] font-semibold text-[16px]">
            <span className="material-symbols-outlined text-[#c0c1ff]">tune</span>
            <h2>Autonomous Consensus & AI Model</h2>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg bg-[#0a0e16] border border-[#262a33]">
            <div className="flex flex-col">
              <span className="text-[13px] font-semibold text-[#dfe2ee]">Dual Engine Consensus Verification</span>
              <span className="text-[11px] text-[#908fa0]">Cross-verify OWASP ZAP alerts with Nuclei engine heuristics before raising priority.</span>
            </div>
            <button 
              type="button" 
              onClick={() => setDualEngine(!dualEngine)}
              className={`w-10 h-6 rounded-full p-0.5 flex items-center transition-colors cursor-pointer ${
                dualEngine ? 'bg-[#8083ff] justify-end' : 'bg-[#31353e] justify-start'
              }`}
            >
              <div className="w-5 h-5 bg-white rounded-full"></div>
            </button>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg bg-[#0a0e16] border border-[#262a33]">
            <div className="flex flex-col">
              <span className="text-[13px] font-semibold text-[#dfe2ee]">Automatic Slack Alert on Critical Findings</span>
              <span className="text-[11px] text-[#908fa0]">Immediately dispatch webhook when CVSS 9.0+ vulnerability is verified.</span>
            </div>
            <button 
              type="button" 
              onClick={() => setSlackAutoAlert(!slackAutoAlert)}
              className={`w-10 h-6 rounded-full p-0.5 flex items-center transition-colors cursor-pointer ${
                slackAutoAlert ? 'bg-[#8083ff] justify-end' : 'bg-[#31353e] justify-start'
              }`}
            >
              <div className="w-5 h-5 bg-white rounded-full"></div>
            </button>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-[13px] font-semibold text-[#dfe2ee]">Gemini Auto-Triage Cadence</label>
            <select 
              value={aiTriageMode}
              onChange={(e) => setAiTriageMode(e.target.value)}
              className="bg-[#0a0e16] text-[#dfe2ee] p-2.5 rounded-lg border border-[#262a33] font-mono text-[12px] max-w-sm"
            >
              <option value="continuous">Continuous (Real-time on new payload reflection)</option>
              <option value="on-scan-complete">On Scan Complete (Batch synthesis)</option>
              <option value="manual">Manual Approval Only</option>
            </select>
          </div>
        </div>

        <div>
          <button 
            type="submit"
            className="px-6 py-2.5 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-bold text-[13px] hover:bg-[#e1e0ff] transition-all cursor-pointer shadow-md"
          >
            Save Security Configuration
          </button>
        </div>
      </form>
    </div>
  );
};
