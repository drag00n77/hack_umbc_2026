import React, { useState } from 'react';
import { NavTab } from './Sidebar.tsx';

interface RemediationCenterProps {
  onNavigate: (tab: NavTab) => void;
}

export const RemediationCenter: React.FC<RemediationCenterProps> = ({ onNavigate }) => {
  const [selectedTask, setSelectedTask] = useState<'sqli' | 'idor' | 'xss' | 'csp'>('sqli');
  const [activeTab, setActiveTab] = useState<'fix' | 'diff' | 'defense' | 'audit'>('fix');
  const [filterQueue, setFilterQueue] = useState<'all' | 'crithigh' | 'assigned'>('all');
  const [commitHash, setCommitHash] = useState('git#8f2a1b - fix: parameterize product search');
  const [copiedPatch, setCopiedPatch] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployedStatus, setDeployedStatus] = useState<string | null>(null);
  const [isHandoffQueued, setIsHandoffQueued] = useState(false);

  const handleCopyPatch = () => {
    const codeSnippet = `// SAFE: Parameterized prepared statement\nasync function searchProducts(req, res) {\n  const searchTerm = String(req.query.q || '').slice(0, 100);\n  const sql = \`SELECT id, name, sku, price FROM products WHERE name ILIKE $1\`;\n  const result = await db.query(sql, [\`%\${searchTerm}%\`]);\n  return res.json(result.rows);\n}`;
    navigator.clipboard.writeText(codeSnippet);
    setCopiedPatch(true);
    setTimeout(() => setCopiedPatch(false), 2000);
  };

  const handleMarkDeployed = () => {
    setIsDeploying(true);
    setTimeout(() => {
      setIsDeploying(false);
      setDeployedStatus('Fix deployed to preview staging (Container ID: #stg-8f2a1b)');
      setTimeout(() => setDeployedStatus(null), 4000);
    }, 1200);
  };

  const handleTriggerRescan = () => {
    setIsHandoffQueued(true);
    setTimeout(() => {
      onNavigate('verification');
    }, 1200);
  };

  return (
    <div className="flex flex-col w-full">
      <div className="relative w-full overflow-hidden p-4 lg:p-8 flex flex-col gap-6 max-w-[1720px] mx-auto">
        <div className="absolute -top-32 right-1/4 w-96 h-96 bg-[#8083ff]/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-48 -left-20 w-80 h-80 bg-[#a078ff]/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Header & KPIs Row */}
        <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-4">
          <div className="flex flex-col gap-1 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-[#c0c1ff]/10 text-[#c0c1ff] font-code-sm text-[11px] font-semibold tracking-wider uppercase font-mono">
                Orchestration Hub
              </span>
              <span className="text-[#908fa0] font-code-sm text-[11px] font-mono">v2.14-PRO</span>
            </div>
            <h1 className="font-headline-xl text-[30px] md:text-[34px] text-[#dfe2ee] font-bold tracking-tight">
              Remediation Center
            </h1>
            <p className="font-body-md text-[13px] text-[#908fa0] leading-relaxed">
              Structured step-by-step developer remediation workflows with integrated role guidance and automated verification handoff.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#181c24] shadow-sm border border-[#262a33]">
              <span className="material-symbols-outlined text-[#7bd0ff] text-[20px]">bolt</span>
              <div className="flex flex-col">
                <span className="font-code-sm text-[10px] text-[#908fa0] uppercase tracking-wider font-mono">Fast Lane</span>
                <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold">Autonomous PR Sync Active</span>
              </div>
            </div>
            <button 
              onClick={() => alert("CLI Agent binary generated: curl -sSL https://patchpilot.io/agent/install.sh | bash")}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#262a33] text-[#dfe2ee] font-label-md text-[13px] hover:bg-[#31353e] transition-colors shadow-sm border border-[#31353e] cursor-pointer" 
              type="button"
            >
              <span className="material-symbols-outlined text-[18px]">terminal</span>
              <span>CLI Agent Export</span>
            </button>
          </div>
        </div>

        {/* Global Summary KPIs Bento */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#181c24] p-4 rounded-xl flex items-center justify-between shadow-sm border border-[#262a33]">
            <div className="flex flex-col">
              <span className="font-code-sm text-[11px] uppercase tracking-wider text-[#908fa0] font-mono">Active Remediations</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="font-headline-lg text-[26px] text-[#dfe2ee] font-bold">7</span>
                <span className="font-body-sm text-[12px] text-[#908fa0]">tracked issues</span>
              </div>
            </div>
            <div className="w-12 h-12 rounded-xl bg-[#262a33] flex items-center justify-center text-[#c0c1ff] border border-[#31353e]">
              <span className="material-symbols-outlined text-[24px]">task_alt</span>
            </div>
          </div>

          <div className="bg-[#181c24] p-4 rounded-xl flex items-center justify-between shadow-sm border border-[#262a33]">
            <div className="flex flex-col">
              <span className="font-code-sm text-[11px] uppercase tracking-wider text-[#ffb4ab] font-bold font-mono">Critical in Progress</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="font-headline-lg text-[26px] text-[#ffb4ab] font-bold">2</span>
                <span className="font-body-sm text-[12px] text-[#ffb4ab]/80">SLA: &lt; 8h remaining</span>
              </div>
            </div>
            <div className="w-12 h-12 rounded-xl bg-[#93000a]/30 flex items-center justify-center text-[#ffb4ab] border border-[#93000a]/50">
              <span className="material-symbols-outlined text-[24px]">warning</span>
            </div>
          </div>

          <div className="bg-[#181c24] p-4 rounded-xl flex items-center justify-between shadow-sm border border-[#262a33]">
            <div className="flex flex-col">
              <span className="font-code-sm text-[11px] uppercase tracking-wider text-[#7bd0ff] font-bold font-mono">Awaiting Review</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="font-headline-lg text-[26px] text-[#7bd0ff] font-bold">3</span>
                <span className="font-body-sm text-[12px] text-[#908fa0]">PRs ready for SecOps</span>
              </div>
            </div>
            <div className="w-12 h-12 rounded-xl bg-[#00a6e0]/20 flex items-center justify-center text-[#7bd0ff] border border-[#00a6e0]/30">
              <span className="material-symbols-outlined text-[24px]">rate_review</span>
            </div>
          </div>

          <div className="bg-[#181c24] p-4 rounded-xl flex items-center justify-between shadow-sm border border-[#262a33]">
            <div className="flex flex-col">
              <span className="font-code-sm text-[11px] uppercase tracking-wider text-[#d0bcff] font-bold font-mono">Avg Time to Patch</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="font-headline-lg text-[26px] text-[#d0bcff] font-bold">4.2h</span>
                <span className="font-code-sm text-[11px] text-[#7bd0ff] font-semibold font-mono">↓ 28% vs benchmark</span>
              </div>
            </div>
            <div className="w-16 h-10 flex items-end">
              <svg className="w-full h-full text-[#7bd0ff]" fill="none" viewBox="0 0 64 32">
                <path d="M2 28L14 20L26 24L38 12L50 16L62 4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
                <circle cx="62" cy="4" fill="currentColor" r="2.5" />
              </svg>
            </div>
          </div>
        </div>

        {/* AI Transparency Advisory Banner */}
        <div className="flex items-center justify-between px-4 py-2.5 rounded-xl bg-[#0a0e16] shadow-sm border border-[#262a33]">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-7 h-7 rounded-lg bg-[#a078ff]/10 flex items-center justify-center text-[#d0bcff] shrink-0 border border-[#a078ff]/20">
              <span className="material-symbols-outlined text-[18px]">auto_awesome</span>
            </div>
            <span className="font-body-sm text-[12px] text-[#dfe2ee] truncate">
              Patch guidance generated by <span className="font-semibold text-[#d0bcff]">Gemini 1.5 Pro</span> from OWASP ZAP v2.14 scan telemetry. All code changes require peer review before production propagation.
            </span>
          </div>
          <span className="hidden md:inline-flex items-center gap-2 font-code-sm text-[11px] text-[#908fa0] font-mono shrink-0">
            Model Conf: 99.4%
          </span>
        </div>

        {/* Interactive 4-Stage Remediation Wizard Stepper */}
        <div className="bg-[#181c24] p-4 rounded-xl shadow-sm border border-[#262a33]">
          <div className="flex items-center justify-between mb-3">
            <span className="font-code-sm text-[11px] uppercase tracking-wider text-[#908fa0] font-mono">
              Active Remediation Pipeline Lifecycle
            </span>
            <span className="font-code-sm text-[11px] text-[#c0c1ff] font-semibold font-mono">
              Target Ref: vuln-9082-sql-injection
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
            {/* Stage 1 */}
            <div className="flex flex-col gap-1 p-3 rounded-xl bg-[#262a33] border border-[#31353e]">
              <div className="flex items-center justify-between">
                <span className="font-code-sm text-[10px] uppercase text-[#7bd0ff] font-bold font-mono">Stage 01</span>
                <span className="w-5 h-5 rounded-full bg-[#7bd0ff] text-[#00354a] flex items-center justify-center font-bold">
                  <span className="material-symbols-outlined text-[14px]">check</span>
                </span>
              </div>
              <span className="font-label-lg text-[13px] text-[#dfe2ee] font-semibold">Vulnerability Triage</span>
              <span className="font-body-sm text-[11px] text-[#908fa0]">Verified by SecOps Lead • Risk confirmed</span>
            </div>

            {/* Stage 2 (Active) */}
            <div className="flex flex-col gap-1 p-3 rounded-xl bg-[#31353e] shadow-md relative overflow-hidden border border-[#c0c1ff]/50">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#c0c1ff] to-[#7bd0ff]"></div>
              <div className="flex items-center justify-between">
                <span className="font-code-sm text-[10px] uppercase text-[#c0c1ff] font-bold font-mono">Stage 02</span>
                <span className="flex h-2.5 w-2.5 rounded-full bg-[#c0c1ff] animate-ping"></span>
              </div>
              <span className="font-label-lg text-[13px] text-[#c0c1ff] font-bold">Code Remediation</span>
              <span className="font-body-sm text-[11px] text-[#dfe2ee]">Active step • Developer fix in progress</span>
            </div>

            {/* Stage 3 */}
            <div className="flex flex-col gap-1 p-3 rounded-xl bg-[#1c2028] opacity-70 border border-[#262a33]">
              <div className="flex items-center justify-between">
                <span className="font-code-sm text-[10px] uppercase text-[#908fa0] font-mono">Stage 03</span>
                <span className="material-symbols-outlined text-[16px] text-[#908fa0]">hourglass_empty</span>
              </div>
              <span className="font-label-lg text-[13px] text-[#dfe2ee] font-medium">Peer & Security Review</span>
              <span className="font-body-sm text-[11px] text-[#908fa0]">Pending pull request submission</span>
            </div>

            {/* Stage 4 */}
            <div className="flex flex-col gap-1 p-3 rounded-xl bg-[#1c2028] opacity-70 border border-[#262a33]">
              <div className="flex items-center justify-between">
                <span className="font-code-sm text-[10px] uppercase text-[#908fa0] font-mono">Stage 04</span>
                <span className="material-symbols-outlined text-[16px] text-[#908fa0]">lock_clock</span>
              </div>
              <span className="font-label-lg text-[13px] text-[#dfe2ee] font-medium">ZAP Automated Verification</span>
              <span className="font-body-sm text-[11px] text-[#908fa0]">Automated staging rescan trigger</span>
            </div>
          </div>
        </div>

        {/* Main Workspace Split Screen: 35% Tasks List / 65% Interactive Action Hub */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* LEFT SIDE: 35% Width */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="flex flex-col gap-3 bg-[#181c24] p-4 rounded-xl shadow-sm border border-[#262a33]">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#c0c1ff] text-[20px]">format_list_bulleted</span>
                  <span className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold">Triage Queue</span>
                </div>
                <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">Sorted by Risk</span>
              </div>

              {/* Quick Filter Buttons */}
              <div className="flex items-center gap-1 bg-[#0a0e16] p-1 rounded-lg border border-[#262a33]">
                <button 
                  onClick={() => setFilterQueue('all')}
                  className={`flex-1 py-1 px-2 rounded-md font-label-md text-[12px] text-center transition-colors cursor-pointer ${
                    filterQueue === 'all' ? 'bg-[#262a33] text-[#c0c1ff] font-bold' : 'text-[#908fa0] hover:text-[#dfe2ee]'
                  }`}
                  type="button"
                >
                  All (7)
                </button>
                <button 
                  onClick={() => setFilterQueue('crithigh')}
                  className={`flex-1 py-1 px-2 rounded-md font-label-md text-[12px] text-center transition-colors cursor-pointer ${
                    filterQueue === 'crithigh' ? 'bg-[#262a33] text-[#ffb4ab] font-bold' : 'text-[#908fa0] hover:text-[#dfe2ee]'
                  }`}
                  type="button"
                >
                  Crit/High (4)
                </button>
                <button 
                  onClick={() => setFilterQueue('assigned')}
                  className={`flex-1 py-1 px-2 rounded-md font-label-md text-[12px] text-center transition-colors cursor-pointer ${
                    filterQueue === 'assigned' ? 'bg-[#262a33] text-[#7bd0ff] font-bold' : 'text-[#908fa0] hover:text-[#dfe2ee]'
                  }`}
                  type="button"
                >
                  Assigned (2)
                </button>
              </div>
            </div>

            {/* Task Items List */}
            <div className="flex flex-col gap-3">
              {/* Task 1 (SQLi) */}
              <div 
                onClick={() => setSelectedTask('sqli')}
                className={`flex flex-col p-4 rounded-xl cursor-pointer transition-all border relative overflow-hidden ${
                  selectedTask === 'sqli' 
                    ? 'bg-[#262a33] border-[#c0c1ff] shadow-md' 
                    : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                }`}
              >
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#ffb4ab]"></div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] font-bold uppercase font-mono">
                      CRITICAL • 9.8
                    </span>
                    <span className="px-2 py-0.5 rounded bg-[#31353e] text-[#c0c1ff] font-code-sm text-[10px] font-mono">
                      Active
                    </span>
                  </div>
                  <span className="material-symbols-outlined text-[#c0c1ff] text-[18px]">
                    {selectedTask === 'sqli' ? 'radio_button_checked' : 'radio_button_unchecked'}
                  </span>
                </div>
                <div className="mt-2">
                  <h3 className="font-headline-sm text-[15px] text-[#dfe2ee] font-semibold">SQL Injection</h3>
                  <p className="font-code-sm text-[11px] text-[#7bd0ff] truncate mt-0.5 font-mono">/api/products/search</p>
                </div>
                <div className="flex items-center justify-between mt-3 pt-2 text-[#908fa0] border-t border-[#31353e]/60">
                  <div className="flex items-center gap-1.5 font-code-sm text-[11px] font-mono">
                    <span className="material-symbols-outlined text-[14px]">database</span>
                    <span>Database Vulnerability</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-label-md text-[11px]">
                    <span className="w-5 h-5 rounded-full bg-[#8083ff]/20 text-[#c0c1ff] flex items-center justify-center font-bold">BE</span>
                    <span>Backend Team</span>
                  </div>
                </div>
              </div>

              {/* Task 2 (IDOR) */}
              <div 
                onClick={() => setSelectedTask('idor')}
                className={`flex flex-col p-4 rounded-xl cursor-pointer transition-all border relative overflow-hidden ${
                  selectedTask === 'idor' 
                    ? 'bg-[#262a33] border-[#7bd0ff] shadow-md' 
                    : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                }`}
              >
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#ffb4ab]/70"></div>
                <div className="flex items-start justify-between gap-2">
                  <span className="px-2 py-0.5 rounded bg-[#93000a]/60 text-[#ffb4ab] font-code-sm text-[10px] font-bold uppercase font-mono">
                    HIGH • 8.5
                  </span>
                  <span className="material-symbols-outlined text-[#908fa0] text-[18px]">
                    {selectedTask === 'idor' ? 'radio_button_checked' : 'radio_button_unchecked'}
                  </span>
                </div>
                <div className="mt-2">
                  <h3 className="font-headline-sm text-[15px] text-[#dfe2ee] font-semibold">Broken Access Control / IDOR</h3>
                  <p className="font-code-sm text-[11px] text-[#908fa0] truncate mt-0.5 font-mono">/api/users</p>
                </div>
                <div className="flex items-center justify-between mt-3 pt-2 text-[#908fa0] border-t border-[#262a33]">
                  <div className="flex items-center gap-1.5 font-code-sm text-[11px] font-mono">
                    <span className="material-symbols-outlined text-[14px]">key</span>
                    <span>Auth Bypass</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-label-md text-[11px]">
                    <span className="w-5 h-5 rounded-full bg-[#00a6e0]/20 text-[#7bd0ff] flex items-center justify-center font-bold">API</span>
                    <span>API Team</span>
                  </div>
                </div>
              </div>

              {/* Task 3 (XSS) */}
              <div 
                onClick={() => setSelectedTask('xss')}
                className={`flex flex-col p-4 rounded-xl cursor-pointer transition-all border relative overflow-hidden ${
                  selectedTask === 'xss' 
                    ? 'bg-[#262a33] border-[#a078ff] shadow-md' 
                    : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                }`}
              >
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#ffb4ab]/70"></div>
                <div className="flex items-start justify-between gap-2">
                  <span className="px-2 py-0.5 rounded bg-[#93000a]/60 text-[#ffb4ab] font-code-sm text-[10px] font-bold uppercase font-mono">
                    HIGH • 7.6
                  </span>
                  <span className="material-symbols-outlined text-[#908fa0] text-[18px]">
                    {selectedTask === 'xss' ? 'radio_button_checked' : 'radio_button_unchecked'}
                  </span>
                </div>
                <div className="mt-2">
                  <h3 className="font-headline-sm text-[15px] text-[#dfe2ee] font-semibold">Reflected XSS</h3>
                  <p className="font-code-sm text-[11px] text-[#908fa0] truncate mt-0.5 font-mono">/search?q=</p>
                </div>
                <div className="flex items-center justify-between mt-3 pt-2 text-[#908fa0] border-t border-[#262a33]">
                  <div className="flex items-center gap-1.5 font-code-sm text-[11px] font-mono">
                    <span className="material-symbols-outlined text-[14px]">code</span>
                    <span>Client Injection</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-label-md text-[11px]">
                    <span className="w-5 h-5 rounded-full bg-[#a078ff]/20 text-[#d0bcff] flex items-center justify-center font-bold">FE</span>
                    <span>Web Core</span>
                  </div>
                </div>
              </div>

              {/* Task 4 (CSP) */}
              <div 
                onClick={() => setSelectedTask('csp')}
                className={`flex flex-col p-4 rounded-xl cursor-pointer transition-all border relative overflow-hidden ${
                  selectedTask === 'csp' 
                    ? 'bg-[#262a33] border-[#7bd0ff] shadow-md' 
                    : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                }`}
              >
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#7bd0ff]"></div>
                <div className="flex items-start justify-between gap-2">
                  <span className="px-2 py-0.5 rounded bg-[#00a6e0]/30 text-[#7bd0ff] font-code-sm text-[10px] font-bold uppercase font-mono">
                    MEDIUM • 5.3
                  </span>
                  <span className="material-symbols-outlined text-[#908fa0] text-[18px]">
                    {selectedTask === 'csp' ? 'radio_button_checked' : 'radio_button_unchecked'}
                  </span>
                </div>
                <div className="mt-2">
                  <h3 className="font-headline-sm text-[15px] text-[#dfe2ee] font-semibold">Missing Content-Security-Policy</h3>
                  <p className="font-code-sm text-[11px] text-[#908fa0] truncate mt-0.5 font-mono">/</p>
                </div>
                <div className="flex items-center justify-between mt-3 pt-2 text-[#908fa0] border-t border-[#262a33]">
                  <div className="flex items-center gap-1.5 font-code-sm text-[11px] font-mono">
                    <span className="material-symbols-outlined text-[14px]">shield</span>
                    <span>Header Hardening</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-label-md text-[11px]">
                    <span className="w-5 h-5 rounded-full bg-[#908fa0]/20 text-[#908fa0] flex items-center justify-center font-bold">OPS</span>
                    <span>DevOps</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Telemetry Trace Correlated */}
            <div className="bg-[#0a0e16] p-4 rounded-xl flex items-center gap-3 border border-[#262a33]">
              <div className="w-10 h-10 rounded-lg bg-[#262a33] flex items-center justify-center text-[#c0c1ff] shrink-0 border border-[#31353e]">
                <span className="material-symbols-outlined text-[20px]">hub</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold">Telemetry Trace Correlated</span>
                <span className="font-code-sm text-[11px] text-[#908fa0] truncate font-mono">OWASP Alert ID: 40018 • ZAP v2.14</span>
              </div>
            </div>
          </div>

          {/* RIGHT SIDE: 65% Width */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            {/* Tabs */}
            <div className="bg-[#181c24] p-1.5 rounded-xl flex items-center gap-2 overflow-x-auto shadow-sm border border-[#262a33]">
              <button 
                onClick={() => setActiveTab('fix')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-label-lg text-[13px] transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'fix' ? 'bg-[#262a33] text-[#c0c1ff] font-bold shadow-sm' : 'text-[#908fa0] hover:text-[#dfe2ee]'
                }`}
                type="button"
              >
                <span className="material-symbols-outlined text-[18px]">build</span>
                <span>Interactive Fix Guide</span>
              </button>
              <button 
                onClick={() => setActiveTab('diff')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-label-lg text-[13px] transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'diff' ? 'bg-[#262a33] text-[#c0c1ff] font-bold shadow-sm' : 'text-[#908fa0] hover:text-[#dfe2ee]'
                }`}
                type="button"
              >
                <span className="material-symbols-outlined text-[18px]">difference</span>
                <span>Code Comparison</span>
              </button>
              <button 
                onClick={() => setActiveTab('defense')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-label-lg text-[13px] transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'defense' ? 'bg-[#262a33] text-[#c0c1ff] font-bold shadow-sm' : 'text-[#908fa0] hover:text-[#dfe2ee]'
                }`}
                type="button"
              >
                <span className="material-symbols-outlined text-[18px]">security</span>
                <span>Defense-in-Depth & Prevention</span>
              </button>
              <button 
                onClick={() => setActiveTab('audit')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-label-lg text-[13px] transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'audit' ? 'bg-[#262a33] text-[#c0c1ff] font-bold shadow-sm' : 'text-[#908fa0] hover:text-[#dfe2ee]'
                }`}
                type="button"
              >
                <span className="material-symbols-outlined text-[18px]">forum</span>
                <span>Audit & Discussion</span>
                <span className="px-1.5 py-0.2 rounded-full bg-[#31353e] text-[#dfe2ee] font-code-sm text-[10px]">3</span>
              </button>
            </div>

            {/* Card 1: Problem & Threat Anatomy */}
            <div className="bg-[#181c24] p-6 rounded-xl shadow-sm border border-[#262a33] flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#ffb4ab] text-[22px]">bug_report</span>
                  <h2 className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold">The Core Problem & Threat Anatomy</h2>
                </div>
                <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">CWE-89: SQL Injection</span>
              </div>
              <p className="font-body-md text-[13px] text-[#dfe2ee] leading-relaxed">
                Direct string interpolation of untrusted input in PostgreSQL endpoints permits malicious payloads to break SQL statement containment. By injecting syntax terminators and boolean injections (<span className="font-code-md text-[12px] text-[#ffb4ab] px-1.5 py-0.5 rounded bg-[#0a0e16] font-mono font-medium">' OR 1=1 --</span>), an unauthenticated adversary can modify execution logic, dump relational tables, or force credential escalation.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                <div className="p-3 rounded-lg bg-[#0a0e16] flex flex-col gap-1 border border-[#262a33]">
                  <span className="font-code-sm text-[10px] uppercase tracking-wider text-[#908fa0] font-mono">Attack Vector</span>
                  <span className="font-label-lg text-[13px] text-[#dfe2ee] font-medium">HTTP GET Query String</span>
                </div>
                <div className="p-3 rounded-lg bg-[#0a0e16] flex flex-col gap-1 border border-[#262a33]">
                  <span className="font-code-sm text-[10px] uppercase tracking-wider text-[#908fa0] font-mono">Parameter Impacted</span>
                  <span className="font-code-sm text-[12px] text-[#ffb4ab] font-mono font-medium">query=item_id</span>
                </div>
                <div className="p-3 rounded-lg bg-[#0a0e16] flex flex-col gap-1 border border-[#262a33]">
                  <span className="font-code-sm text-[10px] uppercase tracking-wider text-[#908fa0] font-mono">Database Engine</span>
                  <span className="font-label-lg text-[13px] text-[#dfe2ee] font-medium font-mono">PostgreSQL 15.4</span>
                </div>
              </div>
            </div>

            {/* Card 2: Prescribed 3-Step Plan */}
            <div className="bg-[#181c24] p-6 rounded-xl shadow-sm border border-[#262a33] flex flex-col gap-4">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#c0c1ff] text-[22px]">checklist</span>
                <h2 className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold">Prescribed 3-Step Remediation Plan</h2>
              </div>
              <div className="flex flex-col gap-3">
                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-[#1c2028] border border-[#262a33]">
                  <div className="w-8 h-8 rounded-lg bg-[#c0c1ff]/20 text-[#c0c1ff] flex items-center justify-center font-code-sm text-[13px] font-bold shrink-0 font-mono">
                    01
                  </div>
                  <div className="flex flex-col gap-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold">Input Validation</span>
                      <span className="px-2 py-0.5 rounded bg-[#31353e] text-[#7bd0ff] font-code-sm text-[10px] font-mono">First Line of Defense</span>
                    </div>
                    <p className="font-body-md text-[13px] text-[#908fa0] leading-relaxed">
                      Enforce strict alphanumeric type assertions and sanitize string length before the query builder is invoked. Disallow unescaped control delimiters at the ingress controller.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-[#1c2028] border border-[#262a33]">
                  <div className="w-8 h-8 rounded-lg bg-[#c0c1ff]/20 text-[#c0c1ff] flex items-center justify-center font-code-sm text-[13px] font-bold shrink-0 font-mono">
                    02
                  </div>
                  <div className="flex flex-col gap-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold">Database Layer Parameterization</span>
                      <span className="px-2 py-0.5 rounded bg-[#c0c1ff]/10 text-[#c0c1ff] font-code-sm text-[10px] font-mono">Mandatory Architectural Fix</span>
                    </div>
                    <p className="font-body-md text-[13px] text-[#908fa0] leading-relaxed">
                      Convert raw inline SQL interpolation into prepared statements utilizing the PostgreSQL parameterized operator (<span className="text-[#c0c1ff] font-mono font-medium">$1</span>). This guarantees separation of SQL instructions from untrusted data literals.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-[#1c2028] border border-[#262a33]">
                  <div className="w-8 h-8 rounded-lg bg-[#c0c1ff]/20 text-[#c0c1ff] flex items-center justify-center font-code-sm text-[13px] font-bold shrink-0 font-mono">
                    03
                  </div>
                  <div className="flex flex-col gap-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold">Output Error Handling</span>
                      <span className="px-2 py-0.5 rounded bg-[#31353e] text-[#d0bcff] font-code-sm text-[10px] font-mono">Leakage Mitigation</span>
                    </div>
                    <p className="font-body-md text-[13px] text-[#908fa0] leading-relaxed">
                      Wrap query executions in generalized try/catch handlers. Suppress database-level error stacks from bubbling up to standard HTTP 500 API responses.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Card 3: Code Recommendation Preview */}
            <div className="bg-[#181c24] rounded-xl shadow-sm overflow-hidden flex flex-col border border-[#262a33]">
              <div className="p-4 bg-[#262a33] border-b border-[#31353e] flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#7bd0ff] text-[20px]">terminal</span>
                  <span className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold">Code Recommendation Preview</span>
                  <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">src/controllers/product.controller.ts</span>
                </div>
                <button 
                  onClick={handleCopyPatch}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-md text-[12px] font-bold hover:bg-[#e1e0ff] transition-colors shadow-sm cursor-pointer" 
                  type="button"
                >
                  <span className="material-symbols-outlined text-[16px]">{copiedPatch ? 'check' : 'content_copy'}</span>
                  <span>{copiedPatch ? 'Copied!' : 'Copy Patch'}</span>
                </button>
              </div>

              {/* Side-by-side Diff */}
              <div className="grid grid-cols-1 md:grid-cols-2 bg-[#0a0e16] font-mono text-[12px]">
                {/* Vulnerable Before */}
                <div className="flex flex-col p-4 border-b md:border-b-0 md:border-r border-[#262a33]">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#262a33]">
                    <span className="font-code-sm text-[11px] text-[#ffb4ab] font-bold uppercase flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#ffb4ab]"></span> Before (Vulnerable)
                    </span>
                    <span className="font-code-sm text-[11px] text-[#908fa0]">Lines 42-49</span>
                  </div>
                  <pre className="text-[#908fa0] overflow-x-auto leading-relaxed">
                    <span className="text-[#ffb4ab]/70">// UNSAFE: Direct string interpolation</span>{'\n'}
                    <span className="text-[#7bd0ff]">async function</span> <span className="text-[#c0c1ff]">searchProducts</span>(req, res) {'{\n'}
                    {'  '}<span className="text-[#7bd0ff]">const</span> searchTerm = req.query.q;{'\n\n'}
                    <span className="text-[#ffb4ab] font-semibold">-   const sql = `SELECT * FROM items\n-     WHERE title LIKE '%${`\${searchTerm}`}%'\`;</span>{'\n\n'}
                    {'  '}<span className="text-[#7bd0ff]">const</span> result = <span className="text-[#7bd0ff]">await</span> db.query(sql);{'\n'}
                    {'  '}<span className="text-[#7bd0ff]">return</span> res.json(result.rows);{'\n'}
                    {'}'}
                  </pre>
                </div>

                {/* Secured After */}
                <div className="flex flex-col p-4 bg-[#1c2028]/60">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#262a33]">
                    <span className="font-code-sm text-[11px] text-[#7bd0ff] font-bold uppercase flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#7bd0ff]"></span> After (Secured with Gemini Fix)
                    </span>
                    <span className="font-code-sm text-[11px] text-[#7bd0ff]">Recommended</span>
                  </div>
                  <pre className="text-[#dfe2ee] overflow-x-auto leading-relaxed">
                    <span className="text-[#7bd0ff]/70">// SAFE: Parameterized prepared statement</span>{'\n'}
                    <span className="text-[#7bd0ff]">async function</span> <span className="text-[#c0c1ff]">searchProducts</span>(req, res) {'{\n'}
                    {'  '}<span className="text-[#7bd0ff]">const</span> searchTerm = String(req.query.q || <span className="text-[#d0bcff]">''</span>).slice(0, 100);{'\n\n'}
                    <span className="text-[#7bd0ff] font-semibold">+   const sql = `SELECT * FROM items\n+     WHERE title ILIKE $1\`;</span>{'\n\n'}
                    {'  '}<span className="text-[#7bd0ff]">const</span> result = <span className="text-[#7bd0ff]">await</span> db.query(sql, [{'\n'}
                    {'    '}<span className="text-[#d0bcff]">`%${`\${searchTerm}`}%`</span>{'\n'}
                    {'  '}]);{'\n'}
                    {'  '}<span className="text-[#7bd0ff]">return</span> res.json(result.rows);{'\n'}
                    {'}'}
                  </pre>
                </div>
              </div>
            </div>

            {/* Card 4: Developer Action & Verification Bridge */}
            <div className="bg-[#181c24] p-6 rounded-xl shadow-md border border-[#262a33] flex flex-col gap-4 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#7bd0ff] text-[22px]">rocket_launch</span>
                  <h2 className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold">
                    Developer Action & Verification Bridge
                  </h2>
                </div>
                <span className="px-2 py-0.5 rounded bg-[#262a33] text-[#908fa0] font-code-sm text-[11px] font-mono border border-[#31353e]">
                  Handoff Stage
                </span>
              </div>
              <p className="font-body-md text-[13px] text-[#908fa0]">
                Submit your branch commit for continuous staging validation. PatchPilot triggers an isolated OWASP ZAP dynamic rescan against your preview environment.
              </p>

              {deployedStatus && (
                <div className="p-3 rounded-lg bg-[#00a6e0]/15 text-[#7bd0ff] font-mono text-[12px] flex items-center gap-2 border border-[#7bd0ff]/30">
                  <span className="material-symbols-outlined text-[16px]">check_circle</span>
                  <span>{deployedStatus}</span>
                </div>
              )}

              <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3 pt-1">
                <div className="flex-1 flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#0a0e16] border border-[#262a33]">
                  <span className="material-symbols-outlined text-[#908fa0] text-[18px]">commit</span>
                  <input 
                    aria-label="Git Branch or Commit Hash" 
                    value={commitHash}
                    onChange={(e) => setCommitHash(e.target.value)}
                    className="bg-transparent text-[#dfe2ee] font-code-md text-[13px] font-mono w-full focus:outline-none placeholder-[#908fa0]" 
                    placeholder="Enter Git Branch / Commit Hash..." 
                    type="text" 
                  />
                </div>

                <button 
                  onClick={handleMarkDeployed}
                  disabled={isDeploying}
                  className="px-4 py-2.5 rounded-lg bg-[#262a33] text-[#dfe2ee] font-label-md text-[13px] hover:bg-[#31353e] transition-colors shadow-sm whitespace-nowrap border border-[#31353e] cursor-pointer" 
                  type="button"
                >
                  {isDeploying ? 'Deploying...' : 'Mark Fix as Deployed to Staging'}
                </button>

                <button 
                  onClick={handleTriggerRescan}
                  className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-md text-[13px] hover:bg-[#e1e0ff] transition-all shadow-md font-bold whitespace-nowrap cursor-pointer" 
                  type="button"
                >
                  <span className={`material-symbols-outlined text-[18px] ${isHandoffQueued ? 'animate-spin' : ''}`}>
                    {isHandoffQueued ? 'refresh' : 'verified_user'}
                  </span>
                  <span>{isHandoffQueued ? 'Queueing Rescan...' : 'Send to Verification Center for OWASP ZAP Rescan →'}</span>
                </button>
              </div>

              {/* Telemetry Footer */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-[#908fa0] font-code-sm text-[11px] font-mono border-t border-[#262a33]">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#7bd0ff]"></span>
                  <span>Verification Queue: Runner ZAP-04 available</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[14px]">sync</span>
                  <span>Automated regression check estimated time: ~3 mins</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
