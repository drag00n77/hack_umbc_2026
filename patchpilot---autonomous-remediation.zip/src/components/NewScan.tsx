import React, { useState, useEffect } from 'react';
import { MOCK_TERMINAL_LOGS } from '../data/mockData.ts';
import { NavTab } from './Sidebar.tsx';

interface NewScanProps {
  onNavigate: (tab: NavTab) => void;
  onOpenRawLogs?: () => void;
}

export const NewScan: React.FC<NewScanProps> = ({ onNavigate }) => {
  const [targetUrl, setTargetUrl] = useState('http://localhost:3000');
  const [selectedProfile, setSelectedProfile] = useState<'quick' | 'standard' | 'deep'>('standard');
  const [spiderActive, setSpiderActive] = useState(true);
  const [activeScanActive, setActiveScanActive] = useState(true);
  const [ajaxSpiderActive, setAjaxSpiderActive] = useState(true);
  const [timeoutMinutes, setTimeoutMinutes] = useState(15);
  const [legalAccepted, setLegalAccepted] = useState(true);
  
  // Pipeline simulation state
  const [pipelineState, setPipelineState] = useState<'running' | 'paused' | 'completed' | 'aborted'>('running');
  const [progressPercent, setProgressPercent] = useState(42);
  const [activeStage, setActiveStage] = useState(2);
  const [urlsDiscovered, setUrlsDiscovered] = useState(148);
  const [requestsProcessed, setRequestsProcessed] = useState(1842);
  const [alertsDetected, setAlertsDetected] = useState(14);
  const [pingSuccess, setPingSuccess] = useState<string | null>(null);
  const [isPinging, setIsPinging] = useState(false);
  const [cliCopied, setCliCopied] = useState(false);

  // Live log lines
  const [logs, setLogs] = useState(MOCK_TERMINAL_LOGS);

  useEffect(() => {
    if (pipelineState !== 'running') return;
    const interval = setInterval(() => {
      setProgressPercent((prev) => {
        if (prev >= 98) return 98;
        return prev + 1;
      });
      setRequestsProcessed((prev) => prev + Math.floor(Math.random() * 8) + 1);
      if (Math.random() > 0.6) {
        setUrlsDiscovered((prev) => prev + 1);
      }
    }, 1800);
    return () => clearInterval(interval);
  }, [pipelineState]);

  const handleTogglePause = () => {
    setPipelineState(prev => prev === 'running' ? 'paused' : 'running');
  };

  const handleAbort = () => {
    setPipelineState('aborted');
  };

  const handleStartScan = () => {
    setPipelineState('running');
    setProgressPercent(10);
    setActiveStage(1);
    setTimeout(() => {
      setActiveStage(2);
      setProgressPercent(42);
    }, 1200);
  };

  const handlePing = () => {
    setIsPinging(true);
    setPingSuccess(null);
    setTimeout(() => {
      setIsPinging(false);
      setPingSuccess('Target Reachable: HTTP 200 OK (0.3ms latency, Express/PostgreSQL)');
      setTimeout(() => setPingSuccess(null), 5000);
    }, 900);
  };

  const handleCliExport = () => {
    const cliCmd = `zap-cli quick-scan --self-contained --spider --ajax --scanners all ${targetUrl}`;
    navigator.clipboard.writeText(cliCmd);
    setCliCopied(true);
    setTimeout(() => setCliCopied(false), 2000);
  };

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-6 max-w-[1720px] mx-auto w-full">
      {/* Header Block */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-[#262a33] text-[#c0c1ff] font-code-sm text-[11px] uppercase tracking-wider font-semibold font-mono">
              Engine Locked
            </span>
            <span className="font-code-sm text-[11px] text-[#908fa0] font-mono font-medium">
              SESSION // 0x7FA31A
            </span>
          </div>
          <h1 className="font-headline-xl text-[32px] md:text-[36px] text-[#dfe2ee] font-bold tracking-tight">
            New Security Scan
          </h1>
          <p className="font-body-md text-[14px] text-[#908fa0] max-w-2xl">
            Configure and launch an authorized OWASP ZAP security assessment with verified target clearance.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={() => {
              setTargetUrl('http://localhost:3000');
              setSelectedProfile('standard');
              setTimeoutMinutes(15);
            }}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1c2028] text-[#dfe2ee] font-label-md text-[13px] hover:bg-[#262a33] transition-colors shadow-sm border border-[#262a33] cursor-pointer" 
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">history</span>
            <span>Previous Configs</span>
          </button>
          <button 
            onClick={handleCliExport}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#262a33] text-[#7bd0ff] font-label-md text-[13px] hover:bg-[#31353e] transition-colors shadow-sm border border-[#31353e] cursor-pointer" 
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">terminal</span>
            <span>{cliCopied ? 'CLI Copied!' : 'CLI Raw Export'}</span>
          </button>
        </div>
      </div>

      {/* Scanner Lock Card */}
      <div className="relative overflow-hidden rounded-xl bg-[#181c24] p-6 shadow-md border border-[#262a33]">
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-[#c0c1ff]/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start sm:items-center gap-4">
            <div className="w-12 h-12 rounded-lg bg-[#262a33] flex items-center justify-center text-[#c0c1ff] shrink-0 shadow-inner border border-[#31353e]">
              <span className="material-symbols-outlined text-[28px]">lock</span>
            </div>
            <div className="flex flex-col">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold">OWASP ZAP Core Engine</span>
                <span className="px-2 py-0.5 rounded bg-[#31353e] text-[#7bd0ff] font-code-sm text-[11px] font-bold font-mono">
                  v2.14.0
                </span>
                <span className="px-2 py-0.5 rounded bg-[#00a6e0]/20 text-[#7bd0ff] font-code-sm text-[11px] font-semibold flex items-center gap-1.5 font-mono">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#7bd0ff] animate-pulse"></span>
                  CONNECTED
                </span>
              </div>
              <span className="font-code-sm text-[12px] text-[#908fa0] mt-1 font-mono">
                Daemon Binding: <span className="text-[#dfe2ee]">127.0.0.1:8080</span> • Telemetry IPC: Active
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 items-center">
            <div className="flex flex-col px-4 py-2 rounded-lg bg-[#1c2028] border border-[#262a33]">
              <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Engine Health</span>
              <span className="font-label-lg text-[13px] text-[#dfe2ee] font-semibold flex items-center gap-1.5 mt-0.5">
                <span className="h-2 w-2 rounded-full bg-[#7bd0ff]"></span>
                Operational
              </span>
            </div>
            <div className="flex flex-col px-4 py-2 rounded-lg bg-[#1c2028] border border-[#262a33]">
              <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Local Latency</span>
              <span className="font-label-lg text-[13px] text-[#7bd0ff] font-semibold font-mono mt-0.5">&lt; 0.4 ms</span>
            </div>
            <div className="col-span-2 sm:col-span-1 flex flex-col justify-center">
              <div className="flex items-center gap-1.5 text-[#c7c4d7] font-code-sm text-[12px]">
                <span className="material-symbols-outlined text-[16px] text-[#d0bcff]">verified_user</span>
                <span>Exclusive Engine Mode</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-3 flex items-center gap-2 text-[#908fa0] font-body-sm text-[12px] bg-[#0a0e16]/60 px-4 py-2 rounded-lg border border-[#262a33]">
          <span className="material-symbols-outlined text-[18px] text-[#c0c1ff] shrink-0">info</span>
          <span>
            <strong className="text-[#dfe2ee] font-medium">Designated Engine:</strong> OWASP ZAP v2.14 is the strictly verified, dedicated security engine for PatchPilot automated pipelines. No fallback proxies allowed.
          </span>
        </div>
      </div>

      {/* Main Workspace Layout: Form vs Pipeline Status */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Scan Configuration & Launch Form */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          {/* Target Definition Box */}
          <div className="rounded-xl bg-[#181c24] p-6 shadow-sm border border-[#262a33] flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#7bd0ff] text-[20px]">radar</span>
                <h2 className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold">Target Specification</h2>
              </div>
              <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">SCOPE: SINGLE_HOST</span>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="font-label-md text-[13px] text-[#dfe2ee] font-medium flex items-center justify-between" htmlFor="target-url-input">
                <span>Authorized Target URL</span>
                <span className="text-[#7bd0ff] font-code-sm text-[11px] font-bold font-mono">PORT 3000 LISTENING</span>
              </label>
              <div className="relative flex items-center">
                <span className="absolute left-4 text-[#908fa0] material-symbols-outlined text-[20px]">link</span>
                <input 
                  id="target-url-input"
                  value={targetUrl}
                  onChange={(e) => setTargetUrl(e.target.value)}
                  className="w-full bg-[#0a0e16] pl-11 pr-4 py-2.5 rounded-lg text-[#c0c1ff] font-code-md text-[13px] font-mono font-medium focus:outline-none focus:bg-[#1c2028] shadow-inner border border-[#262a33]" 
                  placeholder="https://example.com" 
                  type="text" 
                />
              </div>

              {pingSuccess && (
                <div className="p-2 rounded-lg bg-[#00a6e0]/15 text-[#7bd0ff] font-code-sm text-[12px] font-mono flex items-center gap-2 border border-[#7bd0ff]/30">
                  <span className="material-symbols-outlined text-[16px]">check_circle</span>
                  <span>{pingSuccess}</span>
                </div>
              )}

              <div className="flex items-center gap-2 text-[#908fa0] font-body-sm text-[12px] mt-1">
                <span className="material-symbols-outlined text-[16px] text-[#ffb4ab]">shield_lock</span>
                <span>Only scan systems that you own or have explicit, documented permission to test. Unauthorized penetration is strictly prohibited.</span>
              </div>
            </div>
          </div>

          {/* Scan Profiles (Cards Selector) */}
          <div className="rounded-xl bg-[#181c24] p-6 shadow-sm border border-[#262a33] flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#c0c1ff] text-[20px]">tune</span>
                <h2 className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold">Attack Profile Strategy</h2>
              </div>
              <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">TACTIC: DYNAMIC_DAST</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Quick Scan */}
              <div 
                onClick={() => setSelectedProfile('quick')}
                className={`relative flex flex-col justify-between p-4 rounded-xl cursor-pointer transition-all border ${
                  selectedProfile === 'quick'
                    ? 'bg-[#262a33] border-[#c0c1ff] shadow-md'
                    : 'bg-[#1c2028] hover:bg-[#262a33] border-[#262a33]'
                }`}
              >
                <div className="flex flex-col gap-1">
                  <div className="flex items-center justify-between">
                    <span className="font-label-lg text-[14px] font-semibold text-[#dfe2ee]">Quick Scan</span>
                    <span className={`material-symbols-outlined text-[18px] ${selectedProfile === 'quick' ? 'text-[#c0c1ff]' : 'text-[#908fa0]'}`}>
                      bolt
                    </span>
                  </div>
                  <p className="font-body-sm text-[12px] text-[#908fa0] leading-snug">
                    Baseline spidering & high-severity passive analysis rules.
                  </p>
                </div>
                <div className="mt-4 flex items-center justify-between pt-1 border-t border-[#262a33]">
                  <span className="font-code-sm text-[11px] text-[#7bd0ff] font-bold font-mono">~3 mins</span>
                  <span className={`h-2.5 w-2.5 rounded-full ${selectedProfile === 'quick' ? 'bg-[#c0c1ff] ring-2 ring-[#8083ff]' : 'bg-[#31353e]'}`}></span>
                </div>
              </div>

              {/* Standard Scan (Recommended) */}
              <div 
                onClick={() => setSelectedProfile('standard')}
                className={`relative flex flex-col justify-between p-4 rounded-xl cursor-pointer transition-all border ${
                  selectedProfile === 'standard'
                    ? 'bg-[#262a33] border-[#c0c1ff] shadow-md'
                    : 'bg-[#1c2028] hover:bg-[#262a33] border-[#262a33]'
                }`}
              >
                <div className="flex flex-col gap-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="font-label-lg text-[14px] font-semibold text-[#c0c1ff]">Standard</span>
                      <span className="px-1.5 py-0.2 rounded bg-[#8083ff] text-[#1000a9] font-code-sm text-[10px] font-bold">REC</span>
                    </div>
                    <span className="material-symbols-outlined text-[18px] text-[#c0c1ff]">verified</span>
                  </div>
                  <p className="font-body-sm text-[12px] text-[#908fa0] leading-snug">
                    Full spider crawl + active injection & OWASP Top 10 rule vectors.
                  </p>
                </div>
                <div className="mt-4 flex items-center justify-between pt-1 border-t border-[#262a33]">
                  <span className="font-code-sm text-[11px] text-[#c0c1ff] font-bold font-mono">~12 mins</span>
                  <span className={`h-2.5 w-2.5 rounded-full ${selectedProfile === 'standard' ? 'bg-[#c0c1ff] ring-2 ring-[#8083ff]' : 'bg-[#31353e]'}`}></span>
                </div>
              </div>

              {/* Deep Scan */}
              <div 
                onClick={() => setSelectedProfile('deep')}
                className={`relative flex flex-col justify-between p-4 rounded-xl cursor-pointer transition-all border ${
                  selectedProfile === 'deep'
                    ? 'bg-[#262a33] border-[#d0bcff] shadow-md'
                    : 'bg-[#1c2028] hover:bg-[#262a33] border-[#262a33]'
                }`}
              >
                <div className="flex flex-col gap-1">
                  <div className="flex items-center justify-between">
                    <span className="font-label-lg text-[14px] font-semibold text-[#dfe2ee]">Deep Scan</span>
                    <span className={`material-symbols-outlined text-[18px] ${selectedProfile === 'deep' ? 'text-[#d0bcff]' : 'text-[#908fa0]'}`}>
                      pest_control
                    </span>
                  </div>
                  <p className="font-body-sm text-[12px] text-[#908fa0] leading-snug">
                    Aggressive spider, AJAX crawler, and full parameter mutation fuzzing.
                  </p>
                </div>
                <div className="mt-4 flex items-center justify-between pt-1 border-t border-[#262a33]">
                  <span className="font-code-sm text-[11px] text-[#d0bcff] font-bold font-mono">~30 mins</span>
                  <span className={`h-2.5 w-2.5 rounded-full ${selectedProfile === 'deep' ? 'bg-[#d0bcff] ring-2 ring-[#a078ff]' : 'bg-[#31353e]'}`}></span>
                </div>
              </div>
            </div>

            {/* Directives Toggles */}
            <div className="flex flex-col gap-4 pt-2">
              <span className="font-code-sm text-[11px] text-[#908fa0] uppercase tracking-wider font-semibold font-mono">
                Engine Directives Configuration
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Traditional Spider */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-[#1c2028] border border-[#262a33]">
                  <div className="flex flex-col">
                    <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold">Traditional Spider</span>
                    <span className="font-code-sm text-[11px] text-[#7bd0ff]">{spiderActive ? 'Active' : 'Disabled'}</span>
                  </div>
                  <button 
                    onClick={() => setSpiderActive(!spiderActive)}
                    className={`w-10 h-6 rounded-full p-0.5 flex items-center transition-colors cursor-pointer ${
                      spiderActive ? 'bg-[#00a6e0] justify-end' : 'bg-[#31353e] justify-start'
                    }`} 
                    type="button"
                  >
                    <div className="w-5 h-5 bg-white rounded-full shadow-md"></div>
                  </button>
                </div>

                {/* Active Scan */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-[#1c2028] border border-[#262a33]">
                  <div className="flex flex-col">
                    <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold">Active Scan</span>
                    <span className="font-code-sm text-[11px] text-[#7bd0ff]">{activeScanActive ? 'Active' : 'Disabled'}</span>
                  </div>
                  <button 
                    onClick={() => setActiveScanActive(!activeScanActive)}
                    className={`w-10 h-6 rounded-full p-0.5 flex items-center transition-colors cursor-pointer ${
                      activeScanActive ? 'bg-[#00a6e0] justify-end' : 'bg-[#31353e] justify-start'
                    }`} 
                    type="button"
                  >
                    <div className="w-5 h-5 bg-white rounded-full shadow-md"></div>
                  </button>
                </div>

                {/* AJAX Spider */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-[#1c2028] border border-[#262a33]">
                  <div className="flex flex-col">
                    <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold">AJAX Spider (Headless)</span>
                    <span className="font-code-sm text-[11px] text-[#c0c1ff]">{ajaxSpiderActive ? 'Enabled' : 'Disabled'}</span>
                  </div>
                  <button 
                    onClick={() => setAjaxSpiderActive(!ajaxSpiderActive)}
                    className={`w-10 h-6 rounded-full p-0.5 flex items-center transition-colors cursor-pointer ${
                      ajaxSpiderActive ? 'bg-[#8083ff] justify-end' : 'bg-[#31353e] justify-start'
                    }`} 
                    type="button"
                  >
                    <div className="w-5 h-5 bg-white rounded-full shadow-md"></div>
                  </button>
                </div>
              </div>

              {/* Max Scan Duration Slider */}
              <div className="p-4 rounded-lg bg-[#1c2028] border border-[#262a33] flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <label className="font-label-md text-[13px] text-[#dfe2ee] font-medium flex items-center gap-2" htmlFor="duration-slider">
                    <span className="material-symbols-outlined text-[16px] text-[#908fa0]">timer</span>
                    <span>Execution Hard Limit (Timeout)</span>
                  </label>
                  <div className="flex items-center gap-1 font-mono text-[#7bd0ff] font-semibold text-[13px]">
                    <span>{timeoutMinutes}</span>
                    <span>minutes</span>
                  </div>
                </div>
                <input 
                  id="duration-slider"
                  value={timeoutMinutes}
                  onChange={(e) => setTimeoutMinutes(Number(e.target.value))}
                  className="w-full h-1.5 bg-[#31353e] rounded-lg appearance-none cursor-pointer accent-[#c0c1ff]" 
                  max="60" 
                  min="5" 
                  step="5" 
                  type="range" 
                />
                <div className="flex justify-between text-[11px] font-code-sm text-[#908fa0] font-mono">
                  <span>5m (Rapid pass)</span>
                  <span>15m (Default)</span>
                  <span>30m</span>
                  <span>60m (Exhaustive)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Strict Authorization Box & Action Bar */}
          <div className="rounded-xl bg-[#181c24] p-6 shadow-sm border border-[#262a33] flex flex-col gap-4">
            <label className="flex items-start gap-3 cursor-pointer select-none">
              <div className="mt-0.5">
                <input 
                  checked={legalAccepted}
                  onChange={(e) => setLegalAccepted(e.target.checked)}
                  className="w-4 h-4 rounded bg-[#31353e] text-[#c0c1ff] accent-[#c0c1ff] cursor-pointer" 
                  type="checkbox" 
                />
              </div>
              <div className="flex flex-col">
                <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold">
                  I confirm explicit, legally authorized testing rights
                </span>
                <span className="font-body-sm text-[12px] text-[#908fa0]">
                  I verify that I hold legitimate ownership or written mandate to execute dynamic vulnerability scans against the specified hostname, and agree to standard security rules of engagement.
                </span>
              </div>
            </label>

            <div className="flex flex-col sm:flex-row items-center gap-3 pt-1">
              <button 
                onClick={handleStartScan}
                disabled={!legalAccepted}
                className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-lg text-[14px] font-bold hover:bg-[#e1e0ff] transition-all shadow-lg shadow-[#c0c1ff]/15 cursor-pointer disabled:opacity-50" 
                type="button"
              >
                <span className="material-symbols-outlined text-[20px]">play_arrow</span>
                <span>Launch OWASP ZAP Assessment</span>
              </button>
              <button 
                onClick={handlePing}
                disabled={isPinging}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-[#1c2028] hover:bg-[#262a33] text-[#7bd0ff] font-label-lg text-[13px] font-semibold transition-colors border border-[#262a33] cursor-pointer" 
                type="button"
              >
                <span className={`material-symbols-outlined text-[18px] ${isPinging ? 'animate-spin' : ''}`}>
                  {isPinging ? 'refresh' : 'wifi_tethering'}
                </span>
                <span>{isPinging ? 'Testing...' : 'Validate Connectivity (Ping)'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Live Scan Progress & Telemetry Pipeline State */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          {/* Live Execution Card */}
          <div className="rounded-xl bg-[#181c24] p-6 shadow-md border border-[#262a33] flex flex-col gap-5">
            {/* Card Header */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className={`h-2 w-2 rounded-full ${pipelineState === 'running' ? 'bg-[#7bd0ff] animate-ping' : 'bg-[#908fa0]'}`}></span>
                  <span className="font-code-sm text-[11px] text-[#7bd0ff] font-bold uppercase tracking-wider font-mono">
                    {pipelineState === 'running' ? 'PIPELINE RUNNING' : pipelineState.toUpperCase()}
                  </span>
                </div>
                <h3 className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold mt-1">Scan Pipeline Status</h3>
                <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">TASK_ID: #ZAP-2025-084</span>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={handleTogglePause}
                  className="p-2 rounded-lg bg-[#1c2028] hover:bg-[#262a33] text-[#dfe2ee] transition-colors border border-[#262a33] cursor-pointer" 
                  title={pipelineState === 'running' ? 'Pause Crawl' : 'Resume Crawl'} 
                  type="button"
                >
                  <span className="material-symbols-outlined text-[18px]">
                    {pipelineState === 'running' ? 'pause' : 'play_arrow'}
                  </span>
                </button>
                <button 
                  onClick={handleAbort}
                  className="px-3 py-2 rounded-lg bg-[#93000a]/20 hover:bg-[#93000a]/50 text-[#ffb4ab] font-code-sm text-[11px] font-semibold transition-colors flex items-center gap-1 border border-[#ffb4ab]/30 cursor-pointer" 
                  title="Cancel Scan" 
                  type="button"
                >
                  <span className="material-symbols-outlined text-[16px]">cancel</span>
                  <span>Abort</span>
                </button>
              </div>
            </div>

            {/* Target & Overall Progress */}
            <div className="p-4 rounded-lg bg-[#1c2028] border border-[#262a33] flex flex-col gap-3">
              <div className="flex items-center justify-between text-[12px] font-body-sm text-[#908fa0]">
                <span>Target: <span className="text-[#dfe2ee] font-semibold font-mono">{targetUrl}</span></span>
                <span>Engine: <span className="text-[#7bd0ff] font-semibold font-mono">OWASP ZAP v2.14</span></span>
              </div>
              <div className="flex flex-col gap-1.5 pt-1">
                <div className="flex items-center justify-between font-code-sm text-[11px] font-mono">
                  <span className="text-[#dfe2ee] font-medium">Stage {activeStage} of 4: Spidering Application Structure</span>
                  <span className="text-[#c0c1ff] font-bold">{progressPercent}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-[#0a0e16] overflow-hidden">
                  <div 
                    className="h-full bg-[#8083ff] rounded-full transition-all duration-500" 
                    style={{ width: `${progressPercent}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* 4-Stage Visual Stepper */}
            <div className="flex flex-col gap-2">
              <span className="font-code-sm text-[11px] text-[#908fa0] uppercase tracking-wider font-semibold font-mono">
                Pipeline Phasing
              </span>
              <div className="flex flex-col gap-2">
                {/* Step 1 */}
                <div className="flex items-center gap-3 p-2.5 rounded-lg bg-[#1c2028]/80 border border-[#262a33]">
                  <div className="w-7 h-7 rounded-full bg-[#00a6e0]/20 text-[#7bd0ff] flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[16px]">check</span>
                  </div>
                  <div className="flex flex-col flex-1 min-w-0">
                    <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold truncate">1. Connecting & Handshake</span>
                    <span className="font-code-sm text-[11px] text-[#7bd0ff] font-medium font-mono">Completed in 840ms</span>
                  </div>
                  <span className="font-code-sm text-[11px] text-[#7bd0ff] uppercase font-semibold font-mono">Done</span>
                </div>

                {/* Step 2: Spidering (Active) */}
                <div className="flex items-center gap-3 p-2.5 rounded-lg bg-[#1c2028] border border-[#8083ff]/40 shadow-inner">
                  <div className="w-7 h-7 rounded-full bg-[#8083ff] text-[#0d0096] flex items-center justify-center shrink-0 animate-pulse">
                    <span className="material-symbols-outlined text-[16px]">hub</span>
                  </div>
                  <div className="flex flex-col flex-1 min-w-0">
                    <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold truncate">2. Spidering Target</span>
                    <span className="font-code-sm text-[11px] text-[#c0c1ff] font-medium font-mono">Crawling DOM nodes & endpoints</span>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-[#8083ff]/20 text-[#c0c1ff] font-code-sm text-[10px] uppercase font-bold font-mono">
                    Active {progressPercent}%
                  </span>
                </div>

                {/* Step 3 */}
                <div className="flex items-center gap-3 p-2.5 rounded-lg bg-[#0a0e16]/40 opacity-70 border border-[#262a33]">
                  <div className="w-7 h-7 rounded-full bg-[#262a33] text-[#908fa0] flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[16px]">security</span>
                  </div>
                  <div className="flex flex-col flex-1 min-w-0">
                    <span className="font-label-md text-[13px] text-[#908fa0] font-semibold truncate">3. Active Vulnerability Scan</span>
                    <span className="font-code-sm text-[11px] text-[#908fa0]">OWASP Top 10 Injection payloads</span>
                  </div>
                  <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Pending</span>
                </div>

                {/* Step 4 */}
                <div className="flex items-center gap-3 p-2.5 rounded-lg bg-[#0a0e16]/40 opacity-70 border border-[#262a33]">
                  <div className="w-7 h-7 rounded-full bg-[#262a33] text-[#d0bcff] flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[16px]">auto_awesome</span>
                  </div>
                  <div className="flex flex-col flex-1 min-w-0">
                    <span className="font-label-md text-[13px] text-[#908fa0] font-semibold truncate">4. Gemini AI Risk Synthesis</span>
                    <span className="font-code-sm text-[11px] text-[#908fa0]">Autonomous root-cause triage</span>
                  </div>
                  <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Pending</span>
                </div>
              </div>
            </div>

            {/* Real-Time Metrics Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-lg bg-[#1c2028] border border-[#262a33] flex flex-col">
                <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">URLs Discovered</span>
                <span className="font-headline-md text-[22px] text-[#dfe2ee] font-mono font-bold mt-0.5">{urlsDiscovered}</span>
                <span className="font-code-sm text-[11px] text-[#7bd0ff] font-medium font-mono mt-1">+12 in last min</span>
              </div>
              <div className="p-3.5 rounded-lg bg-[#1c2028] border border-[#262a33] flex flex-col">
                <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Requests Processed</span>
                <span className="font-headline-md text-[22px] text-[#dfe2ee] font-mono font-bold mt-0.5">{requestsProcessed.toLocaleString()}</span>
                <span className="font-code-sm text-[11px] text-[#908fa0] font-medium font-mono mt-1">28 req/s throughput</span>
              </div>
              <div className="p-3.5 rounded-lg bg-[#1c2028] border border-[#262a33] flex flex-col">
                <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Alerts Detected</span>
                <span className="font-headline-md text-[22px] text-[#ffb4ab] font-mono font-bold mt-0.5">{alertsDetected}</span>
                <span className="font-code-sm text-[11px] text-[#ffb4ab] font-medium font-mono mt-1">Candidate anomalies</span>
              </div>
              <div className="p-3.5 rounded-lg bg-[#1c2028] border border-[#262a33] flex flex-col">
                <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Elapsed Duration</span>
                <span className="font-headline-md text-[22px] text-[#c0c1ff] font-mono font-bold mt-0.5">04m 18s</span>
                <span className="font-code-sm text-[11px] text-[#908fa0] font-medium font-mono mt-1">Est. rem: 06m 40s</span>
              </div>
            </div>

            {/* Live ZAP Request Console */}
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-code-sm text-[11px] text-[#908fa0] uppercase font-mono">
                  <span className="material-symbols-outlined text-[14px]">terminal</span>
                  <span>Live Request Stream</span>
                </div>
                <span className="font-code-sm text-[10px] text-[#7bd0ff] font-mono">BUFFER: 250 LINES</span>
              </div>
              <div className="rounded-lg bg-[#0a0e16] p-3 font-mono text-[11px] text-[#c7c4d7] h-44 overflow-y-auto flex flex-col justify-end space-y-1.5 shadow-inner border border-[#262a33]">
                {logs.map((log, idx) => (
                  <div key={idx} className="flex items-center gap-2 truncate opacity-85">
                    <span className={log.type === 'error' ? 'text-[#ffb4ab] font-bold' : log.type === 'warning' ? 'text-[#c0c1ff] font-bold' : 'text-[#7bd0ff] font-bold'}>
                      {log.method}
                    </span>
                    <span className="text-[#dfe2ee] font-medium truncate">{log.path}</span>
                    <span className="text-[#908fa0] ml-auto shrink-0">[{log.status}] {log.time}</span>
                  </div>
                ))}
                <div className="flex items-center gap-2 text-[#7bd0ff] animate-pulse truncate pt-1 border-t border-[#262a33]">
                  <span>&gt;&gt;</span>
                  <span className="text-[#dfe2ee]">Inspecting response headers for CSP directive omissions...</span>
                </div>
              </div>
            </div>
          </div>

          {/* Co-Pilot Advisory Notice Tile */}
          <div className="rounded-xl bg-[#181c24] p-5 shadow-sm border border-[#262a33] flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-[#a078ff]/20 text-[#d0bcff] flex items-center justify-center shrink-0 border border-[#a078ff]/30">
              <span className="material-symbols-outlined text-[24px]">psychology</span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold">Gemini Autonomous Triage Pre-loaded</span>
              <p className="font-body-sm text-[12px] text-[#908fa0] leading-relaxed">
                Once OWASP ZAP completes injection tests, AI synthesis will automatically map active findings against contextual code repositories to draft verified pull-request remediations.
              </p>
              <button 
                onClick={() => onNavigate('vulnerabilities')}
                className="mt-2 text-[#c0c1ff] hover:underline font-code-sm text-[11px] font-mono flex items-center gap-1 cursor-pointer w-fit"
              >
                <span>View Current Findings Matrix</span>
                <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
