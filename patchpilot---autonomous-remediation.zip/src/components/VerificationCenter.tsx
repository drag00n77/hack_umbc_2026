import React, { useState } from 'react';
import { NavTab } from './Sidebar.tsx';

interface VerificationCenterProps {
  onNavigate: (tab: NavTab) => void;
  onOpenRawLogs?: () => void;
  onOpenBriefModal?: () => void;
}

export const VerificationCenter: React.FC<VerificationCenterProps> = ({ 
  onNavigate,
  onOpenRawLogs,
  onOpenBriefModal
}) => {
  const [selectedFinding, setSelectedFinding] = useState<'sqli' | 'xss' | 'csp'>('sqli');
  const [isFailedDrawerOpen, setIsFailedDrawerOpen] = useState(true);
  const [isBatchRunning, setIsBatchRunning] = useState(false);
  const [batchBtnText, setBatchBtnText] = useState('Batch Rescan All');
  const [isReverifying, setIsReverifying] = useState(false);
  const [reverifyMessage, setReverifyMessage] = useState<string | null>(null);

  const handleBatchRescan = () => {
    setIsBatchRunning(true);
    setBatchBtnText('Executing Rescans...');
    setTimeout(() => {
      setIsBatchRunning(false);
      setBatchBtnText('Completed (3 Probed)');
      setTimeout(() => setBatchBtnText('Batch Rescan All'), 3500);
    }, 2000);
  };

  const handleReverify = () => {
    setIsReverifying(true);
    setTimeout(() => {
      setIsReverifying(false);
      setReverifyMessage('Probe Suite Passed: 64/64 Evasion Vectors Rejected');
      setTimeout(() => setReverifyMessage(null), 4000);
    }, 1800);
  };

  const handleDownloadCert = () => {
    if (onOpenBriefModal) {
      onOpenBriefModal();
    } else {
      alert("Verification Certificate PDF cryptographically signed with SHA256: 9f2e7b...41a8. Download queued.");
    }
  };

  return (
    <div className="flex flex-col w-full">
      <div className="px-6 py-6 flex flex-col gap-6 max-w-[1720px] mx-auto w-full">
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2 font-code-sm text-[11px] text-[#7bd0ff] uppercase tracking-widest font-mono">
              <span className="material-symbols-outlined text-[16px]">verified_user</span>
              <span>Targeted Remediation Assurance Engine</span>
            </div>
            <h1 className="font-headline-xl text-[30px] md:text-[34px] text-[#dfe2ee] font-bold tracking-tight">
              Verification Center
            </h1>
            <p className="font-body-md text-[13px] text-[#908fa0] max-w-2xl leading-relaxed">
              Confirm whether remediation successfully resolved detected vulnerabilities through automated OWASP ZAP active re-probing.
            </p>
          </div>

          <div className="flex items-center gap-3 self-start md:self-auto">
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#262a33] border border-[#31353e]">
              <span className="h-2 w-2 rounded-full bg-[#7bd0ff] animate-pulse"></span>
              <span className="font-code-sm text-[12px] text-[#dfe2ee] font-mono">Live ZAP Session: #VER-2024-SESSION-9</span>
            </div>
            <button 
              onClick={handleBatchRescan}
              disabled={isBatchRunning}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-md text-[13px] font-bold hover:bg-[#e1e0ff] transition-colors shadow-sm cursor-pointer disabled:opacity-75" 
              type="button"
            >
              <span className={`material-symbols-outlined text-[18px] ${isBatchRunning ? 'animate-spin' : ''}`}>
                {isBatchRunning ? 'refresh' : 'rule_folder'}
              </span>
              <span>{batchBtnText}</span>
            </button>
          </div>
        </div>

        {/* End-to-End Remediation Pipeline Stepper */}
        <div className="relative overflow-hidden rounded-xl bg-[#181c24] p-4 shadow-md border border-[#262a33]">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#262a33]">
            <div className="flex items-center gap-2">
              <span className="font-code-sm text-[11px] text-[#dfe2ee] uppercase tracking-wider font-semibold font-mono">
                End-to-End Remediation Pipeline
              </span>
              <span className="font-code-sm text-[11px] text-[#d0bcff] font-medium font-mono">
                ● Autonomous Cycle
              </span>
            </div>
            <div className="font-code-sm text-[11px] text-[#908fa0] font-mono">
              Step 4 → 5 Active Transition: <span className="text-[#7bd0ff] font-semibold">SQLi Sanitization Probed</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div className="flex items-center gap-3 p-3 rounded-lg bg-[#0a0e16] border border-[#262a33]">
              <div className="w-8 h-8 rounded-full bg-[#262a33] flex items-center justify-center shrink-0 text-[#908fa0] font-code-sm text-[12px] font-bold font-mono">1</div>
              <div className="flex flex-col min-w-0">
                <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold truncate">Detected</span>
                <span className="font-code-sm text-[11px] text-[#908fa0] truncate font-mono">OWASP ZAP 14:22</span>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-lg bg-[#0a0e16] border border-[#262a33]">
              <div className="w-8 h-8 rounded-full bg-[#262a33] flex items-center justify-center shrink-0 text-[#908fa0] font-code-sm text-[12px] font-bold font-mono">2</div>
              <div className="flex flex-col min-w-0">
                <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold truncate">Assigned</span>
                <span className="font-code-sm text-[11px] text-[#908fa0] truncate font-mono">SecOps → Backend</span>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-lg bg-[#0a0e16] border border-[#262a33]">
              <div className="w-8 h-8 rounded-full bg-[#262a33] flex items-center justify-center shrink-0 text-[#908fa0] font-code-sm text-[12px] font-bold font-mono">3</div>
              <div className="flex flex-col min-w-0">
                <span className="font-label-md text-[13px] text-[#dfe2ee] font-semibold truncate">Remediated</span>
                <span className="font-code-sm text-[11px] text-[#908fa0] truncate font-mono">git#8f2a1b merged</span>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-lg bg-[#00a6e0]/15 relative overflow-hidden shadow-sm border border-[#7bd0ff]/40">
              <div className="w-8 h-8 rounded-full bg-[#00a6e0]/30 flex items-center justify-center shrink-0 text-[#7bd0ff] font-code-sm text-[12px] font-bold font-mono animate-pulse">4</div>
              <div className="flex flex-col min-w-0 relative z-10">
                <span className="font-label-md text-[13px] text-[#7bd0ff] font-semibold truncate">ZAP Rescan</span>
                <span className="font-code-sm text-[11px] text-[#7bd0ff] font-medium truncate font-mono">Completed (0 err)</span>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-lg bg-[#8083ff]/20 shadow-md border border-[#c0c1ff]/40">
              <div className="w-8 h-8 rounded-full bg-[#c0c1ff] flex items-center justify-center shrink-0 text-[#1000a9] font-code-sm text-[12px] font-bold font-mono">
                <span className="material-symbols-outlined text-[18px]">check</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-label-md text-[13px] text-[#c0c1ff] font-semibold truncate">Verified</span>
                <span className="font-code-sm text-[11px] text-[#908fa0] truncate font-mono">Audit Signed Off</span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Split Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          {/* Left Column: 5 Cols */}
          <div className="xl:col-span-5 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold">Findings Ready for Verification</span>
                <span className="px-2 py-0.5 rounded bg-[#262a33] font-code-sm text-[11px] text-[#dfe2ee] font-semibold font-mono">
                  3 items
                </span>
              </div>
              <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">Prioritized by CVSS</span>
            </div>

            {/* Findings Queue Cards */}
            <div className="flex flex-col gap-3">
              {/* Finding 1 (SQLi) */}
              <div 
                onClick={() => setSelectedFinding('sqli')}
                className={`p-4 rounded-xl shadow-lg transition-all cursor-pointer relative overflow-hidden border ${
                  selectedFinding === 'sqli' 
                    ? 'bg-[#262a33] border-[#c0c1ff]' 
                    : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                }`}
              >
                <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#c0c1ff]"></div>
                <div className="flex items-start justify-between gap-2 pl-2">
                  <div className="flex flex-col gap-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] font-bold uppercase font-mono">
                        CRITICAL CVSS 9.8
                      </span>
                      <span className="font-code-sm text-[11px] text-[#7bd0ff] font-medium font-mono">
                        Selected For Deep Audit
                      </span>
                    </div>
                    <h3 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold truncate">
                      SQL Injection Vulnerability
                    </h3>
                    <div className="font-code-sm text-[11px] text-[#908fa0] flex items-center gap-1.5 font-mono">
                      <span className="material-symbols-outlined text-[14px]">link</span>
                      <span className="truncate">/api/products/search</span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-[#8083ff]/20 text-[#c0c1ff] font-code-sm text-[11px] font-bold font-mono">
                    Ready
                  </span>
                </div>

                <div className="mt-3 pl-2 pt-2 bg-[#0a0e16]/80 p-3 rounded-lg flex flex-col gap-1 border border-[#262a33]">
                  <div className="flex items-center justify-between text-[11px] font-mono">
                    <span className="text-[#908fa0]">Dev Fix Commit:</span>
                    <span className="text-[#7bd0ff] font-bold">git#8f2a1b</span>
                  </div>
                  <p className="font-code-sm text-[11px] text-[#dfe2ee] truncate font-mono">
                    "Add parameterized PostgreSQL query in search handler"
                  </p>
                </div>

                {reverifyMessage && (
                  <div className="mt-2 p-2 rounded bg-[#00a6e0]/15 text-[#7bd0ff] text-[11px] font-mono border border-[#7bd0ff]/30">
                    {reverifyMessage}
                  </div>
                )}

                <div className="mt-3 pl-2 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 text-[11px] font-mono text-[#908fa0]">
                    <span className="material-symbols-outlined text-[16px] text-[#c0c1ff]">security</span>
                    <span>Probed via OWASP ZAP Targeted Probe</span>
                  </div>
                  <button 
                    onClick={handleReverify}
                    disabled={isReverifying}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-md text-[12px] font-bold hover:bg-[#e1e0ff] transition-colors shadow-sm cursor-pointer disabled:opacity-75"
                  >
                    <span className={`material-symbols-outlined text-[16px] ${isReverifying ? 'animate-spin' : ''}`}>
                      {isReverifying ? 'refresh' : 'replay'}
                    </span>
                    <span>{isReverifying ? 'Probing...' : 'Re-verify'}</span>
                  </button>
                </div>
              </div>

              {/* Finding 2 (XSS) */}
              <div 
                onClick={() => setSelectedFinding('xss')}
                className={`p-4 rounded-xl shadow-sm transition-all cursor-pointer border ${
                  selectedFinding === 'xss' 
                    ? 'bg-[#262a33] border-[#7bd0ff]' 
                    : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex flex-col gap-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 rounded bg-[#93000a]/60 text-[#ffb4ab] font-code-sm text-[10px] font-bold uppercase font-mono">
                        HIGH CVSS 7.6
                      </span>
                      <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">Alert ID: #ZAP-40012</span>
                    </div>
                    <h3 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold truncate">
                      Cross-Site Scripting (Reflected)
                    </h3>
                    <div className="font-code-sm text-[11px] text-[#908fa0] flex items-center gap-1.5 font-mono">
                      <span className="material-symbols-outlined text-[14px]">link</span>
                      <span className="truncate">/search?q=</span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-[#262a33] text-[#908fa0] font-code-sm text-[11px] font-mono">
                    Queued
                  </span>
                </div>
                <div className="mt-3 pt-2 flex items-center justify-between text-[11px] font-mono text-[#908fa0] border-t border-[#262a33]">
                  <span>Status: Queued for Rescan</span>
                  <span>Commit: git#9c4e20</span>
                </div>
              </div>

              {/* Finding 3 (CSP) */}
              <div 
                onClick={() => setSelectedFinding('csp')}
                className={`p-4 rounded-xl shadow-sm transition-all cursor-pointer border ${
                  selectedFinding === 'csp' 
                    ? 'bg-[#262a33] border-[#d0bcff]' 
                    : 'bg-[#181c24] hover:bg-[#1c2028] border-[#262a33]'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex flex-col gap-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 rounded bg-[#a078ff]/30 text-[#d0bcff] font-code-sm text-[10px] font-bold uppercase font-mono">
                        MEDIUM CVSS 5.3
                      </span>
                      <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">Alert ID: #ZAP-10038</span>
                    </div>
                    <h3 className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold truncate">
                      Missing Content-Security-Policy (CSP)
                    </h3>
                    <div className="font-code-sm text-[11px] text-[#908fa0] flex items-center gap-1.5 font-mono">
                      <span className="material-symbols-outlined text-[14px]">link</span>
                      <span className="truncate">/</span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-[#00a6e0]/20 text-[#7bd0ff] font-code-sm text-[11px] font-mono">
                    In Testing
                  </span>
                </div>
                <div className="mt-3 pt-2 flex items-center justify-between text-[11px] font-mono text-[#908fa0] border-t border-[#262a33]">
                  <span>Status: Synthetic probes running</span>
                  <span className="text-[#7bd0ff] font-bold">32/45 tests complete</span>
                </div>
              </div>
            </div>

            {/* Verification Velocity Gauge */}
            <div className="p-4 rounded-xl bg-[#181c24] shadow-sm flex flex-col gap-2 border border-[#262a33]">
              <div className="flex items-center justify-between">
                <span className="font-headline-sm text-[15px] text-[#dfe2ee] font-semibold">Verification Velocity</span>
                <span className="font-code-sm text-[11px] text-[#7bd0ff] font-bold font-mono">91.4% Remediation Rate</span>
              </div>
              <div className="flex flex-col gap-1.5">
                <div className="h-2 w-full bg-[#0a0e16] rounded-full overflow-hidden flex">
                  <div className="h-full bg-[#00a6e0]" style={{ width: '82%' }}></div>
                  <div className="h-full bg-[#93000a]" style={{ width: '18%' }}></div>
                </div>
                <div className="flex justify-between font-code-sm text-[11px] text-[#908fa0] font-mono">
                  <span>Verified Clean (38)</span>
                  <span>Failed / Reopened (3)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: 7 Cols */}
          <div className="xl:col-span-7 flex flex-col gap-6">
            {/* Resolved Vulnerability Card */}
            <div className="p-6 rounded-xl bg-[#181c24] shadow-xl flex flex-col gap-4 relative overflow-hidden border border-[#262a33]">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#7bd0ff] via-[#c0c1ff] to-[#7bd0ff]"></div>
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#262a33]">
                <div className="flex items-center gap-3">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#00a6e0]/15 text-[#7bd0ff] font-code-sm text-[11px] font-bold font-mono">
                    <span className="material-symbols-outlined text-[16px]">check_circle</span>
                    <span>REMEDIATION VERIFIED</span>
                  </span>
                  <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">Signed By: Lead SRE • 14:48:12</span>
                </div>
                <span className="font-code-sm text-[11px] text-[#7bd0ff] font-bold font-mono">PASS // ZERO-EXPLOIT</span>
              </div>

              <div className="flex flex-col gap-1">
                <h2 className="font-headline-lg text-[22px] text-[#dfe2ee] font-bold">Security Vulnerability Resolved</h2>
                <p className="font-body-md text-[13px] text-[#908fa0] leading-relaxed">
                  The previously detected security condition was not identified during the latest targeted verification scan. The application successfully rejected active injection payloads.
                </p>
              </div>

              {/* Side-by-side Before/After */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-2 rounded-lg bg-[#0a0e16] border border-[#262a33]">
                <div className="p-3 rounded-lg bg-[#1c2028] flex flex-col gap-1 border border-[#262a33]">
                  <div className="flex items-center justify-between font-mono text-[11px]">
                    <span className="text-[#ffb4ab] font-bold uppercase">Before (Initial Attack)</span>
                    <span className="text-[#908fa0]">14:22:04</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#ffb4ab]"></span>
                    <span className="font-headline-sm text-[14px] text-[#dfe2ee] font-bold">CRITICAL SEVERITY</span>
                  </div>
                  <p className="font-code-sm text-[11px] text-[#908fa0] font-mono">
                    CVSS 9.8 • Vulnerability active. Unescaped input concatenation reached DB parser directly.
                  </p>
                  <div className="mt-2 p-2 rounded bg-[#0a0e16] font-code-sm text-[11px] text-[#ffb4ab] font-mono overflow-x-auto border border-[#262a33]">
                    HTTP 500: syntax error at or near "' OR '1'='1"
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-[#1c2028] flex flex-col gap-1 border border-[#262a33]">
                  <div className="flex items-center justify-between font-mono text-[11px]">
                    <span className="text-[#7bd0ff] font-bold uppercase">After (Targeted Rescan)</span>
                    <span className="text-[#908fa0]">14:48:30</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#7bd0ff]"></span>
                    <span className="font-headline-sm text-[14px] text-[#7bd0ff] font-bold">NOT DETECTED</span>
                  </div>
                  <p className="font-code-sm text-[11px] text-[#908fa0] font-mono">
                    Zero findings • Parameterized bindings verified. Database query sanitization enforced.
                  </p>
                  <div className="mt-2 p-2 rounded bg-[#0a0e16] font-code-sm text-[11px] text-[#7bd0ff] font-mono overflow-x-auto border border-[#262a33]">
                    HTTP 200: {`{"status":"success","items":[],"count":0}`}
                  </div>
                </div>
              </div>

              {/* Verification Telemetry Details Grid */}
              <div className="flex flex-col gap-1.5">
                <span className="font-code-sm text-[11px] text-[#dfe2ee] uppercase tracking-wider font-semibold font-mono">
                  Verification Telemetry Details
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 p-4 rounded-lg bg-[#0a0e16] border border-[#262a33] font-mono text-[11px]">
                  <div className="flex flex-col">
                    <span className="text-[#908fa0] text-[10px] uppercase">Scanner Engine</span>
                    <span className="text-[#dfe2ee] font-bold mt-0.5">OWASP ZAP v2.14</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[#908fa0] text-[10px] uppercase">Payloads Dispatched</span>
                    <span className="text-[#dfe2ee] font-bold mt-0.5">64 SQLi Evasion Vectors</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[#908fa0] text-[10px] uppercase">Verification Scan ID</span>
                    <span className="text-[#7bd0ff] font-bold mt-0.5">#VER-ZAP-9904</span>
                  </div>
                  <div className="flex flex-col sm:col-span-2">
                    <span className="text-[#908fa0] text-[10px] uppercase">Target Probe URL</span>
                    <span className="text-[#dfe2ee] truncate mt-0.5">http://localhost:3000/api/products/search?q=%27+OR+%271%27%3D%271</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[#908fa0] text-[10px] uppercase">HTTP Response Status</span>
                    <span className="text-[#7bd0ff] font-bold mt-0.5">200 OK (Clean JSON)</span>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#262a33]/60 flex items-start gap-3 border border-[#31353e]">
                <span className="material-symbols-outlined text-[18px] text-[#908fa0] shrink-0 mt-0.5">info</span>
                <p className="font-body-sm text-[12px] text-[#c7c4d7]">
                  Verification reflects automated scan results from OWASP ZAP v2.14 and does not guarantee complete absence of all security risk. SecOps sign-off logged cryptographically in immutable compliance ledger.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button 
                  onClick={handleDownloadCert}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#262a33] hover:bg-[#31353e] text-[#dfe2ee] font-label-md text-[13px] transition-colors shadow-sm border border-[#31353e] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px] text-[#7bd0ff]">file_download</span>
                  <span>Download Verification Certificate (PDF)</span>
                </button>
                <button 
                  onClick={() => alert("Jira ticket #SEC-1082 updated to 'Closed - Verified in Staging'.")}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#262a33] hover:bg-[#31353e] text-[#dfe2ee] font-label-md text-[13px] transition-colors shadow-sm border border-[#31353e] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px] text-[#c0c1ff]">sync_alt</span>
                  <span>Update Jira / GitHub Ticket</span>
                </button>
                <button 
                  onClick={() => alert("Viewing raw ZAP daemon socket stream for Job #VER-ZAP-9904.")}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#262a33] hover:bg-[#31353e] text-[#dfe2ee] font-label-md text-[13px] transition-colors shadow-sm ml-auto border border-[#31353e] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">terminal</span>
                  <span>Inspect Raw ZAP Logs</span>
                </button>
              </div>
            </div>

            {/* Attack Payload Evasion Telemetry Wave Chart */}
            <div className="p-4 rounded-xl bg-[#181c24] shadow-md flex flex-col gap-2 border border-[#262a33]">
              <div className="flex items-center justify-between">
                <span className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">Attack Payload Evasion Telemetry Matrix</span>
                <span className="font-code-sm text-[11px] text-[#7bd0ff] font-mono">All 64 Dispatched Payloads Blocked</span>
              </div>
              <div className="w-full overflow-hidden rounded-lg bg-[#0a0e16] border border-[#262a33]">
                <svg className="w-full h-24 p-1" preserveAspectRatio="none" viewBox="0 0 640 80">
                  <defs>
                    <linearGradient id="zapWaveGradient" x1="0%" x2="0%" y1="0%" y2="100%">
                      <stop offset="0%" stopColor="#7bd0ff" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="#7bd0ff" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <path d="M0,60 Q30,55 60,65 T120,40 T180,50 T240,30 T300,55 T360,25 T420,45 T480,20 T540,35 T600,15 L640,25 L640,80 L0,80 Z" fill="url(#zapWaveGradient)" />
                  <path d="M0,60 Q30,55 60,65 T120,40 T180,50 T240,30 T300,55 T360,25 T420,45 T480,20 T540,35 T600,15 L640,25" fill="none" stroke="#7bd0ff" strokeWidth="2" />
                  <line stroke="#262a33" strokeDasharray="4" strokeWidth="1" x1="0" x2="640" y1="20" y2="20" />
                  <line stroke="#262a33" strokeDasharray="4" strokeWidth="1" x1="0" x2="640" y1="50" y2="50" />
                </svg>
                <div className="flex justify-between px-3 py-1.5 font-code-sm text-[11px] text-[#908fa0] bg-[#1c2028] border-t border-[#262a33] font-mono">
                  <span>Probe Sequence: #1 - #20 (Tautologies)</span>
                  <span>#21 - #45 (Union Selects)</span>
                  <span>#46 - #64 (Blind Sleep & Out-of-band)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Failed Verification History Accordion Drawer */}
        <div className="rounded-xl bg-[#181c24] shadow-lg overflow-hidden border border-[#262a33]">
          <button 
            onClick={() => setIsFailedDrawerOpen(!isFailedDrawerOpen)}
            className="w-full p-4 flex items-center justify-between bg-[#262a33] hover:bg-[#31353e] transition-colors text-left cursor-pointer border-b border-[#31353e]" 
            type="button"
          >
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-[#93000a] flex items-center justify-center text-[#ffdad6]">
                <span className="material-symbols-outlined text-[16px]">priority_high</span>
              </div>
              <span className="font-headline-sm text-[16px] text-[#dfe2ee] font-semibold">
                Failed Verification History (1 Issue Detected)
              </span>
              <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] uppercase font-bold font-mono">
                Requires SRE Attention
              </span>
            </div>
            <div className="flex items-center gap-2 font-code-sm text-[12px] text-[#908fa0] font-mono">
              <span>{isFailedDrawerOpen ? 'Collapse' : 'Expand Analysis'}</span>
              <span className={`material-symbols-outlined text-[18px] transition-transform duration-200 ${isFailedDrawerOpen ? '' : '-rotate-90'}`}>
                expand_more
              </span>
            </div>
          </button>

          {isFailedDrawerOpen && (
            <div className="p-6 flex flex-col gap-4 bg-[#181c24]">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-3 border-b border-[#262a33]">
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[10px] font-bold uppercase font-mono">
                      VULNERABILITY STILL DETECTED • HIGH
                    </span>
                    <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">Target: /api/users</span>
                  </div>
                  <h3 className="font-headline-md text-[18px] text-[#dfe2ee] font-semibold">
                    Broken Access Control — Authorization Bypass on Admin Route
                  </h3>
                  <p className="font-body-md text-[13px] text-[#908fa0]">
                    OWASP ZAP re-test probe simulated an unauthenticated caller with modified JWT claims. Endpoint responded with sensitive user records instead of HTTP 403 Forbidden.
                  </p>
                </div>
                <button 
                  onClick={() => onNavigate('remediation-center')}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#93000a] hover:bg-[#ffb4ab] hover:text-[#690005] text-[#ffdad6] font-label-md text-[13px] font-bold transition-colors shadow-sm shrink-0 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">undo</span>
                  <span>Return to Remediation Center</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-[#0a0e16] flex flex-col gap-1 border border-[#262a33]">
                  <div className="flex items-center justify-between font-mono text-[11px]">
                    <span className="text-[#908fa0] uppercase font-semibold">Initial Evidence (ZAP Discovery)</span>
                    <span className="text-[#ffb4ab] font-bold">HTTP 200 OK</span>
                  </div>
                  <pre className="mt-2 p-3 rounded bg-[#1c2028] font-code-sm text-[11px] text-[#dfe2ee] overflow-x-auto leading-relaxed border border-[#262a33] font-mono">
                    GET /api/users HTTP/1.1{'\n'}
                    Host: localhost:3000{'\n'}
                    Authorization: Bearer null{'\n\n'}
                    Response:{'\n'}
                    {`[{"id":1,"role":"superadmin","email":"admin@corp.internal"}]`}
                  </pre>
                </div>

                <div className="p-4 rounded-lg bg-[#0a0e16] flex flex-col gap-1 border border-[#262a33]">
                  <div className="flex items-center justify-between font-mono text-[11px]">
                    <span className="text-[#ffb4ab] font-bold uppercase">Re-scan Evidence (Post-Fix Attempt)</span>
                    <span className="text-[#ffb4ab] font-bold">STILL FAILING • HTTP 200 OK</span>
                  </div>
                  <pre className="mt-2 p-3 rounded bg-[#1c2028] font-code-sm text-[11px] text-[#ffb4ab] overflow-x-auto leading-relaxed border border-[#262a33] font-mono">
                    GET /api/users HTTP/1.1{'\n'}
                    Host: localhost:3000{'\n'}
                    X-Role-Override: anonymous{'\n\n'}
                    Response:{'\n'}
                    {`[{"id":1,"role":"superadmin","email":"admin@corp.internal"}]\n/* Dev fix in commit #7f00a failed to bind middleware to sub-routers */`}
                  </pre>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-[#262a33] font-code-sm text-[11px] text-[#c7c4d7] font-mono border border-[#31353e]">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[16px] text-[#ffb4ab]">report</span>
                  <span>Automated ticket #SEC-1094 reopened automatically. Alert dispatched to Slack channel #security-alerts.</span>
                </div>
                <span className="text-[#dfe2ee] font-bold">Next Scheduled Probe: Paused</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
