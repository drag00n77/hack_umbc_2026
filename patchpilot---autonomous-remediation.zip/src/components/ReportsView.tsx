import React from 'react';

interface ReportsViewProps {
  onOpenBriefModal: () => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ onOpenBriefModal }) => {
  const reports = [
    {
      id: "REP-2026-09-A",
      title: "OWASP Top 10 Executive Risk Assessment",
      date: "September 27, 2026",
      status: "Official Audit",
      findings: "22 total (2 Critical, 4 High)",
      compliance: "SOC 2 Type II Non-Compliant",
      format: "PDF (Board Brief)",
      badge: "READY"
    },
    {
      id: "REP-2026-09-B",
      title: "Attack Path Kill-Chain & Blast Radius Simulation",
      date: "September 26, 2026",
      status: "AI Synthesis",
      findings: "2 Kill-Chains (Database Exfiltration)",
      compliance: "GDPR Art 32 Exposure",
      format: "STIX 2.1 & JSON",
      badge: "DOWNLOADABLE"
    },
    {
      id: "REP-2026-09-C",
      title: "Targeted Remediation Verification Attestation",
      date: "September 25, 2026",
      status: "Signed Audit",
      findings: "4 Verified Remediations",
      compliance: "Zero Exploit Cryptographically Signed",
      format: "Signed PDF + Hash",
      badge: "VERIFIED"
    }
  ];

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-6 max-w-[1720px] mx-auto w-full">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <span className="font-code-sm text-[11px] text-[#7bd0ff] uppercase tracking-wider font-mono">
            Compliance & Attestation Archives
          </span>
          <h1 className="font-headline-xl text-[30px] md:text-[34px] text-[#dfe2ee] font-bold tracking-tight">
            Security Reports & Audits
          </h1>
          <p className="font-body-md text-[13px] text-[#908fa0] mt-1 max-w-2xl">
            Board-ready PDF synopses, cryptographic verification certificates, and STIX threat-intelligence bundles.
          </p>
        </div>

        <button 
          onClick={onOpenBriefModal}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-md text-[13px] font-bold hover:bg-[#e1e0ff] transition-colors shadow-md cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">add_chart</span>
          <span>Generate New Security Brief</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {reports.map((rep) => (
          <div key={rep.id} className="bg-[#181c24] p-5 rounded-xl border border-[#262a33] flex flex-col justify-between shadow-sm">
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">{rep.id}</span>
                <span className="px-2 py-0.5 rounded bg-[#262a33] text-[#7bd0ff] font-code-sm text-[10px] font-bold font-mono">
                  {rep.badge}
                </span>
              </div>
              <h3 className="font-headline-sm text-[16px] text-[#dfe2ee] font-bold mt-1">
                {rep.title}
              </h3>
              <p className="font-code-sm text-[11px] text-[#908fa0] font-mono">{rep.date} • {rep.status}</p>

              <div className="p-3 rounded-lg bg-[#0a0e16] border border-[#262a33] flex flex-col gap-1 mt-2 text-[12px]">
                <div className="text-[#dfe2ee]">• Findings: <span className="text-[#ffb4ab] font-bold">{rep.findings}</span></div>
                <div className="text-[#dfe2ee]">• Compliance: <span className="text-[#7bd0ff]">{rep.compliance}</span></div>
                <div className="text-[#dfe2ee]">• Format: <span className="text-[#c0c1ff]">{rep.format}</span></div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-[#262a33] flex items-center justify-between">
              <button 
                onClick={onOpenBriefModal}
                className="text-[#c0c1ff] hover:underline font-code-sm text-[12px] font-mono flex items-center gap-1 cursor-pointer"
              >
                <span>View Full PDF Synopsis</span>
                <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
