import React, { useState } from 'react';
import { LOGO_URL } from '../data/mockData.ts';

interface ExecutiveBriefModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExecutiveBriefModal: React.FC<ExecutiveBriefModalProps> = ({ isOpen, onClose }) => {
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownloadPdf = () => {
    setDownloading(true);
    setTimeout(() => {
      setDownloading(false);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-fadeIn">
      <div className="w-full max-w-4xl bg-[#181c24] rounded-2xl border border-[#262a33] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 bg-[#262a33] border-b border-[#31353e] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={LOGO_URL} alt="PatchPilot" className="h-7 w-auto" />
            <div className="flex flex-col">
              <span className="font-headline-sm text-[16px] text-[#dfe2ee] font-bold">
                Executive Security Brief & Compliance Attestation
              </span>
              <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">
                Document Ref: PP-BRIEF-2026-Q3 • Hash: 9f2e7b...41a8
              </span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#908fa0] hover:text-[#dfe2ee] hover:bg-[#31353e] transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex flex-col gap-6 text-[#dfe2ee] font-body-md text-[13px]">
          {/* Top synopsis */}
          <div className="p-4 rounded-xl bg-[#0a0e16] border border-[#262a33] flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px] uppercase tracking-wider text-[#7bd0ff] font-bold">
                Target Audit Scope: localhost:3000 (Node.js Express / PostgreSQL)
              </span>
              <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-mono text-[10px] font-bold">
                STATUS: NON-COMPLIANT
              </span>
            </div>
            <p className="text-[#c7c4d7] leading-relaxed">
              This executive brief provides situational visibility for the CISO, Board of Directors, and engineering leadership. PatchPilot autonomously verified perimeter exposure against OWASP Top 10 vectors utilizing the strictly designated OWASP ZAP v2.14 dynamic engine and Gemini 1.5 Pro threat synthesis.
            </p>
          </div>

          {/* Key Metric Bento */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col">
              <span className="text-[10px] text-[#908fa0] uppercase font-mono">Total Findings</span>
              <span className="text-[24px] font-bold text-[#dfe2ee] font-mono">22</span>
              <span className="text-[11px] text-[#ffb4ab] font-mono mt-1">2 Critical Priority</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col">
              <span className="text-[10px] text-[#908fa0] uppercase font-mono">Posture Score</span>
              <span className="text-[24px] font-bold text-[#ffb4ab] font-mono">81%</span>
              <span className="text-[11px] text-[#ffb4ab] font-mono mt-1">High Risk Threshold</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col">
              <span className="text-[10px] text-[#908fa0] uppercase font-mono">Remediated & Verified</span>
              <span className="text-[24px] font-bold text-[#7bd0ff] font-mono">4</span>
              <span className="text-[11px] text-[#7bd0ff] font-mono mt-1">Zero Exploit Proven</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col">
              <span className="text-[10px] text-[#908fa0] uppercase font-mono">Mean Time to Triage</span>
              <span className="text-[24px] font-bold text-[#c0c1ff] font-mono">8m</span>
              <span className="text-[11px] text-[#7bd0ff] font-mono mt-1">Autonomous Speed</span>
            </div>
          </div>

          {/* Urgent Risk Item */}
          <div className="p-4 rounded-xl bg-[#93000a]/15 border border-[#ffb4ab]/30 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-[#ffb4ab] font-bold text-[14px] flex items-center gap-2">
                <span className="material-symbols-outlined text-[18px]">warning</span>
                Immediate Risk Vector: In-Band SQL Injection in /api/products/search
              </span>
              <span className="font-mono text-[11px] text-[#ffb4ab] font-bold">CVSS 9.8</span>
            </div>
            <p className="text-[#c7c4d7]">
              Unauthenticated perimeter requests can execute arbitrary PostgreSQL statements, exposing 142,000 hashed client credentials and billing addresses. Immediate patch deployment is mandated to satisfy SOC 2, HIPAA, and GDPR obligations.
            </p>
          </div>

          {/* Attestation details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col gap-2">
              <span className="font-semibold text-[#dfe2ee]">Regulatory Compliance Impact</span>
              <ul className="flex flex-col gap-1 text-[12px] text-[#c7c4d7]">
                <li>• <strong>SOC 2 Type II:</strong> CC6.1 Logical Access Controls non-compliant.</li>
                <li>• <strong>GDPR Article 32:</strong> Security of processing vulnerable to unauthenticated dump.</li>
                <li>• <strong>PCI-DSS 4.0:</strong> Requirement 6.4.2 public-facing web app protection breached.</li>
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-[#1c2028] border border-[#262a33] flex flex-col gap-2">
              <span className="font-semibold text-[#dfe2ee]">Sign-off & Verification Status</span>
              <div className="flex flex-col gap-1 text-[12px] font-mono text-[#908fa0]">
                <div>Auditor: <span className="text-[#dfe2ee]">PatchPilot Autonomous Engine v4.18</span></div>
                <div>Reviewer: <span className="text-[#dfe2ee]">SecOps Lead (lead@patchpilot.io)</span></div>
                <div>Timestamp: <span className="text-[#dfe2ee]">{new Date().toUTCString()}</span></div>
                <div>Signature: <span className="text-[#7bd0ff]">0x9f2e...7b41a8 (Valid ED25519)</span></div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer CTAs */}
        <div className="p-4 bg-[#262a33] border-t border-[#31353e] flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="text-[11px] text-[#908fa0] font-mono">
            {downloadSuccess ? 'PDF Brief Generated Successfully' : 'Official PDF Ready for Distribution'}
          </span>
          <div className="flex items-center gap-3">
            <button 
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-[#1c2028] text-[#dfe2ee] font-label-md text-[13px] hover:bg-[#31353e] transition-colors border border-[#31353e] cursor-pointer"
            >
              Close
            </button>
            <button 
              onClick={handleDownloadPdf}
              disabled={downloading}
              className="flex items-center gap-2 px-5 py-2 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-md text-[13px] font-bold hover:bg-[#e1e0ff] transition-all cursor-pointer disabled:opacity-75"
            >
              <span className={`material-symbols-outlined text-[18px] ${downloading ? 'animate-spin' : ''}`}>
                {downloading ? 'refresh' : 'download'}
              </span>
              <span>{downloading ? 'Compiling PDF...' : 'Download Official PDF Brief'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
