import React, { useState } from 'react';

interface SlackAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SlackAlertModal: React.FC<SlackAlertModalProps> = ({ isOpen, onClose }) => {
  const [channel, setChannel] = useState('#security-incidents');
  const [severityFilter, setSeverityFilter] = useState<'critical-only' | 'all-high'>('critical-only');
  const [isSending, setIsSending] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSend = () => {
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setSentSuccess(true);
      setTimeout(() => {
        setSentSuccess(false);
        onClose();
      }, 1500);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-fadeIn">
      <div className="w-full max-w-xl bg-[#181c24] rounded-2xl border border-[#262a33] shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 bg-[#262a33] border-b border-[#31353e] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#93000a] text-[#ffdad6] flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px]">campaign</span>
            </div>
            <div className="flex flex-col">
              <h3 className="font-headline-sm text-[16px] text-[#dfe2ee] font-bold">
                Send Critical Security Alert to Slack
              </h3>
              <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">
                Immediate incident response notification
              </span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded text-[#908fa0] hover:text-[#dfe2ee] hover:bg-[#31353e] transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col gap-4 text-[#dfe2ee] font-body-md text-[13px]">
          <div className="flex flex-col gap-1.5">
            <label className="text-[12px] font-semibold text-[#dfe2ee]">Target Slack Channel</label>
            <select 
              value={channel}
              onChange={(e) => setChannel(e.target.value)}
              className="bg-[#0a0e16] text-[#dfe2ee] p-2.5 rounded-lg border border-[#262a33] focus:outline-none focus:border-[#c0c1ff] font-mono text-[12px]"
            >
              <option value="#security-incidents">#security-incidents (SecOps & On-Call)</option>
              <option value="#eng-leadership">#eng-leadership (VP Eng & Directors)</option>
              <option value="#compliance-audit">#compliance-audit (SOC2 & Legal)</option>
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-[12px] font-semibold text-[#dfe2ee]">Alert Scope</label>
            <div className="grid grid-cols-2 gap-2">
              <button 
                type="button"
                onClick={() => setSeverityFilter('critical-only')}
                className={`p-2.5 rounded-lg border text-left font-mono text-[11px] cursor-pointer ${
                  severityFilter === 'critical-only'
                    ? 'bg-[#93000a]/20 border-[#ffb4ab] text-[#ffb4ab]'
                    : 'bg-[#0a0e16] border-[#262a33] text-[#908fa0]'
                }`}
              >
                <div className="font-bold">Critical Severity Only</div>
                <div className="text-[10px] opacity-80">2 Findings (CVSS 9.8 SQLi)</div>
              </button>

              <button 
                type="button"
                onClick={() => setSeverityFilter('all-high')}
                className={`p-2.5 rounded-lg border text-left font-mono text-[11px] cursor-pointer ${
                  severityFilter === 'all-high'
                    ? 'bg-[#a078ff]/20 border-[#d0bcff] text-[#d0bcff]'
                    : 'bg-[#0a0e16] border-[#262a33] text-[#908fa0]'
                }`}
              >
                <div className="font-bold">Critical + High Vectors</div>
                <div className="text-[10px] opacity-80">6 Total Findings</div>
              </button>
            </div>
          </div>

          {/* Slack Message Preview Box */}
          <div className="p-3.5 rounded-xl bg-[#0a0e16] border border-[#262a33] flex flex-col gap-2 font-mono text-[11px]">
            <div className="flex items-center gap-2 text-[#908fa0] text-[10px] uppercase border-b border-[#262a33] pb-1.5">
              <span>Preview Payload for {channel}</span>
            </div>
            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#93000a] text-[#ffdad6] flex items-center justify-center font-bold text-[10px] shrink-0">
                P1
              </div>
              <div className="flex flex-col gap-1 min-w-0">
                <span className="font-bold text-[#ffb4ab]">
                  🚨 [CRITICAL ALERT] SQL Injection confirmed on http://localhost:3000
                </span>
                <span className="text-[#dfe2ee]">
                  • Endpoint: <code className="text-[#7bd0ff]">GET /api/products/search</code> (CVSS 9.8)
                </span>
                <span className="text-[#dfe2ee]">
                  • Threat: Raw PostgreSQL 15 syntax reflection allows customer record extraction.
                </span>
                <span className="text-[#d0bcff]">
                  • Recommended Fix: Bound positional parameterization ready in PR #142.
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#262a33] border-t border-[#31353e] flex items-center justify-between">
          <span className="text-[11px] text-[#908fa0] font-mono">
            {sentSuccess ? 'Alert Dispatched to Slack Webhook!' : 'Automated Webhook Sync'}
          </span>
          <div className="flex items-center gap-2">
            <button 
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg bg-[#1c2028] text-[#dfe2ee] font-label-md text-[12px] hover:bg-[#31353e] transition-colors border border-[#31353e] cursor-pointer"
            >
              Cancel
            </button>
            <button 
              onClick={handleSend}
              disabled={isSending || sentSuccess}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#93000a] text-[#ffdad6] hover:bg-[#ffb4ab] hover:text-[#690005] font-label-md text-[12px] font-bold transition-all cursor-pointer disabled:opacity-75"
            >
              <span className={`material-symbols-outlined text-[16px] ${isSending ? 'animate-spin' : ''}`}>
                {isSending ? 'refresh' : sentSuccess ? 'check' : 'send'}
              </span>
              <span>{isSending ? 'Dispatching...' : sentSuccess ? 'Dispatched!' : 'Broadcast to Slack'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
