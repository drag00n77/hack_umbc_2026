import React, { useState } from 'react';
import { 
  VULNERABILITIES, 
  AUDIENCE_EXPLANATIONS 
} from '../data/mockData.ts';
import { Vulnerability } from '../types/index.ts';
import { NavTab } from './Sidebar.tsx';

interface SecurityOverviewProps {
  onNavigate: (tab: NavTab) => void;
  onOpenSlackModal: () => void;
  onOpenBriefModal: () => void;
}

export const SecurityOverview: React.FC<SecurityOverviewProps> = ({
  onNavigate,
  onOpenSlackModal,
  onOpenBriefModal,
}) => {
  const [selectedVuln, setSelectedVuln] = useState<Vulnerability>(VULNERABILITIES[0]);
  const [activeTab, setActiveTab] = useState<'overview' | 'understand' | 'remediation' | 'verify'>('overview');
  const [audience, setAudience] = useState<'beginner' | 'developer' | 'secops' | 'executive'>('developer');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Interactive scan states
  const [isScanning, setIsScanning] = useState(false);
  const [scanStatusLabel, setScanStatusLabel] = useState('Start Security Scan');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifyStatusLabel, setVerifyStatusLabel] = useState('Run Verification Scan');
  const [isVerifiedSafe, setIsVerifiedSafe] = useState(false);
  const [copiedPatch, setCopiedPatch] = useState(false);
  const [prCreated, setPrCreated] = useState(false);

  const handleStartScan = () => {
    setIsScanning(true);
    setScanStatusLabel('Scanning Target (OWASP ZAP)...');
    setTimeout(() => {
      setIsScanning(false);
      setScanStatusLabel('Scan Completed (22 Findings)');
      setTimeout(() => setScanStatusLabel('Start Security Scan'), 4000);
    }, 2400);
  };

  const handleRunVerify = () => {
    setIsVerifying(true);
    setVerifyStatusLabel('Executing 128 Mutated Payloads...');
    setTimeout(() => {
      setIsVerifying(false);
      setIsVerifiedSafe(true);
      setVerifyStatusLabel('Scan Verified Safe (Zero Exploit)');
    }, 2000);
  };

  const handleCopyPatch = () => {
    if (selectedVuln.remediatedCode) {
      navigator.clipboard.writeText(selectedVuln.remediatedCode);
      setCopiedPatch(true);
      setTimeout(() => setCopiedPatch(false), 2200);
    }
  };

  const handleCreatePr = () => {
    setPrCreated(true);
    setTimeout(() => setPrCreated(false), 3000);
  };

  const filteredVulns = VULNERABILITIES.filter(v => {
    const matchesFilter = filterSeverity === 'all' || v.severity === filterSeverity;
    const matchesSearch = v.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          v.endpoint.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          v.cwe.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const currentAudienceData = AUDIENCE_EXPLANATIONS[audience];

  return (
    <div className="flex flex-col gap-6 p-4 lg:p-8 max-w-[1720px] mx-auto w-full">
      {/* 1. TARGET SCAN CONTROL BAR */}
      <section className="bg-[#181c24] rounded-xl p-4 lg:p-6 shadow-md border border-[#262a33] flex flex-col gap-4">
        <div className="flex flex-col xl:flex-row items-start xl:items-center justify-between gap-4">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-4 w-full xl:w-auto flex-1">
            <div className="flex items-center gap-2 shrink-0">
              <span className="material-symbols-outlined text-[#c0c1ff] text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                lock
              </span>
              <span className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold">Target Environment</span>
            </div>

            <div className="flex items-center gap-3 bg-[#0a0e16] px-4 py-2 rounded-lg w-full md:max-w-md shadow-inner border border-[#262a33]">
              <span className="material-symbols-outlined text-[16px] text-[#908fa0]">terminal</span>
              <input 
                className="bg-transparent font-code-md text-[13px] text-[#dfe2ee] w-full focus:outline-none select-all font-mono" 
                readOnly 
                type="text" 
                value="http://localhost:3000" 
              />
              <span className="px-2 py-0.5 rounded bg-[#262a33] text-[#7bd0ff] font-code-sm text-[11px] font-bold uppercase tracking-wider shrink-0 flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-[#7bd0ff] animate-pulse"></span>
                Live / Reachable
              </span>
            </div>

            <div className="relative flex items-center shrink-0">
              <select className="bg-[#262a33] text-[#dfe2ee] font-label-md text-[13px] px-4 py-2 pr-8 rounded-lg appearance-none cursor-pointer focus:outline-none focus:bg-[#31353e] border border-[#31353e]">
                <option value="zap">Scanner: OWASP ZAP (v2.14)</option>
                <option value="nuclei">Scanner: Nuclei Engine (v3.2)</option>
                <option value="dual">Scanner: Dual Engine Consensus</option>
              </select>
              <span className="material-symbols-outlined text-[18px] text-[#908fa0] absolute right-2 pointer-events-none">
                expand_more
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 w-full xl:w-auto justify-between xl:justify-end">
            <div className="flex flex-col xl:items-end">
              <span className="font-code-sm text-[11px] text-[#dfe2ee] font-mono">Last scan: 2m ago • 48s duration</span>
              <span className="font-code-sm text-[11px] text-[#908fa0]">1,280 security payloads executed</span>
            </div>
            <button 
              onClick={handleStartScan}
              disabled={isScanning}
              className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-lg text-[14px] font-bold hover:bg-[#e1e0ff] transition-all shadow-md active:scale-95 cursor-pointer disabled:opacity-75" 
              type="button"
            >
              <span className={`material-symbols-outlined text-[20px] ${isScanning ? 'animate-spin' : ''}`}>
                {isScanning ? 'progress_activity' : 'radar'}
              </span>
              <span>{scanStatusLabel}</span>
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[#908fa0] font-body-sm text-[12px] pt-1 border-t border-[#262a33]/60 gap-2">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[16px] text-[#7bd0ff]">verified_user</span>
            <span>Authorized perimeter testing mode enabled. Strictly throttled to 25 RPS against target host.</span>
          </div>
          <div className="flex items-center gap-3 font-code-sm text-[11px] text-[#908fa0]">
            <span>Engine Status: <strong className="text-[#dfe2ee]">{isScanning ? 'RUNNING' : 'IDLE'}</strong></span>
            <span>•</span>
            <span>Target Fingerprint: <span className="text-[#dfe2ee]">Node.js Express / PostgreSQL</span></span>
          </div>
        </div>
      </section>

      {/* 2. HORIZONTAL SECURITY METRICS RIBBON */}
      <section className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
        {/* Critical */}
        <div className="bg-[#1c2028] rounded-xl p-4 flex flex-col justify-between shadow-sm relative overflow-hidden group hover:bg-[#262a33] transition-colors border border-[#262a33]">
          <div className="absolute top-0 left-0 right-0 h-1 bg-[#ffb4ab]"></div>
          <div className="flex items-center justify-between">
            <span className="font-label-md text-[12px] text-[#c7c4d7] uppercase tracking-wider font-semibold">Critical Severity</span>
            <span className="flex h-2 w-2 rounded-full bg-[#ffb4ab] animate-ping"></span>
          </div>
          <div className="flex items-baseline gap-3 my-2">
            <span className="font-display-lg text-[44px] font-bold text-[#ffb4ab] leading-none">2</span>
            <span className="font-code-sm text-[11px] text-[#ffb4ab] bg-[#93000a]/50 px-2 py-0.5 rounded font-bold font-mono">+1 new detected</span>
          </div>
          <div className="flex items-center justify-between font-code-sm text-[11px] text-[#908fa0]">
            <span>Immediate Fix Required</span>
            <span className="text-[#ffb4ab] font-bold font-mono">9.0 - 10.0</span>
          </div>
        </div>

        {/* High */}
        <div className="bg-[#1c2028] rounded-xl p-4 flex flex-col justify-between shadow-sm relative overflow-hidden group hover:bg-[#262a33] transition-colors border border-[#262a33]">
          <div className="absolute top-0 left-0 right-0 h-1 bg-[#a078ff]"></div>
          <div className="flex items-center justify-between">
            <span className="font-label-md text-[12px] text-[#c7c4d7] uppercase tracking-wider font-semibold">High Severity</span>
            <span className="material-symbols-outlined text-[16px] text-[#d0bcff]">warning</span>
          </div>
          <div className="flex items-baseline gap-3 my-2">
            <span className="font-display-lg text-[44px] font-bold text-[#d0bcff] leading-none">4</span>
            <span className="font-code-sm text-[11px] text-[#c7c4d7] bg-[#31353e] px-2 py-0.5 rounded font-mono">Unchanged</span>
          </div>
          <div className="flex items-center justify-between font-code-sm text-[11px] text-[#908fa0]">
            <span>Auth & Session Vectors</span>
            <span className="text-[#d0bcff] font-bold font-mono">7.0 - 8.9</span>
          </div>
        </div>

        {/* Medium */}
        <div className="bg-[#1c2028] rounded-xl p-4 flex flex-col justify-between shadow-sm relative overflow-hidden group hover:bg-[#262a33] transition-colors border border-[#262a33]">
          <div className="absolute top-0 left-0 right-0 h-1 bg-[#00a6e0]"></div>
          <div className="flex items-center justify-between">
            <span className="font-label-md text-[12px] text-[#c7c4d7] uppercase tracking-wider font-semibold">Medium Severity</span>
            <span className="material-symbols-outlined text-[16px] text-[#7bd0ff]">tune</span>
          </div>
          <div className="flex items-baseline gap-3 my-2">
            <span className="font-display-lg text-[44px] font-bold text-[#7bd0ff] leading-none">7</span>
            <span className="font-code-sm text-[11px] text-[#7bd0ff] bg-[#31353e] px-2 py-0.5 rounded font-mono">-2 resolved</span>
          </div>
          <div className="flex items-center justify-between font-code-sm text-[11px] text-[#908fa0]">
            <span>Config & Headers</span>
            <span className="text-[#7bd0ff] font-bold font-mono">4.0 - 6.9</span>
          </div>
        </div>

        {/* Low / Info */}
        <div className="bg-[#1c2028] rounded-xl p-4 flex flex-col justify-between shadow-sm relative overflow-hidden group hover:bg-[#262a33] transition-colors border border-[#262a33]">
          <div className="absolute top-0 left-0 right-0 h-1 bg-[#464554]"></div>
          <div className="flex items-center justify-between">
            <span className="font-label-md text-[12px] text-[#c7c4d7] uppercase tracking-wider font-semibold">Low / Informational</span>
            <span className="material-symbols-outlined text-[16px] text-[#908fa0]">info</span>
          </div>
          <div className="flex items-baseline gap-3 my-2">
            <span className="font-display-lg text-[44px] font-bold text-[#908fa0] leading-none">9</span>
            <span className="font-code-sm text-[11px] text-[#908fa0] bg-[#31353e] px-2 py-0.5 rounded font-mono">Telemetry</span>
          </div>
          <div className="flex items-center justify-between font-code-sm text-[11px] text-[#908fa0]">
            <span>Footprinting & Banners</span>
            <span className="text-[#908fa0] font-bold font-mono">0.1 - 3.9</span>
          </div>
        </div>

        {/* Total & Posture Gauge */}
        <div className="col-span-2 md:col-span-3 xl:col-span-1 bg-[#262a33] rounded-xl p-4 flex flex-col justify-between shadow-sm border border-[#31353e]">
          <div className="flex items-center justify-between">
            <span className="font-label-md text-[12px] text-[#dfe2ee] font-semibold uppercase tracking-wider">Security Posture</span>
            <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[11px] font-bold tracking-wider">HIGH RISK</span>
          </div>
          <div className="flex items-center gap-4 my-2">
            <div className="flex flex-col">
              <span className="font-display-lg text-[44px] font-bold text-[#dfe2ee] leading-none">22</span>
              <span className="font-code-sm text-[11px] text-[#908fa0]">Total Findings</span>
            </div>
            {/* SVG Donut */}
            <div className="relative w-14 h-14 ml-auto">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                <path className="text-[#31353e]" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3.5" />
                <path className="text-[#7bd0ff]" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeDasharray="18, 100" strokeLinecap="round" strokeWidth="3.5" />
                <path className="text-[#ffb4ab]" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeDasharray="12, 100" strokeDashoffset="-20" strokeLinecap="round" strokeWidth="3.5" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center font-code-sm text-[12px] font-bold text-[#dfe2ee]">
                81%
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between font-code-sm text-[11px] text-[#908fa0] pt-1">
            <span><strong className="text-[#7bd0ff]">4</strong> Verified</span>
            <span>•</span>
            <span><strong className="text-[#ffb4ab]">18</strong> Unresolved</span>
          </div>
        </div>
      </section>

      {/* 3. AI PRIORITY QUEUE SECTION */}
      <section className="flex flex-col gap-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-gradient-to-r from-[#262a33] to-[#181c24] p-4 rounded-xl shadow-md border border-[#31353e]">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-[#a078ff] flex items-center justify-center text-[#3c0091] shadow-md">
              <span className="material-symbols-outlined text-[24px]">auto_awesome</span>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-3">
                <span className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold">Autonomous AI Priority Queue</span>
                <span className="px-2 py-0.5 rounded bg-[#a078ff] text-[#340080] font-code-sm text-[11px] font-bold uppercase">Gemini 1.5 Pro</span>
              </div>
              <p className="font-body-sm text-[12px] text-[#c7c4d7]">Triaged in real-time by business exploitability, data perimeter sensitivity, and verified scanner proofs.</p>
            </div>
          </div>
          <div className="flex items-center gap-2 font-code-sm text-[12px] text-[#c7c4d7]">
            <span className="material-symbols-outlined text-[16px] text-[#d0bcff]">bolt</span>
            <span>Next Auto-Triage: Continuous</span>
          </div>
        </div>

        {/* Priority Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Priority 1 */}
          <div className="bg-[#181c24] rounded-xl p-5 flex flex-col justify-between shadow-md relative overflow-hidden group border border-[#262a33] hover:border-[#ffb4ab]/40 transition-all">
            <div className="absolute -top-12 -right-12 w-32 h-32 bg-[#c0c1ff]/10 rounded-full blur-2xl pointer-events-none"></div>
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[11px] font-bold uppercase">Priority #1</span>
                  <span className="px-2 py-0.5 rounded bg-[#93000a]/40 text-[#ffb4ab] font-code-sm text-[11px] font-semibold">CVSS 9.8</span>
                </div>
                <span className="px-2 py-0.5 rounded bg-[#31353e] text-[#7bd0ff] font-code-sm text-[11px] flex items-center gap-1 font-mono">
                  <span className="material-symbols-outlined text-[13px]">psychology</span>
                  98% AI Confidence
                </span>
              </div>
              <h3 className="font-headline-sm text-[18px] text-[#dfe2ee] font-bold group-hover:text-[#c0c1ff] transition-colors">
                SQL Injection via Query Parameter
              </h3>
              <div className="flex items-center gap-2 my-2 font-code-sm text-[12px] text-[#c7c4d7] bg-[#1c2028] px-3 py-1.5 rounded-lg border border-[#262a33]">
                <span className="text-[#ffb4ab] font-bold">GET</span>
                <span className="truncate font-mono">/api/products/search</span>
              </div>
              <div className="my-4 flex flex-col gap-2">
                <span className="font-code-sm text-[11px] uppercase tracking-wider text-[#908fa0] font-semibold">Key Attack Drivers:</span>
                <ul className="flex flex-col gap-1.5 font-body-sm text-[12px] text-[#c7c4d7]">
                  <li className="flex items-start gap-2">
                    <span className="material-symbols-outlined text-[16px] text-[#ffb4ab] shrink-0 mt-0.5">crisis_alert</span>
                    <span>Unauthenticated endpoint exposing direct PostgreSQL syntax errors.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="material-symbols-outlined text-[16px] text-[#ffb4ab] shrink-0 mt-0.5">database</span>
                    <span>Full database extraction possible; sensitive user credential hashes at risk.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="material-symbols-outlined text-[16px] text-[#d0bcff] shrink-0 mt-0.5">policy</span>
                    <span>Direct compliance breach (SOC2 & GDPR critical severity).</span>
                  </li>
                </ul>
              </div>
            </div>
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
              <button 
                onClick={() => {
                  setSelectedVuln(VULNERABILITIES[0]);
                  setActiveTab('understand');
                }}
                className="w-full py-2 px-4 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-md text-[13px] font-semibold flex items-center justify-center gap-2 hover:bg-[#e1e0ff] transition-colors shadow-sm cursor-pointer" 
                type="button"
              >
                <span className="material-symbols-outlined text-[18px]">rule</span>
                <span>Investigate Finding</span>
              </button>
              <button 
                onClick={onOpenSlackModal}
                className="w-full sm:w-auto py-2 px-3 rounded-lg bg-[#262a33] text-[#ffb4ab] hover:bg-[#93000a] hover:text-[#ffdad6] transition-colors flex items-center justify-center gap-2 shrink-0 border border-[#31353e] cursor-pointer" 
                title="Send to Slack"
                type="button"
              >
                <span className="material-symbols-outlined text-[16px]">campaign</span>
                <span className="sm:hidden text-xs">Alert Slack</span>
              </button>
            </div>
          </div>

          {/* Priority 2 */}
          <div className="bg-[#181c24] rounded-xl p-5 flex flex-col justify-between shadow-md relative overflow-hidden group hover:bg-[#1c2028] transition-colors border border-[#262a33]">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-[#262a33] text-[#dfe2ee] font-code-sm text-[11px] font-bold uppercase">Priority #2</span>
                  <span className="px-2 py-0.5 rounded bg-[#a078ff]/30 text-[#d0bcff] font-code-sm text-[11px] font-semibold">CVSS 8.5</span>
                </div>
                <span className="px-2 py-0.5 rounded bg-[#31353e] text-[#7bd0ff] font-code-sm text-[11px] flex items-center gap-1 font-mono">
                  <span className="material-symbols-outlined text-[13px]">psychology</span>
                  94% AI Confidence
                </span>
              </div>
              <h3 className="font-headline-sm text-[18px] text-[#dfe2ee] font-bold group-hover:text-[#c0c1ff] transition-colors">
                Broken Authentication: JWT Weak Key
              </h3>
              <div className="flex items-center gap-2 my-2 font-code-sm text-[12px] text-[#c7c4d7] bg-[#1c2028] px-3 py-1.5 rounded-lg border border-[#262a33]">
                <span className="text-[#d0bcff] font-bold">POST</span>
                <span className="truncate font-mono">/api/v1/auth/jwt-refresh</span>
              </div>
              <div className="my-4 flex flex-col gap-2">
                <span className="font-code-sm text-[11px] uppercase tracking-wider text-[#908fa0] font-semibold">Key Attack Drivers:</span>
                <ul className="flex flex-col gap-1.5 font-body-sm text-[12px] text-[#c7c4d7]">
                  <li className="flex items-start gap-2">
                    <span className="material-symbols-outlined text-[16px] text-[#d0bcff] shrink-0 mt-0.5">key_off</span>
                    <span>Weak HMAC-SHA256 secret subject to rapid dictionary offline crack.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="material-symbols-outlined text-[16px] text-[#d0bcff] shrink-0 mt-0.5">shield_person</span>
                    <span>Enables forging arbitrary SecOps and Admin bearer tokens.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="material-symbols-outlined text-[16px] text-[#908fa0] shrink-0 mt-0.5">sync_problem</span>
                    <span>Zero refresh-token revocation list implemented in Redis.</span>
                  </li>
                </ul>
              </div>
            </div>
            <div className="pt-2">
              <button 
                onClick={() => onNavigate('attack-paths')}
                className="w-full py-2 px-4 rounded-lg bg-[#262a33] text-[#dfe2ee] font-label-md text-[13px] hover:bg-[#31353e] transition-colors flex items-center justify-center gap-2 border border-[#31353e] cursor-pointer" 
                type="button"
              >
                <span>View Exploit Chain</span>
                <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
              </button>
            </div>
          </div>

          {/* Priority 3 */}
          <div className="bg-[#181c24] rounded-xl p-5 flex flex-col justify-between shadow-md relative overflow-hidden group hover:bg-[#1c2028] transition-colors border border-[#262a33]">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-[#262a33] text-[#dfe2ee] font-code-sm text-[11px] font-bold uppercase">Priority #3</span>
                  <span className="px-2 py-0.5 rounded bg-[#a078ff]/30 text-[#d0bcff] font-code-sm text-[11px] font-semibold">CVSS 7.6</span>
                </div>
                <span className="px-2 py-0.5 rounded bg-[#31353e] text-[#7bd0ff] font-code-sm text-[11px] flex items-center gap-1 font-mono">
                  <span className="material-symbols-outlined text-[13px]">psychology</span>
                  91% AI Confidence
                </span>
              </div>
              <h3 className="font-headline-sm text-[18px] text-[#dfe2ee] font-bold group-hover:text-[#c0c1ff] transition-colors">
                Stored Cross-Site Scripting (XSS)
              </h3>
              <div className="flex items-center gap-2 my-2 font-code-sm text-[12px] text-[#c7c4d7] bg-[#1c2028] px-3 py-1.5 rounded-lg border border-[#262a33]">
                <span className="text-[#d0bcff] font-bold">POST</span>
                <span className="truncate font-mono">/dashboard/team/comments</span>
              </div>
              <div className="my-4 flex flex-col gap-2">
                <span className="font-code-sm text-[11px] uppercase tracking-wider text-[#908fa0] font-semibold">Key Attack Drivers:</span>
                <ul className="flex flex-col gap-1.5 font-body-sm text-[12px] text-[#c7c4d7]">
                  <li className="flex items-start gap-2">
                    <span className="material-symbols-outlined text-[16px] text-[#d0bcff] shrink-0 mt-0.5">code_blocks</span>
                    <span>Unescaped markdown parser renders raw script tags directly in DOM.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="material-symbols-outlined text-[16px] text-[#d0bcff] shrink-0 mt-0.5">admin_panel_settings</span>
                    <span>Payload executes in active triage session of security administrators.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="material-symbols-outlined text-[16px] text-[#908fa0] shrink-0 mt-0.5">badge</span>
                    <span>Session cookie lacks HttpOnly flag, permitting theft via document.cookie.</span>
                  </li>
                </ul>
              </div>
            </div>
            <div className="pt-2">
              <button 
                onClick={() => onNavigate('attack-paths')}
                className="w-full py-2 px-4 rounded-lg bg-[#262a33] text-[#dfe2ee] font-label-md text-[13px] hover:bg-[#31353e] transition-colors flex items-center justify-center gap-2 border border-[#31353e] cursor-pointer" 
                type="button"
              >
                <span>View Exploit Chain</span>
                <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 4. MAIN VULNERABILITY WORKSPACE (High-density Split-Screen Layout) */}
      <section className="grid grid-cols-1 xl:grid-cols-12 gap-4 items-start">
        {/* LEFT PANEL: Scrollable Vulnerability Feed (5 cols on XL) */}
        <div className="xl:col-span-5 bg-[#181c24] rounded-xl p-4 flex flex-col gap-4 shadow-sm border border-[#262a33]">
          {/* Controls & Filter Bar */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-headline-sm text-[18px] text-[#dfe2ee] font-semibold">Vulnerability Matrix</span>
                <span className="px-2 py-0.5 rounded bg-[#31353e] text-[#dfe2ee] font-code-sm text-[11px] font-bold font-mono">
                  {filteredVulns.length} Total
                </span>
              </div>
              <button 
                onClick={() => { setFilterSeverity('all'); setSearchQuery(''); }}
                className="text-[#908fa0] hover:text-[#dfe2ee] font-code-sm text-[11px] flex items-center gap-1 cursor-pointer" 
                type="button"
              >
                <span className="material-symbols-outlined text-[16px]">filter_list</span>
                Reset
              </button>
            </div>

            {/* Search Input */}
            <div className="relative flex items-center bg-[#0a0e16] rounded-lg px-3 py-1.5 shadow-inner border border-[#262a33]">
              <span className="material-symbols-outlined text-[18px] text-[#908fa0] mr-2">search</span>
              <input 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent font-body-sm text-[13px] text-[#dfe2ee] w-full focus:outline-none placeholder:text-[#908fa0]/60" 
                placeholder="Search vulnerability, CVE, or path..." 
                type="text" 
              />
              <span className="font-code-sm text-[11px] text-[#908fa0] bg-[#1c2028] px-1.5 py-0.5 rounded font-mono border border-[#262a33]">⌘K</span>
            </div>

            {/* Filter Pills */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <button 
                onClick={() => setFilterSeverity('all')}
                className={`px-2.5 py-1 rounded text-[12px] font-label-md font-medium cursor-pointer transition-colors ${
                  filterSeverity === 'all' ? 'bg-[#c0c1ff] text-[#1000a9] font-bold' : 'bg-[#1c2028] text-[#c7c4d7] hover:bg-[#262a33]'
                }`}
              >
                All (22)
              </button>
              <button 
                onClick={() => setFilterSeverity('critical')}
                className={`px-2.5 py-1 rounded text-[12px] font-label-md font-medium cursor-pointer transition-colors ${
                  filterSeverity === 'critical' ? 'bg-[#ffb4ab] text-[#690005] font-bold' : 'bg-[#93000a]/30 text-[#ffb4ab] hover:bg-[#93000a]/50'
                }`}
              >
                Critical (2)
              </button>
              <button 
                onClick={() => setFilterSeverity('high')}
                className={`px-2.5 py-1 rounded text-[12px] font-label-md font-medium cursor-pointer transition-colors ${
                  filterSeverity === 'high' ? 'bg-[#a078ff] text-[#340080] font-bold' : 'bg-[#1c2028] text-[#d0bcff] hover:bg-[#262a33]'
                }`}
              >
                High (4)
              </button>
              <button 
                onClick={() => setFilterSeverity('medium')}
                className={`px-2.5 py-1 rounded text-[12px] font-label-md font-medium cursor-pointer transition-colors ${
                  filterSeverity === 'medium' ? 'bg-[#00a6e0] text-[#00374d] font-bold' : 'bg-[#1c2028] text-[#7bd0ff] hover:bg-[#262a33]'
                }`}
              >
                Med (7)
              </button>
              <button 
                onClick={() => setFilterSeverity('low')}
                className={`px-2.5 py-1 rounded text-[12px] font-label-md font-medium cursor-pointer transition-colors ${
                  filterSeverity === 'low' ? 'bg-[#dfe2ee] text-[#1c2028] font-bold' : 'bg-[#1c2028] text-[#908fa0] hover:bg-[#262a33]'
                }`}
              >
                Low (9)
              </button>
            </div>
          </div>

          {/* Vulnerability Items List */}
          <div className="flex flex-col gap-2 max-h-[740px] overflow-y-auto pr-1">
            {filteredVulns.map((vuln) => {
              const isSelected = selectedVuln.id === vuln.id;
              return (
                <div
                  key={vuln.id}
                  onClick={() => setSelectedVuln(vuln)}
                  className={`p-3 rounded-xl cursor-pointer relative shadow-sm transition-all border ${
                    isSelected 
                      ? 'bg-[#31353e] border-[#c0c1ff]/60 shadow-[0_0_12px_rgba(192,193,255,0.15)]' 
                      : 'bg-[#1c2028] hover:bg-[#262a33] border-[#262a33]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded font-code-sm text-[10px] font-bold uppercase ${
                        vuln.severity === 'critical' ? 'bg-[#93000a] text-[#ffdad6]' :
                        vuln.severity === 'high' ? 'bg-[#a078ff]/30 text-[#d0bcff]' :
                        vuln.severity === 'medium' ? 'bg-[#00a6e0]/30 text-[#7bd0ff]' : 'bg-[#31353e] text-[#908fa0]'
                      }`}>
                        {vuln.severity}
                      </span>
                      <span className="font-code-sm text-[11px] text-[#908fa0]">Priority #{vuln.priority}</span>
                    </div>
                    <span className={`px-2 py-0.2 rounded font-code-sm text-[10px] font-mono font-bold ${
                      vuln.status === 'Remediated' || vuln.status === 'Verified' 
                        ? 'bg-[#00a6e0]/20 text-[#7bd0ff]' 
                        : 'bg-[#0a0e16] text-[#dfe2ee]'
                    }`}>
                      {vuln.status}
                    </span>
                  </div>

                  <div className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold mt-1.5">{vuln.name}</div>
                  <div className="font-code-sm text-[11px] text-[#7bd0ff] truncate mt-0.5 font-mono">{vuln.endpoint}</div>

                  <div className="flex items-center justify-between font-code-sm text-[11px] text-[#908fa0] mt-2 pt-1.5 border-t border-[#262a33]">
                    <span className="flex items-center gap-1 font-mono">
                      <span className="material-symbols-outlined text-[13px] text-[#c0c1ff]">security</span>
                      {vuln.scanner}
                    </span>
                    <span className="font-mono">CVSS {vuln.cvss} • Conf: {vuln.confidence}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT DETAIL PANEL: Comprehensive Workspace with 4 Interactive Tabs (7 cols on XL) */}
        <div className="xl:col-span-7 bg-[#181c24] rounded-xl p-4 lg:p-6 flex flex-col gap-4 shadow-sm border border-[#262a33]">
          {/* Header of Selected Item */}
          <div className="flex flex-col gap-3 pb-3 border-b border-[#262a33]">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-[#93000a] text-[#ffdad6] font-code-sm text-[11px] font-bold uppercase font-mono">
                  {selectedVuln.severity.toUpperCase()} • CVSS {selectedVuln.cvss}
                </span>
                <span className="px-2 py-0.5 rounded bg-[#31353e] text-[#dfe2ee] font-code-sm text-[11px] font-mono">
                  Status: {selectedVuln.status}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-[#262a33] text-[#7bd0ff] font-code-sm text-[11px] flex items-center gap-1 font-mono">
                  <span className="material-symbols-outlined text-[14px]">verified</span>
                  Factual Evidence: Confirmed
                </span>
                <span className="px-2 py-0.5 rounded bg-[#a078ff]/30 text-[#d0bcff] font-code-sm text-[11px] flex items-center gap-1 font-mono">
                  <span className="material-symbols-outlined text-[14px]">auto_awesome</span>
                  Gemini 1.5 Pro
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h2 className="font-headline-lg text-[24px] text-[#dfe2ee] font-bold">
                {selectedVuln.name}
              </h2>
              <div className="flex items-center gap-2 shrink-0">
                <button 
                  onClick={onOpenBriefModal}
                  className="p-2 rounded bg-[#1c2028] hover:bg-[#262a33] text-[#c7c4d7] hover:text-[#dfe2ee] transition-colors border border-[#262a33] cursor-pointer" 
                  title="Export Finding Summary" 
                  type="button"
                >
                  <span className="material-symbols-outlined text-[18px]">download</span>
                </button>
                <button 
                  onClick={() => onNavigate('remediation-center')}
                  className="p-2 rounded bg-[#1c2028] hover:bg-[#262a33] text-[#c7c4d7] hover:text-[#dfe2ee] transition-colors border border-[#262a33] cursor-pointer" 
                  title="Send to Remediation Center" 
                  type="button"
                >
                  <span className="material-symbols-outlined text-[18px]">build_circle</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-[#0a0e16] px-3 py-1.5 rounded-lg font-code-sm text-[12px] text-[#dfe2ee] w-fit max-w-full border border-[#262a33]">
              <span className="text-[#ffb4ab] font-bold font-mono">{selectedVuln.method}</span>
              <span className="truncate font-mono">{selectedVuln.endpoint}</span>
              <button 
                onClick={() => navigator.clipboard.writeText(selectedVuln.endpoint)}
                className="ml-2 text-[#908fa0] hover:text-[#c0c1ff] transition-colors cursor-pointer" 
                title="Copy endpoint URL" 
                type="button"
              >
                <span className="material-symbols-outlined text-[14px]">content_copy</span>
              </button>
            </div>
          </div>

          {/* TAB NAVIGATION BAR */}
          <div className="flex items-center gap-1 bg-[#0a0e16] p-1 rounded-lg border border-[#262a33]">
            <button 
              onClick={() => setActiveTab('overview')}
              className={`flex-1 py-2 px-3 rounded-md font-label-md text-[13px] text-center transition-all cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-[#262a33] text-[#c0c1ff] font-bold shadow-sm'
                  : 'text-[#908fa0] hover:text-[#dfe2ee] font-medium'
              }`}
              type="button"
            >
              1. Overview
            </button>
            <button 
              onClick={() => setActiveTab('understand')}
              className={`flex-1 py-2 px-3 rounded-md font-label-md text-[13px] text-center transition-all cursor-pointer ${
                activeTab === 'understand'
                  ? 'bg-[#262a33] text-[#c0c1ff] font-bold shadow-sm'
                  : 'text-[#908fa0] hover:text-[#dfe2ee] font-medium'
              }`}
              type="button"
            >
              2. Understand (AI)
            </button>
            <button 
              onClick={() => setActiveTab('remediation')}
              className={`flex-1 py-2 px-3 rounded-md font-label-md text-[13px] text-center transition-all cursor-pointer ${
                activeTab === 'remediation'
                  ? 'bg-[#262a33] text-[#c0c1ff] font-bold shadow-sm'
                  : 'text-[#908fa0] hover:text-[#dfe2ee] font-medium'
              }`}
              type="button"
            >
              3. Remediation
            </button>
            <button 
              onClick={() => setActiveTab('verify')}
              className={`flex-1 py-2 px-3 rounded-md font-label-md text-[13px] text-center transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'verify'
                  ? 'bg-[#262a33] text-[#c0c1ff] font-bold shadow-sm'
                  : 'text-[#908fa0] hover:text-[#dfe2ee] font-medium'
              }`}
              type="button"
            >
              <span>4. Verify</span>
              <span className="h-1.5 w-1.5 rounded-full bg-[#7bd0ff]"></span>
            </button>
          </div>

          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="flex flex-col gap-4 animate-fadeIn">
              <div className="bg-[#1c2028] rounded-xl p-4 flex flex-col gap-2 border border-[#262a33]">
                <span className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold">Vulnerability Summary</span>
                <p className="font-body-md text-[13px] text-[#c7c4d7] leading-relaxed">
                  {selectedVuln.summary}
                </p>
              </div>

              {/* Technical Scanner Evidence Card */}
              <div className="bg-[#0a0e16] rounded-xl p-4 flex flex-col gap-3 shadow-inner border border-[#262a33]">
                <div className="flex items-center justify-between pb-2 border-b border-[#262a33]">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#7bd0ff] text-[18px]">terminal</span>
                    <span className="font-code-md text-[13px] text-[#dfe2ee] font-semibold font-mono">
                      Technical Scanner Evidence ({selectedVuln.scanner} v2.14)
                    </span>
                  </div>
                  <span className="font-code-sm text-[11px] text-[#7bd0ff] bg-[#1c2028] px-2 py-0.5 rounded font-mono border border-[#262a33]">
                    Payload Verified
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 font-code-sm text-[11px] font-mono pt-1">
                  <div><span className="text-[#908fa0]">Request Method:</span> <strong className="text-[#dfe2ee] ml-1">{selectedVuln.method}</strong></div>
                  <div><span className="text-[#908fa0]">Target Parameter:</span> <strong className="text-[#ffb4ab] ml-1">{selectedVuln.parameter || 'q'}</strong></div>
                  <div><span className="text-[#908fa0]">Response Status:</span> <strong className="text-[#ffb4ab] ml-1">{selectedVuln.responseStatus || '500 Server Error'}</strong></div>
                  <div><span className="text-[#908fa0]">Scanner Confidence:</span> <strong className="text-[#7bd0ff] ml-1">High ({selectedVuln.confidence}%)</strong></div>
                </div>

                <div className="flex flex-col gap-1 mt-2">
                  <span className="font-code-sm text-[11px] text-[#908fa0]">Executed Proof-of-Concept Attack Payload:</span>
                  <pre className="bg-[#262a33] p-3 rounded font-code-sm text-[11px] text-[#ffb4ab] overflow-x-auto select-all font-mono border border-[#31353e]">
                    {selectedVuln.payload || "/api/products/search?q=test' UNION SELECT null,username,password_hash FROM users--"}
                  </pre>
                </div>

                <div className="flex flex-col gap-1">
                  <span className="font-code-sm text-[11px] text-[#908fa0]">Target System Error Output Observed:</span>
                  <pre className="bg-[#262a33] p-3 rounded font-code-sm text-[11px] text-[#c7c4d7] overflow-x-auto font-mono border border-[#31353e]">
                    {selectedVuln.errorOutput || 'PostgreSQL ERROR: 42601: syntax error at or near "UNION" at character 54'}
                  </pre>
                </div>
              </div>

              {/* Factual Distinction Callout */}
              <div className="flex items-start gap-3 p-3 rounded-lg bg-[#262a33]/60 text-[#c7c4d7] font-body-sm text-[12px] border border-[#31353e]">
                <span className="material-symbols-outlined text-[18px] text-[#d0bcff] shrink-0 mt-0.5">info</span>
                <span>
                  <strong>Factual vs Autonomous AI Distinction:</strong> The scanner evidence above represents raw, deterministic network payload logs. PatchPilot's Gemini engine models downstream blast radiuses, business context, and code-level remediation diffs.
                </span>
              </div>
            </div>
          )}

          {/* TAB 2: UNDERSTAND (AI EXPLAINER) */}
          {activeTab === 'understand' && (
            <div className="flex flex-col gap-4 animate-fadeIn">
              {/* Audience Selector Pills */}
              <div className="flex items-center gap-2 pb-2 border-b border-[#262a33] overflow-x-auto">
                <span className="font-code-sm text-[11px] text-[#908fa0] shrink-0 mr-2 font-mono">Tailor Explanation:</span>
                {(['beginner', 'developer', 'secops', 'executive'] as const).map((aud) => (
                  <button
                    key={aud}
                    onClick={() => setAudience(aud)}
                    className={`px-3 py-1.5 rounded-lg font-label-md text-[12px] transition-all cursor-pointer capitalize ${
                      audience === aud
                        ? 'bg-[#c0c1ff] text-[#1000a9] font-bold shadow-sm'
                        : 'bg-[#1c2028] text-[#c7c4d7] hover:bg-[#262a33] hover:text-[#dfe2ee]'
                    }`}
                    type="button"
                  >
                    {aud === 'secops' ? 'Security Analyst' : aud}
                  </button>
                ))}
              </div>

              {/* Active Explainer Card */}
              <div className="bg-[#1c2028] rounded-xl p-5 flex flex-col gap-4 shadow-sm border border-[#262a33]">
                <div className="flex items-center gap-2 text-[#d0bcff] font-label-lg text-[14px] font-semibold">
                  <span className="material-symbols-outlined text-[20px]">auto_awesome</span>
                  <span>{currentAudienceData.title}</span>
                </div>

                <blockquote className="font-body-lg text-[15px] text-[#dfe2ee] leading-relaxed pl-4 border-l-2 border-[#c0c1ff] italic">
                  {currentAudienceData.quote}
                </blockquote>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                  <div className="bg-[#0a0e16] p-3.5 rounded-lg flex flex-col gap-1 border border-[#262a33]">
                    <span className="font-code-sm text-[11px] text-[#7bd0ff] font-bold uppercase tracking-wider font-mono">What is happening</span>
                    <p className="font-body-sm text-[12px] text-[#c7c4d7]">
                      {currentAudienceData.happening}
                    </p>
                  </div>

                  <div className="bg-[#0a0e16] p-3.5 rounded-lg flex flex-col gap-1 border border-[#262a33]">
                    <span className="font-code-sm text-[11px] text-[#d0bcff] font-bold uppercase tracking-wider font-mono">Why it matters</span>
                    <p className="font-body-sm text-[12px] text-[#c7c4d7]">
                      {currentAudienceData.matters}
                    </p>
                  </div>

                  <div className="bg-[#0a0e16] p-3.5 rounded-lg flex flex-col gap-1 border border-[#262a33]">
                    <span className="font-code-sm text-[11px] text-[#ffb4ab] font-bold uppercase tracking-wider font-mono">Potential Impact</span>
                    <p className="font-body-sm text-[12px] text-[#c7c4d7]">
                      {currentAudienceData.impact}
                    </p>
                  </div>

                  <div className="bg-[#0a0e16] p-3.5 rounded-lg flex flex-col gap-1 border border-[#262a33]">
                    <span className="font-code-sm text-[11px] text-[#c0c1ff] font-bold uppercase tracking-wider font-mono">Affected Component</span>
                    <p className="font-body-sm text-[12px] text-[#dfe2ee] font-mono">
                      {currentAudienceData.component}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: REMEDIATION WORKSPACE */}
          {activeTab === 'remediation' && (
            <div className="flex flex-col gap-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold">Autonomous Remediation Guidance</span>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={handleCopyPatch}
                    className="px-3 py-1.5 rounded-lg bg-[#262a33] text-[#dfe2ee] font-label-md text-[12px] hover:bg-[#31353e] transition-colors flex items-center gap-1.5 border border-[#31353e] cursor-pointer" 
                    type="button"
                  >
                    <span className="material-symbols-outlined text-[16px]">
                      {copiedPatch ? 'check' : 'content_copy'}
                    </span>
                    <span>{copiedPatch ? 'Copied!' : 'Copy Patch'}</span>
                  </button>
                  <button 
                    onClick={handleCreatePr}
                    className="px-3 py-1.5 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-md text-[12px] font-bold hover:bg-[#e1e0ff] transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer" 
                    type="button"
                  >
                    <span className="material-symbols-outlined text-[16px]">fork_right</span>
                    <span>{prCreated ? 'PR #142 Created' : 'Create GitHub PR'}</span>
                  </button>
                </div>
              </div>

              {/* Step-by-Step List */}
              <div className="bg-[#1c2028] rounded-xl p-4 border border-[#262a33]">
                <ol className="flex flex-col gap-2 font-body-sm text-[12px] text-[#c7c4d7] list-decimal list-inside">
                  {(selectedVuln.stepsToFix || [
                    "Replace dynamic string concatenation immediately in the query pipeline.",
                    "Adopt parameterized queries utilizing native PostgreSQL positional placeholders ($1, $2).",
                    "Enforce schema validation with Zod/Joi to disallow unescaped characters in raw search inputs.",
                    "Run integration regression suite to confirm search behavior remains unbroken.",
                    "Scan all adjacent controller files for matching un-parameterized SQL statements."
                  ]).map((step: string, idx: number) => (
                    <li key={idx} className="leading-relaxed">
                      <strong className="text-[#dfe2ee]">{step.split(' ')[0]} {step.split(' ')[1]}</strong> {step.split(' ').slice(2).join(' ')}
                    </li>
                  ))}
                </ol>
              </div>

              {/* Code Diff Comparison */}
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between font-code-sm text-[11px] font-mono">
                  <span className="text-[#ffb4ab] font-bold flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px]">remove_circle</span>
                    Vulnerable Code (Before)
                  </span>
                  <span className="text-[#908fa0]">{selectedVuln.affectedFile || 'ProductSearchController.ts'}</span>
                </div>
                <pre className="bg-[#0a0e16] p-3 rounded-lg font-code-sm text-[11px] text-[#ffb4ab] overflow-x-auto font-mono border border-[#262a33]">
                  <code>{selectedVuln.vulnerableCode}</code>
                </pre>
              </div>

              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between font-code-sm text-[11px] font-mono">
                  <span className="text-[#7bd0ff] font-bold flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px]">add_circle</span>
                    Recommended Fix (Parameterized Query)
                  </span>
                  <span className="text-[#7bd0ff]">AI Suggested Fix</span>
                </div>
                <pre className="bg-[#0a0e16] p-3 rounded-lg font-code-sm text-[11px] text-[#7bd0ff] overflow-x-auto font-mono border border-[#262a33]">
                  <code>{selectedVuln.remediatedCode}</code>
                </pre>
              </div>

              {/* Prevention guidance */}
              <div className="p-3 rounded-lg bg-[#262a33]/60 text-[#c7c4d7] font-body-sm text-[12px] flex items-start gap-2 border border-[#31353e]">
                <span className="material-symbols-outlined text-[18px] text-[#7bd0ff] shrink-0 mt-0.5">verified</span>
                <span>
                  <strong>Hardening Best Practice:</strong> Apply database least-privilege credentials. The runtime application user should have no read privileges over the internal <code className="text-[#dfe2ee]">users</code> or <code className="text-[#dfe2ee]">system_keys</code> tables.
                </span>
              </div>
            </div>
          )}

          {/* TAB 4: VERIFY REMEDIATION */}
          {activeTab === 'verify' && (
            <div className="flex flex-col gap-4 animate-fadeIn">
              <div className="bg-[#1c2028] rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 border border-[#262a33]">
                <div className="flex flex-col">
                  <div className="flex items-center gap-2 text-[#dfe2ee] font-headline-sm text-[18px] font-bold">
                    <span className="material-symbols-outlined text-[#7bd0ff] text-[22px]">health_and_safety</span>
                    <span>Autonomous Verification Engine</span>
                  </div>
                  <p className="font-body-sm text-[12px] text-[#908fa0]">Re-run targeted vulnerability payloads against the live endpoint to conclusively verify fix efficacy.</p>
                </div>
                <button 
                  onClick={handleRunVerify}
                  disabled={isVerifying}
                  className="px-6 py-2.5 rounded-lg bg-[#00a6e0] text-[#00374d] font-label-lg text-[13px] font-bold hover:bg-[#7bd0ff] hover:text-[#00354a] transition-all flex items-center justify-center gap-2 shadow-sm shrink-0 cursor-pointer disabled:opacity-75" 
                  type="button"
                >
                  <span className={`material-symbols-outlined text-[20px] ${isVerifying ? 'animate-spin' : ''}`}>
                    {isVerifying ? 'hourglass_top' : isVerifiedSafe ? 'check_circle' : 'play_arrow'}
                  </span>
                  <span>{verifyStatusLabel}</span>
                </button>
              </div>

              {/* Progression Stepper */}
              <div className="bg-[#0a0e16] p-4 rounded-xl flex items-center justify-between gap-2 overflow-x-auto border border-[#262a33]">
                <div className="flex items-center gap-2 shrink-0">
                  <div className="w-7 h-7 rounded-full bg-[#93000a] text-[#ffdad6] flex items-center justify-center font-code-sm text-[11px] font-bold">1</div>
                  <div className="flex flex-col">
                    <span className="font-label-md text-[12px] text-[#dfe2ee] font-semibold">Detected</span>
                    <span className="font-code-sm text-[11px] text-[#ffb4ab] font-mono">SQLi (9.8)</span>
                  </div>
                </div>
                <span className="material-symbols-outlined text-[#908fa0] text-[18px]">arrow_forward</span>
                <div className="flex items-center gap-2 shrink-0">
                  <div className="w-7 h-7 rounded-full bg-[#a078ff] text-[#340080] flex items-center justify-center font-code-sm text-[11px] font-bold">2</div>
                  <div className="flex flex-col">
                    <span className="font-label-md text-[12px] text-[#dfe2ee] font-semibold">Patch Applied</span>
                    <span className="font-code-sm text-[11px] text-[#d0bcff] font-mono">PR #142 Merged</span>
                  </div>
                </div>
                <span className="material-symbols-outlined text-[#908fa0] text-[18px]">arrow_forward</span>
                <div className="flex items-center gap-2 shrink-0">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center font-code-sm text-[11px] font-bold ${
                    isVerifying ? 'bg-[#8083ff] text-[#0d0096] animate-pulse' : 'bg-[#262a33] text-[#c0c1ff]'
                  }`}>3</div>
                  <div className="flex flex-col">
                    <span className="font-label-md text-[12px] text-[#dfe2ee] font-semibold">Active Retest</span>
                    <span className="font-code-sm text-[11px] text-[#c0c1ff] font-mono">128 Payloads</span>
                  </div>
                </div>
                <span className="material-symbols-outlined text-[#908fa0] text-[18px]">arrow_forward</span>
                <div className="flex items-center gap-2 shrink-0">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center font-code-sm text-[11px] font-bold ${
                    isVerifiedSafe ? 'bg-[#7bd0ff] text-[#00354a]' : 'bg-[#262a33] text-[#908fa0]'
                  }`}>4</div>
                  <div className="flex flex-col">
                    <span className="font-label-md text-[12px] text-[#dfe2ee] font-semibold">Verified Safe</span>
                    <span className="font-code-sm text-[11px] text-[#7bd0ff] font-mono">Zero Exploit</span>
                  </div>
                </div>
              </div>

              {/* Success Result Card */}
              <div className={`bg-gradient-to-br from-[#262a33] via-[#1c2028] to-[#181c24] rounded-xl p-5 flex flex-col gap-4 shadow-sm border transition-all ${
                isVerifiedSafe ? 'border-[#7bd0ff] ring-1 ring-[#7bd0ff]/40' : 'border-[#31353e]'
              }`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#00a6e0]/20 text-[#7bd0ff] flex items-center justify-center shadow-sm">
                      <span className="material-symbols-outlined text-[24px]">verified</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-headline-sm text-[18px] text-[#dfe2ee] font-bold">
                        {isVerifiedSafe ? 'Remediation Verified Conclusively' : 'Verification Target Ready'}
                      </span>
                      <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">
                        Target Session: #VER-2024-SESSION-9 • Scanner: OWASP ZAP v2.14
                      </span>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded bg-[#00a6e0]/20 text-[#7bd0ff] font-code-sm text-[11px] font-bold font-mono">
                    {isVerifiedSafe ? 'CLEARED' : 'PENDING CHECK'}
                  </span>
                </div>

                <p className="font-body-md text-[13px] text-[#c7c4d7] leading-relaxed">
                  The previously reported database syntax exception was <strong className="text-[#dfe2ee]">not reproducible</strong> during the verification pass. All 128 mutation test vectors returned clean HTTP 200 responses with properly escaped literals.
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                  <div className="bg-[#0a0e16] p-3 rounded-lg border border-[#262a33]">
                    <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Initial State</span>
                    <div className="font-code-md text-[13px] text-[#ffb4ab] font-bold mt-1 font-mono">CRITICAL 9.8</div>
                  </div>
                  <div className="bg-[#0a0e16] p-3 rounded-lg border border-[#262a33]">
                    <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Post-Patch</span>
                    <div className="font-code-md text-[13px] text-[#7bd0ff] font-bold mt-1 font-mono">NOT DETECTED</div>
                  </div>
                  <div className="bg-[#0a0e16] p-3 rounded-lg border border-[#262a33]">
                    <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Latency Delta</span>
                    <div className="font-code-md text-[13px] text-[#dfe2ee] font-bold mt-1 font-mono">-34ms (Faster)</div>
                  </div>
                  <div className="bg-[#0a0e16] p-3 rounded-lg border border-[#262a33]">
                    <span className="font-code-sm text-[10px] text-[#908fa0] uppercase font-mono">Regression Risk</span>
                    <div className="font-code-md text-[13px] text-[#7bd0ff] font-bold mt-1 font-mono">0% Clean</div>
                  </div>
                </div>

                <div className="font-code-sm text-[11px] text-[#908fa0] bg-[#0a0e16]/60 p-2.5 rounded-lg flex items-center gap-2 border border-[#262a33]">
                  <span className="material-symbols-outlined text-[15px] text-[#908fa0]">shield</span>
                  <span>Verification reflects the results of the latest automated scan suite and does not guarantee absolute absence of architectural risk.</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* 5. EXECUTIVE SECURITY BRIEF PREVIEW SECTION */}
      <section className="bg-[#181c24] rounded-xl p-4 lg:p-6 shadow-sm border border-[#262a33] flex flex-col gap-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-[#262a33]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#8083ff]/20 text-[#c0c1ff] flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px]">assignment</span>
            </div>
            <div className="flex flex-col">
              <h3 className="font-headline-sm text-[18px] text-[#dfe2ee] font-bold">Live Executive Security Brief Preview</h3>
              <span className="font-body-sm text-[12px] text-[#908fa0]">Board-ready PDF synopsis compiled from verified findings & attack surface exposure.</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={onOpenSlackModal}
              className="px-4 py-2 rounded-lg bg-[#262a33] text-[#dfe2ee] font-label-md text-[13px] hover:bg-[#31353e] transition-colors flex items-center gap-1.5 border border-[#31353e] cursor-pointer" 
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">share</span>
              <span>Share with SecOps Team</span>
            </button>
            <button 
              onClick={onOpenBriefModal}
              className="px-4 py-2 rounded-lg bg-[#c0c1ff] text-[#1000a9] font-label-md text-[13px] hover:bg-[#e1e0ff] transition-colors flex items-center gap-1.5 font-bold cursor-pointer" 
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">picture_as_pdf</span>
              <span>Export Official PDF Report</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          <div className="bg-[#1c2028] p-4 rounded-xl flex flex-col justify-between border border-[#262a33]">
            <span className="font-code-sm text-[11px] text-[#908fa0] uppercase tracking-wider font-mono">Executive Summary</span>
            <p className="font-body-sm text-[13px] text-[#dfe2ee] my-2 leading-relaxed">
              The target host <code className="text-[#7bd0ff] font-mono text-[12px]">localhost:3000</code> presents <strong>2 Critical</strong> exploitable endpoints requiring immediate triage prior to production deployment.
            </p>
            <span className="font-code-sm text-[11px] text-[#ffb4ab] font-bold font-mono">Compliance: Non-Compliant</span>
          </div>

          <div className="bg-[#1c2028] p-4 rounded-xl flex flex-col justify-between border border-[#262a33]">
            <span className="font-code-sm text-[11px] text-[#908fa0] uppercase tracking-wider font-mono">Active Attack Vector</span>
            <p className="font-body-sm text-[13px] text-[#dfe2ee] my-2 leading-relaxed">
              Public internet → Unauthenticated Search Endpoint → Raw PostgreSQL Interpreter → Administrative credential dump.
            </p>
            <span className="font-code-sm text-[11px] text-[#ffb4ab] font-bold font-mono">Exploitation Risk: Urgent</span>
          </div>

          <div className="bg-[#1c2028] p-4 rounded-xl flex flex-col justify-between border border-[#262a33]">
            <span className="font-code-sm text-[11px] text-[#908fa0] uppercase tracking-wider font-mono">Remediation Velocity</span>
            <div className="flex items-baseline gap-2 my-2">
              <span className="font-headline-xl text-[28px] text-[#dfe2ee] font-bold">4 / 22</span>
              <span className="font-code-sm text-[11px] text-[#7bd0ff] font-bold font-mono">18% Cleared</span>
            </div>
            <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">Mean Time to Triage: 8m</span>
          </div>

          <div className="bg-[#1c2028] p-4 rounded-xl flex flex-col justify-between border border-[#262a33]">
            <span className="font-code-sm text-[11px] text-[#908fa0] uppercase tracking-wider font-mono">Audit Attestation</span>
            <div className="flex items-center gap-2 my-2">
              <span className="material-symbols-outlined text-[#7bd0ff] text-[24px]">verified</span>
              <span className="font-label-lg text-[14px] text-[#dfe2ee] font-semibold">Automated Retest Pass</span>
            </div>
            <span className="font-code-sm text-[11px] text-[#908fa0] font-mono">Cryptographic Hash: <code className="text-[#dfe2ee]">9f2e...41a8</code></span>
          </div>
        </div>
      </section>

      {/* 6. FOOTER BRAND TAGLINE */}
      <footer className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 pb-8 text-[#908fa0] font-code-sm text-[11px] border-t border-[#262a33]/60 font-mono">
        <div className="flex items-center gap-2">
          <span className="material-symbols-outlined text-[16px] text-[#c0c1ff]">shield</span>
          <span className="font-semibold text-[#dfe2ee]">PatchPilot</span>
          <span>•</span>
          <span className="text-[#7bd0ff] font-medium">Detect. Understand. Defend.</span>
        </div>
        <div>
          <span>Autonomous Vulnerability Remediation Platform • v4.18 Enterprise Build</span>
        </div>
      </footer>
    </div>
  );
};
