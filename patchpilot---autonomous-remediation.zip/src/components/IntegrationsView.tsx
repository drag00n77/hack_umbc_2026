import React from 'react';

export const IntegrationsView: React.FC = () => {
  const integrations = [
    {
      name: "OWASP ZAP Core Engine",
      category: "Dedicated Security Scanner",
      status: "Connected & Operational",
      version: "v2.14.0",
      description: "Strictly designated primary dynamic penetration engine running via local daemon IPC on 127.0.0.1:8080.",
      connected: true,
      icon: "security"
    },
    {
      name: "Google Gemini 1.5 Pro",
      category: "Autonomous AI Intelligence",
      status: "Active (SecOps Fine-Tuning)",
      version: "2026 Edition",
      description: "Generates tailored multi-audience risk explanations, root-cause AST mapping, and executable git diff remediations.",
      connected: true,
      icon: "auto_awesome"
    },
    {
      name: "Slack Incident Webhooks",
      category: "Alerting & ChatOps",
      status: "Connected (#security-incidents)",
      version: "App ID: #SLACK-8812",
      description: "Instant dispatch of Critical severity findings and triage queue updates to SecOps on-call teams.",
      connected: true,
      icon: "campaign"
    },
    {
      name: "GitHub PR Remediation Bot",
      category: "Source Code Management",
      status: "Connected (@patchpilot-bot)",
      version: "GitHub App v3",
      description: "Automates branch creation and pull request submissions for parameterized database statements.",
      connected: true,
      icon: "fork_right"
    },
    {
      name: "Jira Software Cloud",
      category: "Issue Tracking & Workflows",
      status: "Connected (Project SEC)",
      version: "v9.4 API",
      description: "Two-way synchronization of detected findings, triage priorities, and staging verification passes.",
      connected: true,
      icon: "task"
    },
    {
      name: "Nuclei Engine Extension",
      category: "Community Templates",
      status: "Standby Consensus",
      version: "v3.2",
      description: "Secondary consensus engine for validating fast template-based perimeter footprints.",
      connected: true,
      icon: "dynamic_form"
    }
  ];

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-6 max-w-[1720px] mx-auto w-full">
      <div>
        <span className="font-code-sm text-[11px] text-[#7bd0ff] uppercase tracking-wider font-mono">
          Ecosystem Connectivity
        </span>
        <h1 className="font-headline-xl text-[30px] md:text-[34px] text-[#dfe2ee] font-bold tracking-tight">
          Integrations Hub
        </h1>
        <p className="font-body-md text-[13px] text-[#908fa0] mt-1 max-w-2xl">
          Verified connectors for security engines, code repositories, communication channels, and ticketing platforms.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {integrations.map((item, idx) => (
          <div key={idx} className="bg-[#181c24] p-5 rounded-xl border border-[#262a33] flex flex-col justify-between shadow-sm">
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-lg bg-[#262a33] flex items-center justify-center text-[#c0c1ff] border border-[#31353e]">
                    <span className="material-symbols-outlined text-[20px]">{item.icon}</span>
                  </div>
                  <div className="flex flex-col">
                    <h3 className="font-semibold text-[#dfe2ee] text-[15px]">{item.name}</h3>
                    <span className="text-[11px] text-[#908fa0] font-mono">{item.category}</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-[#00a6e0]/20 text-[#7bd0ff] font-code-sm text-[10px] font-bold font-mono">
                  {item.version}
                </span>
              </div>
              <p className="font-body-sm text-[12px] text-[#c7c4d7] mt-3 leading-relaxed">
                {item.description}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-[#262a33] flex items-center justify-between">
              <span className="flex items-center gap-1.5 font-code-sm text-[11px] text-[#7bd0ff] font-mono">
                <span className="h-2 w-2 rounded-full bg-[#7bd0ff]"></span>
                {item.status}
              </span>
              <button 
                onClick={() => alert(`Configuring parameters for ${item.name}`)}
                className="px-2.5 py-1 rounded bg-[#262a33] hover:bg-[#31353e] text-[#dfe2ee] font-code-sm text-[11px] font-mono cursor-pointer border border-[#31353e]"
              >
                Configure
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
