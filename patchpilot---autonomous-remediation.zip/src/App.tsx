import React, { useState } from 'react';
import { Sidebar, NavTab } from './components/Sidebar.tsx';
import { Header } from './components/Header.tsx';
import { SecurityOverview } from './components/SecurityOverview.tsx';
import { NewScan } from './components/NewScan.tsx';
import { VulnerabilitiesView } from './components/VulnerabilitiesView.tsx';
import { AttackPathsView } from './components/AttackPathsView.tsx';
import { RemediationCenter } from './components/RemediationCenter.tsx';
import { VerificationCenter } from './components/VerificationCenter.tsx';
import { ReportsView } from './components/ReportsView.tsx';
import { IntegrationsView } from './components/IntegrationsView.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { ExecutiveBriefModal } from './components/ExecutiveBriefModal.tsx';
import { SlackAlertModal } from './components/SlackAlertModal.tsx';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('security-overview');
  const [isSlackModalOpen, setIsSlackModalOpen] = useState(false);
  const [isBriefModalOpen, setIsBriefModalOpen] = useState(false);
  const [isGlobalScanning, setIsGlobalScanning] = useState(false);

  const handleTriggerGlobalScan = () => {
    setIsGlobalScanning(true);
    setTimeout(() => {
      setIsGlobalScanning(false);
    }, 2500);
  };

  return (
    <div className="bg-[#0f131c] min-h-screen text-[#dfe2ee] font-sans antialiased selection:bg-[#8083ff] selection:text-[#0d0096]">
      {/* Fixed Left Navigation Sidebar */}
      <Sidebar 
        currentTab={currentTab} 
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }} 
      />

      {/* Main Container with Left Padding for Sidebar */}
      <div className="pl-72">
        {/* Fixed Top Header Bar */}
        <Header 
          currentTab={currentTab}
          onOpenSlackModal={() => setIsSlackModalOpen(true)}
          onOpenBriefModal={() => setIsBriefModalOpen(true)}
          onTriggerScan={handleTriggerGlobalScan}
          isScanning={isGlobalScanning}
        />

        {/* Dynamic Main Workspace Container */}
        <main className="w-full pt-20 bg-[#0f131c] min-h-screen">
          {currentTab === 'security-overview' && (
            <SecurityOverview 
              onNavigate={setCurrentTab}
              onOpenSlackModal={() => setIsSlackModalOpen(true)}
              onOpenBriefModal={() => setIsBriefModalOpen(true)}
            />
          )}

          {currentTab === 'new-scan' && (
            <NewScan 
              onNavigate={setCurrentTab} 
            />
          )}

          {currentTab === 'vulnerabilities' && (
            <VulnerabilitiesView 
              onNavigate={setCurrentTab} 
            />
          )}

          {currentTab === 'attack-paths' && (
            <AttackPathsView 
              onNavigate={setCurrentTab} 
            />
          )}

          {currentTab === 'remediation-center' && (
            <RemediationCenter 
              onNavigate={setCurrentTab} 
            />
          )}

          {currentTab === 'verification' && (
            <VerificationCenter 
              onNavigate={setCurrentTab}
              onOpenBriefModal={() => setIsBriefModalOpen(true)}
            />
          )}

          {currentTab === 'reports' && (
            <ReportsView 
              onOpenBriefModal={() => setIsBriefModalOpen(true)} 
            />
          )}

          {currentTab === 'integrations' && (
            <IntegrationsView />
          )}

          {currentTab === 'settings' && (
            <SettingsView />
          )}
        </main>
      </div>

      {/* Modals */}
      <ExecutiveBriefModal 
        isOpen={isBriefModalOpen} 
        onClose={() => setIsBriefModalOpen(false)} 
      />

      <SlackAlertModal 
        isOpen={isSlackModalOpen} 
        onClose={() => setIsSlackModalOpen(false)} 
      />
    </div>
  );
}
